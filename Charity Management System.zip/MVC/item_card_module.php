
<?php
 echo ('you are in module'); 

////////////////////////////////////////////////////////////////////////////////////////////oop work
echo ('you are at module');
class item_card
 {
  // Properties
  public     $item_ID;
   public     $Name;
  public     $item_quntity;
  public     $incoming;
  public     $outgoing;
  public     $dmy;
  public     $note;
  // Methods
  //////////////////////////////sets
          public function __construct()
        {
            $this->item_ID = NULL;
            $this->item_quntity = NULL;
            $this->incoming = NULL;
            $this->outgoing = NULL;
            $this->dmy = NULL;
            $this->note = NULL;
        }

 public function set_Item_ID($Item_ID)
  {        
   $this->item_ID = $Item_ID;
  
  }
 public function set_item_amount($item_quntity)                   
  {
     
    $this->item_quntity = $item_quntity;
  }
 public function set_incoming($incoming)
  {
    
    $this->incoming = $incoming;
  }
 public function set_outgoing($outgoing)
  {
   
    $this->outgoing = $outgoing;
  }
 public function set_date_of_item($dmy)
  {
     
    $this->dmy = $dmy;
  }
 public function set_note($note)
  {
     
    $this->note = $note;
  }
  ///////////////////gets   
 public function get_Item_ID () 
  {  
    $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->item_ID=$row['ID']; 

                            
                        }
                    }
    //return $this->item_ID;
  }
 public function get_Item_amount () 
  {
    $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 )
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {

                            $this->item_quntity=$row['Quantity']; 
                           

                        }
                    }
    //return $this->item_quntity;
  }
  public function get_incoming () 
  {
     $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->incoming=$row['Incoming']; 
                 
                            
                        }
                    }
  }
  public function get_outgoing () 
  {$link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->outgoing=$row['Outgoing']; 

                            
                        }
                    }
   
  }
  public function get_date_of_item () 
  {
    $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->date_of_item=$row['DateOfTransc']; 

                            
                        }
                    }
   
  }
  public function get_note () 
  {
    $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 )
                    {
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->note=$row['Note']; 

                            
                        }
                    }
   
  }
  ///logical function
 public function feedback () 
  {
    //////............get all info about one item only
  }
   public function insert_in_db() 
  {
    
     
       $link = mysqli_connect("localhost", "root", "", "mmm");
 
              if($link === false){
                  die("ERROR: Could not connect. " . mysqli_connect_error());
              }
                    // Attempt insert query execution
                 $sql = "INSERT INTO `item card`(`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`) VALUES ('$this->item_ID','$this->item_quntity','$this->incoming','$this->outgoing','$this->dmy','$this->note')";

                 if(mysqli_query($link, $sql)){
                    echo "item inserted successfully.";
                 } else{
                    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                 } 



       
     }
      public function update_record($Item_ID,$item_quntity,$incoming,$outgoing,$dmy,$note)  
  { 
    
     
       $link = mysqli_connect("localhost", "root", "", "mmm");                             
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


               $sql =" UPDATE `item card` SET Quantity='$item_quntity' ,Incoming='$incoming',Outgoing='$outgoing'
               ,Note='$note'  WHERE ID='$Item_ID'";
               //,DateOfTransc='$dmy'

                        /*UPDATE Customers
                        SET ContactName='Alfred Schmidt', City='Frankfurt'
                        WHERE CustomerID=1;*/


               if(mysqli_query($link, $sql))
               {
                echo "Records updated successfully.";
                } 
                else
                {
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }


       
     }
      public function delete_record($Item_ID)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
  {
    
     
       $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


               $sql =" DELETE FROM `item card`  WHERE ID='$Item_ID'";



               if(mysqli_query($link, $sql)){
                echo "Records deleted successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }


       
     }
     public function search_and_view($Item_ID)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
  {/*SELECT * FROM Customers
WHERE Country='Mexico';
*/
    
    $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card` WHERE ID='$Item_ID'";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                             $this->item_ID=$row['ID']; 
                             $this->item_quntity=$row['Quantity']; 
                             $this->incoming=$row['Incoming']; 
                             $this->outgoing=$row['Outgoing'];
                             //$this->dmy=$row['DateOfTransc']; 
                             $this->note=$row['Note']; 
                        }
                    }
         
       
     }
      public function FetchData()
    {
      $IcArray = array();

      $link = mysqli_connect("localhost", "root", "", "mmm");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

          $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);

                    if(mysqli_num_rows($result) > 0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $IC = new item_card(); 

                            $IC->item_ID = $row['ID'];
                            $IC->Name = $row['Name'];
                            $IC->item_quntity = $row['Quantity'];
                            $IC->incoming = $row['Incoming'];
                            $IC->outgoing = $row['Outgoing'];
                            $IC->dmy = $row['DateOfTransc.'];
                            $IC->note = $row['Note'];
                            $IC->Warehouse_ID = $row['Warehouse_ID']; 

                            array_push($IcArray , $IC);
                        }
                    } 
                  
                   
                    echo "<br>";
                    //echo "This Should be the statement before the return ";
                   return $IcArray;

      // echo "<br>";
      // print_r($IcArray);
    }
 
}
   
    
?>
   
