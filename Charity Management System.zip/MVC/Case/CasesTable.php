
<?php

//start_session();
require_once 'Case.controller.php';

echo ' 
<!DOCTYPE html>
<html>

<head>
<style>


body {
  background-color: #8cd98c;

}

table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  background-color: white;
}
th, td {
  padding: 10px;
  
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.tab-2 input{display: block;margin-bottom: 10px}
.tab-2{margin-left: 1000px;margin-bottom: -300px}
tr:hover{background-color:#EEE;cursor: pointer}
tr{transition:all .25s ease-in-out}



.right{
  position: absolute;
  left:73%;
  top:5%;
}


a:link, a:visited {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  
}

</style>
</head>


<body>
<h2>Cases</h2>
<br>
<br>
<br>
<br>
<form action="Case.controller.php" method="POST" >

     
        <div class="tab tab-2">
        ID:<input type="text" name="ID" id="ID" required>
        Name:<input type="text" name="Name" id="Name" required>
        <td>Type :</td>
        <td>
        <br>
        ';

$count = 1;
  echo '
  <select name="Type" id="Type"> 
  ';
      $array = json_decode( $_SESSION["SendTypes"] , true);

      foreach ($array as $arrays)
            {
              $count=$arrays['ID'];
              echo '
              <option value="';echo $count;echo'">';echo $arrays['Type']; echo'</option>

              ';
              // $count=$count+1;



            }
            echo ' <br>
            </select>
            ';



echo'
</td>
<br>
<br>
        Age: <input type="number" name="Age" id="Age" required>
        Feedback:<input type="text" name="Feedback" id="Feedback" required>
        <td>Gender :</td>
        <td>
        <select name="Gender" id="Gender">
        <option value="M">Male</option>
        <option value="F">Female</option>
      </td>
        </select>
                                
                <button onclick="editHtmlTbleSelectedRow(); value="Edit" name="Edit" ">Edit</button>
                
                
            </div>


<table id="table" style="width:60%">
  <tr>
    <th>ID</th>
    <th>Name</th> 
    <th>Type ID</th>
    <th>Type</th>
    <th>Age</th>
    <th>Feedback</th>
    <th>Gender </th>      
  </tr>';

  
  

if(isset($_SESSION["whatever"])){
  
  $array = json_decode( $_SESSION["whatever"] , true);  
foreach ($array as $arrays)
            {
               echo '<tr><td>';
                    echo $arrays['ID'];
                    echo'</td><td>';
                    echo $arrays['casename'];
                    echo'</td><td>';
                    echo $arrays['casetypeID'];
                    echo'</td><td>';
                    echo $arrays['casetype'];
                    echo'</td><td>';
                    echo $arrays['caseage'];
                    echo'</td><td>';
                    echo $arrays['feedback'];
                    echo'</td><td>';
                    echo $arrays['gender'];
                    echo'</td>';
                    echo '<td>';
                    echo '<button onclick="removeSelectedRow(); value="Remove" name="Remove"">Remove</button>';
                    echo'</td>';
                    // echo '<td>';
                    // echo '<button onclick="GetCaseType(); value="GCT" name="GCT"">Get Case Type</button>';
                    // echo'</td>';                                              
                    echo'</tr>';
            }          
}


  
echo'</table>

<br>
<br>
<br>

<script>


function selectedRowToInput()
              {
                var table = document.getElementById("table");
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {                         
                        document.getElementById("ID").value = this.cells[0].innerHTML;
                        document.getElementById("Name").value = this.cells[1].innerHTML;
                        document.getElementById("Type").value = this.cells[2].innerHTML;
                        document.getElementById("Age").value = this.cells[4].innerHTML;
                        document.getElementById("Feedback").value = this.cells[5].innerHTML;
                        document.getElementById("Gender").value = this.cells[6].innerHTML;                         
                    };
                }                             
              }
              
              selectedRowToInput();
                           
                function editHtmlTbleSelectedRow()
                {
                    var ID = document.getElementById("ID").value,
                        Name = document.getElementById("Name").value,
                        Type = document.getElementById("Type").value,
                        Age = document.getElementById("Age").value,
                        Feedback = document.getElementById("Feedback").value,
                        Gender = document.getElementById("Gender").value;
                        
                    var
                        W1 = $_POST["ID"],
                        W2 = $_POST["Name"],
                        W3 = $_POST["Type"],
                        W4 = $_POST["Age"],
                        W5 = $_POST["Feedback"],
                        W6 = $_POST["Gender"];

                } 
                function removeSelectedRow()
                {
                    var ID = document.getElementById("ID").value;
                        
                    var
                        W1 = $_POST["ID"];
                }                                                      

         </script>
<div class="right">
<button class="button" class="button onclick="myFunction() value="Insert" name="Insert" ">Insert New Item</button>
<a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
<script>
   function myFunction() {
       $n=new requested_items2(); 
    $TTT = $_POST[2];
    $n=$_POST[2];

   }

     </script>

</div>



</form>
</body>
</html>';







///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////


?>