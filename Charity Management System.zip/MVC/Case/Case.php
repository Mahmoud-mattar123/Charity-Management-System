<?php

require_once 'D:/Xamp new/htdocs/MVC/Database.php';
require_once 'D:/Xamp new/htdocs/MVC/CaseType/CaseType.php';

        class Cases {
                       
        public $ID;
        public $casename;
        public $casetypeID;
        public $casetype;
        public $caseage;
        public $feedback;
        public $gender;
        
        //constructor
        public function __construct(){
            $this->ID =NULL;
            $this->casename =NULL;
            $this->casetypeID =NULL;
            $this->caseage =NULL;
            $this->feedback =NULL;
            $this->gender =NULL;
        }

        ////////////////////////////////////////////////        

        public function getcasename($ID)
        {
           $db = Database::getInstance();
           $mysqli = $db->getConnection(); 
           $sql_query = "SELECT * FROM cases WHERE `ID` = '$ID'";
           $result = $mysqli->query($sql_query);   
                                                
               while ($row = mysqli_fetch_assoc($result)){                                                    
                $this->casename=$row['Name'];                            
               }
               
               return $this->casename;
        }


         public function FetchData()
         {
           $CsArray = array();
           
           $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases";
            $result = $mysqli->query($sql_query);                    
                                                                    
                while ($row = mysqli_fetch_assoc($result))
                {
                    $Cs = new Cases();
                    $CT = new CaseType(); 
                    $Cs->ID = $row['ID'];
                    $Cs->casename = $row['Name'];
                    $Cs->casetypeID = $row['Case_Type_ID'];
                    $Cs->casetype = $CT->FetchType($Cs->casetypeID);   ////3amal                   
                    $Cs->caseage = $row['Age'];
                    $Cs->feedback = $row['Feedback'];
                    $Cs->gender = $row['Gender'];                                                                                      
                    array_push($CsArray , $Cs);
               }                                                  
                    echo "<br>";                         
                    return $CsArray;           
        }


         public function setcasetype($casetype)
         {                 
            $this->casetype=$casetype;
         }
 
         public function getcasetype($ID)
         {            
                $db = Database::getInstance();
                $mysqli = $db->getConnection(); 
                $sql_query = "SELECT * FROM cases WHERE `ID` = '$ID'";
                $result = $mysqli->query($sql_query);
                                                
                while ($row = mysqli_fetch_assoc($result)){         
                    $this->casetype=$row['Case_Type_ID'];  
                }
                
                return $this->casetype;
         }

         public function setcaseid($caseid)
         {            
            $this->caseid=$caseid;             
         }
 
         public function getcaseid()
         {            
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases";
            $result = $mysqli->query($sql_query);            
                                    
            while ($row = mysqli_fetch_assoc($result)){                                                    
                 $this->caseid=$row['ID'];                                                    
            }             
         }

         public function setcasename($casename)
         {                         
            $this->casename=$casename;
         }
          

         public function setcaseage($caseage)
        {                                                    
            $this->caseage=$caseage;                   
        }

        public function getcaseage()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases";
            $result = $mysqli->query($sql_query);  
                                    
                while ($row = mysqli_fetch_assoc($result)){                                                 
                    $this->caseage=$row['Age'];                             
                }                                
        }



        public function setfeedback($feedback)
        {                              
            $this->feedback=$feedback;
        }

        public function getfeedback()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases";
            $result = $mysqli->query($sql_query);   
                                  
                while ($row = mysqli_fetch_assoc($result)){                                        
                    $this->feedback=$row['Feedback'];                             
                }                                
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        public function setgender($gender)
        {                                                      
            $this->gender=$gender;
        }

        public function getgender()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases";
            $result = $mysqli->query($sql_query);                                  
                  
                while ($row = mysqli_fetch_assoc($result)){                                                  
                            $this->gender=$row['Gender'];                         
                }                           
        }
        
        //////////////////////////////////////////////////////////////////////////
    

        public function create_new_case($casename , $casetypeID ,$caseage , $feedback ,$gender)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            // $sql_query = "SELECT * FROM casetype WHERE Case_Type='$casetypeID'";
            // $result = $mysqli->query($sql_query);

            //     while ($row = mysqli_fetch_assoc($result))
            //     {
            //         $record=$row['ID'];
            //     }

               $sql_query = "INSERT INTO cases(Name, Case_Type_ID, Age, Feedback, Gender) VALUES ('$casename','$casetypeID','$caseage','$feedback','$gender')";
               $resultt = $mysqli->query($sql_query);

               if(mysqli_query($mysqli, $resultt)){
                echo "Records inserted successfully.";
                } 
                // else{
                // echo "ERROR: Could not able to execute $resultt. " . mysqli_error($mysqli);
                // }
        }

        //////////////////////////////////////name
        public function Update_case_name($caseid,$casename)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE cases SET `Name`='$casename' WHERE `ID`='$caseid'";
            $result = $mysqli->query($sql_query);
             
               if(mysqli_query($mysqli, $sql_query)){
                echo "Records Update successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }


        //////////////////////////////////////Type
        public function Update_case_type($caseid,$casetype)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE cases SET `Type`='$casetype' WHERE `ID`='$caseid'";
            $result = $mysqli->query($sql_query);
               
               if(mysqli_query($mysqli, $sql_query)){
                echo "Records Update successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }

        

        public function UpdateAll($ID,$casename , $casetypeID ,$caseage , $feedback ,$gender)
        {                
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `cases` SET `Name`= '$casename',`Case_Type_ID`='$casetypeID',`Age`='$caseage',`Feedback`='$feedback',`Gender`='$gender' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);    
                                             
               if(mysqli_query($mysqli, $sql_query)){
                echo "Record Updated successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }


        //////////////////////////////////////age
        public function Update_case_age($caseid,$caseage)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE cases SET `Age`='$caseage' WHERE `ID`='$caseid'";
            $result = $mysqli->query($sql_query);             

               if(mysqli_query($mysqli, $sql_query)){
                echo "Record Update successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }

        //////////////////////////////////////feedback
        public function Update_case_feedback($caseid,$feedback)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = " UPDATE cases SET `Feedback`='$feedback' WHERE `ID`='$caseid'";
            $result = $mysqli->query($sql_query);
                          
               if(mysqli_query($mysqli, $sql_query)){
                echo "Records Update successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }



          //////////////////////////////////////feedback
          public function Update_case_gender($caseid,$gender)
          {                    
                $db = Database::getInstance();
                $mysqli = $db->getConnection(); 
                $sql_query = "UPDATE cases SET `Gender`='$gender' WHERE `ID`='$caseid'";
                $result = $mysqli->query($sql_query);
                                   
                 if(mysqli_query($mysqli, $sql_query)){
                  echo "Records Update successfully.";
                  } 
                  else{
                  echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                  }
          }


        public function  delete_case($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "DELETE FROM cases WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);  
           
            if(mysqli_query($mysqli, $sql_query)){
                echo "Record Deleted successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }


        public function View_case_Information($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);                 
                while($row=mysqli_fetch_array($result)){
                        return $row['ID']. " | " .$row['Name']. " | ". $row['Type']. " | ".$row['Age']. " | ". $row['Feedback']. " | ".$row['Gender'];                                       
              }        
        }

        public function FetchDataTypes($ID)
        {                        
            $SpecificItem = array();
    
            $db = Database::getInstance();
            $mysqli = $db->getConnection();                                                                                                

            $sql_query = "SELECT * FROM `casetype` WHERE `ID`= '$ID'";
            $result = $mysqli->query($sql_query);
            while ($row = mysqli_fetch_assoc($result))
            {
                $Details = new CaseType();
                $Details->ID = $row['ID'];
                $Details->Type = $row['Case_Type'];
                array_push($SpecificItem , $Details); 
            }                            
            echo "<br>";
            return $SpecificItem;     
        }

        public function FetchCasesType()
        {                        
            $SpecificItem = array();
    
            $db = Database::getInstance();
            $mysqli = $db->getConnection();                                                                                                

            $sql_query = "SELECT * FROM `casetype`";
            $result = $mysqli->query($sql_query);
            while ($row = mysqli_fetch_assoc($result))
            {
                $Details = new CaseType();
                $Details->ID = $row['ID'];
                $Details->Type = $row['Case_Type'];
                array_push($SpecificItem , $Details); 
            }                            
            echo "<br>";
            return $SpecificItem;     
        }


        public function new_casetype($c_t)
        { 

            $db = Database::getInstance();
            $mysqli = $db->getConnection();

            $sql_query = "INSERT INTO  casetype(Case_Type) VALUES('$c_t')";
            $resultt = $mysqli->query($sql_query);

            if(mysqli_query($mysqli, $resultt)){
            echo "Records inserted successfully.";
            } 


        }

    }
?>


