<?php
require_once 'Case.php';




class Cases2
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        //////////////////
        public $W1;
        public $W2;
        public $W3;
        public $W4;
        public $W5;
        public $W6;


             //constructor
           public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
            ///////////////////////////
            $this->W1 =NULL;
            $this->W2 =NULL;
            $this->W3 =NULL;
            $this->W4 =NULL;
            $this->W5 =NULL;
            $this->W6 =NULL;
           
        }
    }
     
    $TTT = 1;
    $FFF = 1;

    if(isset($_POST['Insert'])){
    
        $TTT = 2;
     }
  if(isset($_POST['do1'])){

  $TTT = 2;
  }
$ct_correct=0;
        if(isset($_POST['Edit'])){
          $ThisWillWork = new Cases2();
        if (is_numeric($_POST["ID"])) { 
          if($_POST["ID"]>0)
          {

            $ThisWillWork->W1 = $_POST["ID"];
            $ct_correct+=1;
          }
          

        }
        
        if (is_numeric($_POST["Name"])) { 
        //donothing

        }
        else{
          $ThisWillWork->W2 = $_POST["Name"];
        $ct_correct+=1;

        }
        if (is_numeric($_POST["Age"]) &&$_POST["Age"]>0) { 
          $ThisWillWork->W4 = $_POST["Age"];
          $ct_correct+=1;

        }
       
        if (is_numeric($_POST['Feedback'])) { 
        //donothing

        }
        else{
          $ThisWillWork->W5 = $_POST["Feedback"];
        $ct_correct+=1;

        }
        if (is_numeric($_POST["Gender"])) { 
        //donothing

        }
        else{
          
           if($_POST["Gender"]=='F'||$_POST["Gender"]=='f'||$_POST["Gender"]=='M'||$_POST["Gender"]=='m')
           {
         
            $ThisWillWork->W6 = $_POST["Gender"];   
            $ct_correct+=1;


           }
           
          
          

        }
       


        
      
        if($ct_correct==5)
        {

          $ThisWillWork->W3 = $_POST["Type"];
          $userOne = new Cases();
          $userOne->UpdateAll($ThisWillWork->W1 , $ThisWillWork->W2 , $ThisWillWork->W3 , $ThisWillWork->W4 , $ThisWillWork->W5 , $ThisWillWork->W6);
  

        }
       


        }


      if(isset($_POST['Remove'])){

     

        $ThisWillWork = new Cases2();
        $ThisWillWork->W1 = $_POST["ID"];        
       

        $userOne = new Cases();        
        $userOne->delete_case($ThisWillWork->W1);                
      }

      if(isset($_POST['GCT'])){     
        $ThisWillWork = new Cases2();
        $ThisWillWork->W1 = $_POST["Type"];  
        echo "ID Is ". $ThisWillWork->W1;
        $ThisWillWork2 = new Cases();
        $Arrayyyy2 = $ThisWillWork2->FetchDataTypes($ThisWillWork->W1);  
        $string2 = json_encode($Arrayyyy2);    
        $_SESSION["whatever2"] = $string2;
    
        //echo "The Value Is " . $ThisWillWork->W1;
      }
    
    

    if($TTT==1)
    {        
        
        $userOne = new Cases();
        $ThisWillWork2 = new Cases();
        $Arrayyyy2 = $ThisWillWork2->FetchCasesType();
        $string2 = json_encode($Arrayyyy2); 
        $_SESSION["SendTypes"] = $string2;

        $Arrayyyy = $userOne->FetchData();
                                 
            $string = json_encode($Arrayyyy);
            $_SESSION["whatever"] = $string;
            require_once 'Casestable.php';            
           
    }
    else{
      $ThisWillWork2 = new Cases();
      $Arrayyyy2 = $ThisWillWork2->FetchCasesType();  
      $string2 = json_encode($Arrayyyy2);    
      $_SESSION["SendTypes"] = $string2;
    // echo "Dakhal fel view";
        require_once 'Case.view.php';
     
    $v=new Cases2();
    $ct_correct=0;
    if(isset($_POST['do1'])){
      $v=new Cases2();
         $TTT = 2;
         if (is_numeric($_POST['casename'])) { 
        //donothing
          
         }
         else{
          $v->b = $_POST['casename'];
          $ct_correct+=1;

         }
         //////////////////////
         if (is_numeric($_POST['feedback'])) { 
          //donothing
            
           }
           else{
            $v->e = $_POST['feedback'];
            $ct_correct+=1;
  
           }
           if (is_numeric( $_POST['caseage'])) {
             if($_POST['caseage']>0)
             {
              $v->d = $_POST['caseage'];
              $ct_correct+=1;


             } 
            
              
             }
            
        
        $v->c = $_POST["Types"];
        $v->f = $_POST['Gender'];
        $v->g1 = $_POST['do1']; 
        echo $ct_correct;
        if($ct_correct==3)
        {
          $userOne= new Cases();
        $userOne->create_new_case($v->b,$v->c,$v->d,$v->e,$v->f);

        }
       
      }

      
 
 



  if($v->g2!='') 
    {
        if($v->b != NULL)
        {
            
            $userOne= new Cases();
            $userOne-> Update_case_name($v->a,$v->b); //------------->update name in db new record
        }
        if($v->c != NULL)
        {
            

            $userOne= new Cases();
            $userOne->Update_case_type($v->a,$v->c);   //------------->update type in db new record

        }
        if($v->d != NULL)
        {
            
            $userOne= new Cases();
            $userOne->Update_case_age($v->a,$v->d);    //------------->update age in db new record
    

        }
        if($v->e !=NULL)
        {
            

            $userOne= new Cases();
            $userOne->Update_case_feedback($v->a,$v->e);  //------------->update feedback in db new record
        }
        if($v->f !=NULL)
        {
            

            $userOne= new Cases();
            $userOne-> Update_case_gender($v->a,$v->f);   //------------->update feedback in db new record
        }

    }



if($v->g3!='') //------------->delete in db new record
{
    
    $userOne= new Cases();
    $userOne-> delete_case($v->a);

}
if($v->g4!='') //------------->view in db new record
{
    if($v->a>0)
    {
    $userOne= new Cases();
    $check2=$userOne->View_case_Information($v->a);
    }
    else
    {
        echo"error";
    }
}


    }

    if(isset($_POST['do80']))
   {
    if (is_numeric( $_POST['case_type']))
     {

       //do nothing

     }
     else
     {
      if($_POST['case_type'] != ' ')
      $rr=$_POST['case_type'];
      $userOne= new Cases();

      $userOne->new_casetype($rr);

       
     }



   }

?>