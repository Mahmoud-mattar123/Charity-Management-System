<?php

require_once 'Case.controller.php';

class Cases3
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;


             //constructor
           public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
           
        }
    }
  


    $v=new Cases2();

    if(isset($_POST['do4'])){
        $v=new Cases2();
        $v->a = $_POST['caseid'];    
        $v->b = $_POST['casename'];
        $v->c = $_POST['casetype'];
        $v->d = $_POST['caseage'];
        $v->e = $_POST['feedback'];         
        $v->f = $_POST['Gender']; 
        $v->g = $_POST['do4']; 
      }
 
 

echo '
<!DOCTYPE HTML>
<html>

<head>
  <style type="text/css">
    .form-style-6{
      font: 95% Arial, Helvetica, sans-serif;
      max-width: 400px;
      margin: 10px auto;
      padding: 16px;
      background: #F7F7F7;
    }
    .form-style-6 h1{
      background: #43D1AF;
      padding: 20px 0;
      font-size: 140%;
      font-weight: 300;
      text-align: center;
      color: #fff;
      margin: -16px -16px 16px -16px;
    }
    .form-style-6 input[type="text"],
    .form-style-6 input[type="date"],
    .form-style-6 input[type="datetime"],
    .form-style-6 input[type="email"],
    .form-style-6 input[type="number"],
    .form-style-6 input[type="search"],
    .form-style-6 input[type="time"],
    .form-style-6 input[type="url"],
    .form-style-6 textarea,
    .form-style-6 select 
    {
      -webkit-transition: all 0.30s ease-in-out;
      -moz-transition: all 0.30s ease-in-out;
      -ms-transition: all 0.30s ease-in-out;
      -o-transition: all 0.30s ease-in-out;
      outline: none;
      box-sizing: border-box;
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      width: 100%;
      background: #fff;
      margin-bottom: 4%;
      border: 1px solid #ccc;
      padding: 3%;
      color: #555;
      font: 130% Arial, Helvetica, sans-serif;
    }
    .form-style-6 input[type="text"]:focus,
    .form-style-6 input[type="date"]:focus,
    .form-style-6 input[type="datetime"]:focus,
    .form-style-6 input[type="email"]:focus,
    .form-style-6 input[type="number"]:focus,
    .form-style-6 input[type="search"]:focus,
    .form-style-6 input[type="time"]:focus,
    .form-style-6 input[type="url"]:focus,
    .form-style-6 textarea:focus,
    .form-style-6 select:focus
    {
      box-shadow: 0 0 5px #43D1AF;
      padding: 3%;
      border: 1px solid #43D1AF;
    }
    
    .form-style-6 input[type="submit"],
    .form-style-6 input[type="button"]{
      box-sizing: border-box;
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      width: 100%;
      padding: 3%;
      background: #43D1AF;
      border-bottom: 2px solid #30C29E;
      border-top-style: none;
      border-right-style: none;
      border-left-style: none;	
      color: #fff;
    }
    .form-style-6 input[type="submit"]:hover,
    .form-style-6 input[type="button"]:hover{
      background: #2EBC99;
    }

    a:link, a:visited {
  background-color: #2EBC99;
  color: white;
  padding: 5px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}

a:hover, a:active {
  background-color: #2EBC99;
}


.button {
  background-color: #2EBC99;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}


.movetype {
  background-color: #2EBC99;
  border: none;
  color: white;
  padding: 10px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
 
 

  
}

body {
  background-color: #8cd98c;

}
    </style>

</head>
<body>
   

  <div class="form-style-6">
    <h1 style="color:rgb(6, 172, 0);">Cases</h1>
<form action="Case.controller.php" method="POST" >
  <table>

   <tr>
    <td>Case name :</td>
    <td><input type="text" name="casename" placeholder="Case name.." required></td>
   </tr>
     <tr>
    <td>Case type :</td>
    <td>
    ';

$count = 1;
  echo '
  <select name="Types" id="Types"> 
  ';
      $array = json_decode( $_SESSION["SendTypes"] , true);
      
      foreach ($array as $arrays)
            {
              $count=$arrays['ID'];
              echo '
              <option value="';echo $count;echo'">';echo $arrays['Type']; echo'</option>
             
              ';
              // $count=$count+1;
              
    
              
            }  
            echo ' 
            </select>
            ';  


  
echo'
  
   </td>
    <tr>
    <td>Case age :</td>
    <td><input id="age" type="text" name="caseage" placeholder="Case age.." required>
    </td>
   </tr>
   <tr>
    <td>Feedback :</td>
    <td><input type="text" name="feedback" placeholder="Feedback.." required></td>
   </tr>
    
    <tr>
    <td>Gender :</td>
    <td>
    <select name="Gender" id="Gender">
    <option value="M">Male</option>
    <option value="F">Female</option>
  </td>
    </select> 
   </tr>
    
<tr>   

   <td><button class="button" class="button onclick="myFunction1() value="do1" name="do1" ">Submit</button></td>

  
<td>
   <div class="movetype">
   <a href="http://localhost/MVC/Case/new_case_ins.php">Create New Case Type</a> 
    </div>
    </td>
</tr>
    <script>
    function myFunction1() {      
    $v=new Cases2();
     
    $v->b = $_POST["casename"];
    $v->c = $_POST["Types"];
    $v->d = $_POST["caseage"];
    $v->e = $_POST["feedback"];         
    $v->f = $_POST["Gender"];      
    $v->g1 = $_POST["do1"];      
    }
    </script>
 
 


  
  
  
   <tr>
   
  <a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>

  <a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
   

   </tr>
   </table> 
   
   

   

   
 </form>
</div>
</body>


</html>
';
if($v->a>0)
{
if($v->g4!='') //------------->view in db new record
{
    
    $userOne= new Cases();
    $check2=$userOne-> View_case_Information($v->a);
    
   echo'<html>
   <head>
   <style>
   table, th, td {
     border: 1px solid black;
   }
   </style>
   </head>
   <body>
   
   <h1>your information is:</h1>
   
   <table>
     <tr>
       <th>id</th>    
       <th>name</th>
       <th>type</th>
       <th>age</th>
       <th>feedback</th>
       <th>gender</th>
     </tr>
     
   </table>
   
   </body>
   </html>';
   echo  $check2;
}
}
?>