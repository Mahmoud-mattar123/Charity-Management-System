<?php

interface Subject 
{
    public function register_observer($User_ID);
    public function remove_observer($User_ID);
    public function notify_observer($Event_ID);
}

?>