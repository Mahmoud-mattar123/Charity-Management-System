<?php

interface Observer 
{
    public function update($event_name,$event_fees,$type);
}

?>