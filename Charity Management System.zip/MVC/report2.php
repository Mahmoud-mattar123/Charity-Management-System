<?php
require_once 'D:/Xamp new/htdocs/MVC/Item Card/item card module.php';
require_once 'D:/Xamp new/htdocs/MVC/Requested Items/Requested_Item_Module.php';
echo'



<!DOCTYPE html>
<html>

<head>
<style>
table, th, td {
  background-color: white;
  border: 1px solid black;
  border-collapse: collapse;
  
}
th, td {
  padding: 20px;
  
}

.tab-2 input{display: block;margin-bottom: 10px}
.tab-2{margin-left: 1000px;margin-bottom: -300px}
tr:hover{background-color:#EEE;cursor: pointer}
tr{transition:all .25s ease-in-out}


body {
  background-color: #8cd98c;

}

</style>
</head>


<body>
<table id="table" style="width:100%">

';

class item_ct
{
  public $item_ID;
  public $ct1;
  public $ct2;
  public function __construct()
        {
            $this->item_ID = 0;
            $this->ct1 = 0;
            $this->ct2 = 0;
        }
}
$itemc= new item_card();
$itarray=array();
$itarray=$itemc->FetchData();//list itemcard
///////////////////////////
$reqi= new requested_items();
$reqarray=array();
$reqarray=$reqi->FetchData();//list req items

   //////////////////////////////////////////////report 2 code
 
 $item_state = array();
foreach ($reqarray as $j =>$a_value)
 {  $ctt=0; $q=0;
	foreach($reqarray as $i => $b_value)
    {   if($a_value->ID==$b_value->ID)
 	    {
 		 $ctt++;
 	    }
    }

foreach ($itarray as $k =>$c_value)
 {


 	if($c_value->item_ID==$a_value->ID)
 	{
 		 $q= $c_value->item_quntity;
 	}

     

 	 
 
 }
     $x = new item_ct(); 
     $x ->ID=  $a_value->ID;
     $x->ct1 = $ctt;
     $x->ct2 = $q;
     array_push($item_state , $x);

}

  foreach($item_state as $i => $i_value) {
  
    echo '<tr><td>';
  	echo "The ID is:";
    echo $i_value->ID;
    echo'</td><td>';
 
     echo "The Quantity is:";

    echo $i_value->ct2;
    echo'</td><td>';

    echo "The Quantity needed from this item is:";

    echo $i_value->ct1;
    echo'</td><td>';

    if($i_value->ct2>$i_value->ct1)
    {
     echo"Item Quantity in good state ";
 
    }
    if($i_value->ct2==$i_value->ct1)
    {
      echo"Item Quantity in average state";
      
    }
    if($i_value->ct2<$i_value->ct1)
    {
      echo"Item Quantity in bad state";
      
    }
    echo'</td>';
 
   }


echo'</table>


   
   </body>
   </html>

';

?>