<!Doctype html>
<html>
<style>
a:link, a:visited {
  background-color: green;
  font-size: 24px;
  width: 50%;
  /* height: 2%; */
  color: white;
  padding: 40px 40px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
 
}

a:hover, a:active {
  background-color: grey;
}
.button1 {
  margin: 0;
  width: 22%;
  
  position: absolute;
  top: 22%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
 
}
.button2 {
  margin: 0;
  position: absolute;
  top: 45%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button3 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 22%;
  left: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button4 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 45%;
  left: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}


.last{
  margin: 0;
  width: 20%;
  position: absolute;
  top: 90%;
  left: 80%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}


.right{
  margin: 0;
  width: 20%;
  position: absolute;
  top: 88%;
  left: 2%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

</style>
<body>

<h1 style="color:rgb(6, 172, 0);">Welcome Manager</h1>
<p>
<div class="button1">
<a href="http://localhost/MVC/Case/Case.view.php">Cases</a>
  </div>

</p>

<p>
<div class="button3">
  <a href="http://localhost/MVC/Item%20Card/item_carde_view.php">Item Card</a>
    </div>
</div>




</p>


<div class="last">
<a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>
</div>


<div class="right">
<a href="http://localhost/MVC/Form2.php">Types Of Report</a>
</div>

</body>
</html>
