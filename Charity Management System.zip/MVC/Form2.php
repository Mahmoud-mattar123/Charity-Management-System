<?php

echo'
<!Doctype html>
<html>

<head>



<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
a:link, a:visited {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  
}
body {
  background-color: #8cd98c;

}

.block {
  display: block;
  width: 100%;
  border: none;
  background-color: #4CAF50;
  color: white;
  padding: 50px 28px;
  font-size: 16px;
  cursor: pointer;
  text-align: center;
}

.block:hover {
  background-color: #ddd;
  color: black;
}


a:link {
  text-decoration: none;
}

a:visited {
  text-decoration: none;
}


a:active {
  text-decoration: underline;
}

</style>
</head>
<body>

<a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>

<div class="block">
<a href="http://localhost/MVC/Date%20Report/Form3%20controller.php"><h1>Date Report</h1></a>
</div>

<div class="block">
  <a href="http://localhost/MVC/report2.php"><h1>Warehouse State Report</h1></a>
    </div>

  

</body>
</html>
';

?>