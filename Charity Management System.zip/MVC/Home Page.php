<!Doctype html>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

</head>


<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 30px 70px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}

div.c {
  font-size: 250%;
  color: white;
}

.mySlides {display:none;}


.w3-btn {width:150px;}


.move1 {
position: absolute;
  top: 90%;
  right: 55%;
}

.move2 {
position: absolute;
  top: 90%;
  right: 40%;
}

h1 {
  text-align: center;
}

hr {

 
  width:10%;
  height:5px;
  border-width:20;
  color:gray;
  background-color:green;
  margin-left:45%;
}


div.a {
  text-align: center;
}



</style>
<body>



<div class="w3-container">

<div class="move1">
<p><button class="w3-button w3-green w3-round-xxlarge">DONATE NOW</button>
</div>

<div class="move2">
<p><button class="w3-button w3-green w3-round-xxlarge">CONTACT US</button>
</div>


</div>


<ul>

<div class="c"><li>  Charity Organization<li ></div>
<li style="float:right"><a class="active" href="http://localhost/MVC/User/Module/Login.php">Sign In</a></li>
  <li  style="float:right"><a href="http://localhost/MVC/Event/edit_page.php">About</a></li>
  <li  style="float:right"><a href="#contact">Contact</a></li>
  <li  style="float:right"><a href="#news">News</a></li>
  <li style="float:right"><a class="active" href="#home">Home</a></li>
</ul>


<div class="w3-content" style="max-width:100%">
<img class="mySlides" src="main.jpg" style="width:100%">
  <img class="mySlides" src="1.jpg" style="width:100%">
  <img class="mySlides" src="3.jpg" style="width:100%">
  <img class="mySlides" src="2.jfif" style="width:100%">
</div>

<div class="w3-center">
  <div class="w3-section">
    <button class="w3-button w3-light-grey" onclick="plusDivs(-1)">❮ Prev</button>
    <button class="w3-button w3-light-grey" onclick="plusDivs(1)">Next ❯</button>
  </div>
  <button class="w3-button demo" onclick="currentDiv(1)">1</button> 
  <button class="w3-button demo" onclick="currentDiv(2)">2</button> 
  <button class="w3-button demo" onclick="currentDiv(3)">3</button> 
  <button class="w3-button demo" onclick="currentDiv(4)">4</button> 
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" w3-green", "");
  }
  x[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " w3-green";
}
</script>

<br><br>
<h1><B>OUR ACTIVTY<B></h1>
<hr>
<div class="a">
<h3>This country will not be a good place for any of us to live in unless we make it a good place for all of us to live in.</h3>
</div>
</body>
</html>
