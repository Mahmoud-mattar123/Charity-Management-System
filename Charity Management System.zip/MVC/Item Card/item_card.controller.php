<?php
ob_start();
session_start();

require_once 'item card module.php';
require_once 'item_carde_view.php';



class item_card2
    {
      public $a;
      public $b;
      public $c;
      public $d;
      public $e;
      public $f;
      public $g;
      public $h;
      public $n;
      public $y;
      public $k;
      public $q;
      public $v;
      public $i;
      public $trns_id;
      public $trns;
      public $switch;
      public $aa;
      public $bb;
      public $cc;
      public $dd;
      public $ee;
      public $ff;
      public $gg;
      public $hh;
      public $nn;
      public $RowNmuber;

             //constructor
           public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g =NULL;
            $this->h=NULL;
            $this->n=NULL;
            $this->k=NULL;
            $this->y=NULL;
            $this->q=NULL;
            $this->v=NULL;
            $this->i=NULL;
            $this->trns_id=NULL;
            $this->trns=NULL;
            $this->switch=NULL;
            $this->aa =NULL;
            $this->bb =NULL;
            $this->cc =NULL;
            $this->dd =NULL;
            $this->ee =NULL;
            $this->ff =NULL;
            $this->gg =NULL;
            $this->hh=NULL;
            $this->nn=NULL;
            $this->RowNmuber=NULL;
        }
    }

$VARIABLE= new item_card2();
$v=new item_card3();
$ct_correct=0;
  if(isset($_POST['Invoice']))
  {
    $VARIABLE->switch=2;
    $v=new item_card2();
    $v->trns = $_POST["Trans_ID2"];      
    $itemc= new item_card();       
    $arrayinvoice=$itemc->Fetch_invoice_tran_id($v->trns);
    $string = json_encode($arrayinvoice);
    $_SESSION["arrayinvoice"]=$string;
    header("Location:Invoice.php");
  }
//////////////////////

if(isset($_POST['Insert'])){
  if (is_numeric( $_POST["Item_Name"])) { 
  
  //donothing
  }
    else{

      $ct_correct+=1;
    }
    
   

   if (is_numeric( $_POST["item_quntity"])) { 
    if($_POST["item_quntity"]>=0)
    {
      $ct_correct+=1;
    }
 
    
   }
   if (is_numeric( $_POST["incoming"])) { 
    if($_POST["incoming"]>=0)
    {
      $ct_correct+=1;
    }
   
    
   }
   if (is_numeric( $_POST["outgoing"])) { 
    if($_POST["outgoing"]>=0)
    {
      $ct_correct+=1;
    }
   
    
   }
   if (is_numeric( $_POST["note"])) { 
    
      //donothing
   }
    else{

      $ct_correct+=1;
    }
    
   
   if (is_numeric( $_POST["Trans_ID"])) { 
    if($_POST["Trans_ID"]>0)
    {
      $ct_correct+=1;
    }
   
    
   }
   if (is_numeric( $_POST["WarehouseID"])) { 
    if($_POST["WarehouseID"]>0)
    {
      $ct_correct+=1;
    }
    
    
   }
   
    
   





   if($ct_correct==7){
    $itemc= new item_card();
    $itemc->set_Item_ID(  $_POST["Item_Name"]);
    $itemc->set_item_amount($_POST["item_quntity"]);
    $itemc->set_incoming( $_POST["incoming"]);
    $itemc->set_outgoing( $_POST["outgoing"]);
    $itemc->set_date_of_item(  $_POST["date_of_today"]);  
    $itemc->set_note( $_POST["note"]);
    $itemc->set_trns_id( $_POST["Trans_ID"]);
    $itemc->set_warehouse_id(  $_POST["WarehouseID"]);
    $itemc->insert_in_db();

  }
 
}









?>