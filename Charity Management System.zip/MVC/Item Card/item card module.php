
<?php
 

////////////////////////////////////////////////////////////////////////////////////////////oop work

class item_card
 {
  // Properties
  public     $item_ID;
  public     $item_quntity;
  public     $Name;
  public     $incoming;
  public     $outgoing;
  public     $dmy;
  public     $note;
  public     $trns_id;
  public     $warehouse_id;
  public     $ID;
  // Methods
  public     $RowNmuber;
                            // $IC->item_quntity = $row['Quantity'];
                            //  $IC->incoming = $row['Incoming'];
                            //  $IC->outgoing = $row['Outgoing'];
                            //  $IC->dmy = $row['DateOfTransc.'];
                            //  $IC->note = $row['Note'];
                            //  $IC->trns_id = $row['Trans_ID'];
                            //  $IC->Warehouse_ID = $row['Warehouse_ID'];
    

  //////////////////////////////sets
          public function __construct()
        {
            $this->item_ID = NULL;
            $this->item_quntity = NULL;
            $this->Name=NULL;
            $this->incoming = NULL;
            $this->outgoing = NULL;
            $this->dmy = NULL;
            $this->note = NULL;
            $this->warehouse_id=NULL;
            $this->trns_id=NULL;
            $this->ID=NULL;
        }
public function set_Name($Name)
{
    $this->Name =$Name;
}
public function set_warehouse_id($warehouse_id)
{
    $this->warehouse_id = $warehouse_id;
}

 public function set_Item_ID($item_ID)
  {        
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    $sql ="SELECT * FROM `items` WHERE `Name`='$item_ID'";
    $result = mysqli_query($link,$sql);
        while ($row = mysqli_fetch_assoc($result))
        {

            $this->item_ID = $row['ID']; 
           
            
        }
   
  
  }
 public function set_item_amount($item_quntity)                   
  {
     
    $this->item_quntity = $item_quntity;
  }
 public function set_incoming($incoming)
  {
    
    $this->incoming = $incoming;
  }
 public function set_outgoing($outgoing)
  {
   
    $this->outgoing = $outgoing;
  }
 public function set_date_of_item($dmy)
  {
     
    $this->dmy = $dmy;
  }
 public function set_note($note)
  {
     
    $this->note = $note;
  }

  public function set_trns_id($trns_id)
  {
     
    $this->trns_id = $trns_id;
  }
  public function set_ID($ID)
  {
     
    $this->ID = $ID;
  }
  ///////////////////gets   
 public function get_Item_ID () 
  {  
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->item_ID=$row['ID']; 

                            
                        }
                    }
    //return $this->item_ID;
  }
 public function get_Item_amount () 
  {
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 )
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {

                            $this->item_quntity=$row['Quantity']; 
                           

                        }
                    }
    //return $this->item_quntity;
  }
  public function get_incoming () 
  {
     $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->incoming=$row['Incoming']; 
                 
                            
                        }
                    }
  }
  public function get_outgoing () 
  {$link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->outgoing=$row['Outgoing']; 

                            
                        }
                    }
   
  }
  public function get_date_of_item () 
  {
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->date_of_item=$row['DateOfTransc']; 

                            
                        }
                    }
   
  }
  public function get_note () 
  {
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 )
                    {
                        while ($row = mysqli_fetch_assoc($result)){

                        
                            $this->note=$row['Note']; 

                            
                        }
                    }
   
  }
  public function get_warehouse_id()
{
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    //  return $this->casename; 
    $sql ="SELECT * FROM `item card`";
        $result = mysqli_query($link,$sql);
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 ){
            while ($row = mysqli_fetch_assoc($result)){

            
                $this->warehouse_id=$row['Warehouse_ID']; 

                
            }
}

}
public function get_Name()
{
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    //  return $this->casename; 
    $sql ="SELECT * FROM `item card`";
        $result = mysqli_query($link,$sql);
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 ){
            while ($row = mysqli_fetch_assoc($result)){

            
                $this->Name=$row['Name']; 

                
            }
}
}










public function get_trns_id()
{
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    //  return $this->casename; 
    $sql ="SELECT * FROM `item card`";
        $result = mysqli_query($link,$sql);
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 ){
            while ($row = mysqli_fetch_assoc($result)){

            
                $this->trns_id=$row['Trans_ID']; 

                
            }
}
}


















public function get_ID()
{
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    //  return $this->casename; 
    $sql ="SELECT * FROM `item card`";
        $result = mysqli_query($link,$sql);
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 ){
            while ($row = mysqli_fetch_assoc($result)){

            
                $this->ID=$row['ID']; 

                
            }
}
}
  ///logical function
 public function feedback () 
  {
    //////............get all info about one item only
  }
   public function insert_in_db() 
  {
    
     
       $link = mysqli_connect("localhost", "root", "", "whmang");
 
              if($link === false){
                  die("ERROR: Could not connect. " . mysqli_connect_error());
              }
                    // Attempt insert query execution
                 $sql = "INSERT INTO `item card`(`Item_ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`,`Trans_ID`,`Warehouse_ID`) VALUES ('$this->item_ID','$this->item_quntity','$this->incoming','$this->outgoing','$this->dmy','$this->note','$this->trns_id','$this->warehouse_id ')";

                 if(mysqli_query($link, $sql)){
                    echo "item inserted successfully.";
                 } else{
                    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                 } 



       
     }
    
     
     public function Update_Name($Item_ID,$Name)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET `Name`='$Name' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     }
     public function Update_Quantity($Item_ID,$item_quntity)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET Quantity='$item_quntity' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     }
     public function Update_incoming($Item_ID,$incoming)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET Incoming='$incoming' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     }  
        public function Update_outgoing($Item_ID,$outgoing)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET Outgoing='$outgoing' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     } 
         public function Update_DateofTrasc($Item_ID,$dmy)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET `DateOfTransc.`='$dmy' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     }  
        public function Update_note($Item_ID,$note)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET `Note`='$note' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     }    
      public function Update_warehouse_id($Item_ID,$warehouse_id)
     {
         $link = mysqli_connect("localhost", "root", "", "whmang");

         // Check connection
         if($link === false){
             die("ERROR: Could not connect. " . mysqli_connect_error());
         }

       
        $sql =" UPDATE `item card` SET Warehouse_ID='$warehouse_id' WHERE `ID`='$Item_ID'";



        if(mysqli_query($link, $sql)){
         echo "Records Updated successfully.";
         } 
         else{
         echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
         }
     }    
     
      public function delete_record($Item_ID)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
  {
    
     
       $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


               $sql =" DELETE FROM `item card`  WHERE ID='$Item_ID'";



               if(mysqli_query($link, $sql)){
                echo "Records deleted successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }


       
     }
     public function search_and_view($Item_ID)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
  {/*SELECT * FROM Customers
WHERE Country='Mexico';
*/
    
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false)
                {
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT * FROM `item card` WHERE ID='$Item_ID'";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                             $this->item_ID=$row['ID']; 
                           
                             $this->item_quntity=$row['Quantity']; 
                             $this->incoming=$row['Incoming']; 
                             $this->outgoing=$row['Outgoing'];
                             $this->dmy=$row['DateOfTransc.'];

                             $this->trns_id=$row['Trans_ID'];
                        
                            
                             $this->note=$row['Note']; 
                             $this->warehouse_id=$row['Warehouse_ID']; 
                        }
                    }
         
       
     }





     public function FetchData()
     {
       $IcArray = array();
 
       $link = mysqli_connect("localhost", "root", "", "whmang");
  
       // Check connection
       if($link === false){
           die("ERROR: Could not connect. " . mysqli_connect_error());
       }
 
           $sql ="SELECT * FROM `item card`";
                     $result = mysqli_query($link,$sql);
 
                     if(mysqli_num_rows($result) > 0)
                     {
                         while ($row = mysqli_fetch_assoc($result))
                         {
                             $IC = new item_card(); 
 
                             $IC->item_ID = $row['ID'];                             
                             $IC->item_quntity = $row['Quantity'];
                             $IC->incoming = $row['Incoming'];
                             $IC->outgoing = $row['Outgoing'];
                             $IC->dmy = $row['DateOfTransc.'];
                             $IC->trns_id = $row['Trans_ID'];
                             $IC->note = $row['Note'];
                             $IC->Warehouse_ID = $row['Warehouse_ID']; 
 
                             array_push($IcArray , $IC);
                         }
                     } 
                   
                    
                     echo "<br>";
                     //echo "This Should be the statement before the return ";
                    return $IcArray;
 
       // echo "<br>";
       // print_r($IcArray);
     }








     public function view_Row_Number($trns_id)  
     {
       
       $link = mysqli_connect("localhost", "root", "", "whmang");
    
                   // Check connection
                   if($link === false)
                   {
                       die("ERROR: Could not connect. " . mysqli_connect_error());
                   }
   
   
                   //  return $this->casename; 
                   $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                       $result = mysqli_query($link,$sql);
                           while ($row = mysqli_fetch_assoc($result))
                           {
                            
                              return  $row['ID']; 
                              
                               
                           }
    }
            
          
        

        public function view_Item_ID($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
     {/*SELECT * FROM Customers
   WHERE Country='Mexico';
   */
       
       $link = mysqli_connect("localhost", "root", "", "whmang");
    
                   // Check connection
                   if($link === false)
                   {
                       die("ERROR: Could not connect. " . mysqli_connect_error());
                   }
   
   
                   //  return $this->casename; 
                   $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                       $result = mysqli_query($link,$sql);
                       $resultCheck = mysqli_num_rows($result);
                       if( $resultCheck >0 ){
                           while ($row = mysqli_fetch_assoc($result))
                           {
                            $rec=$row['Item_ID'];
                            $sql2 ="SELECT * FROM `items` WHERE ID='$rec'";
                            $result = mysqli_query($link,$sql2);
                            while ($row2 = mysqli_fetch_assoc($result))
                            {
                                return $row2['Name'];
                            }
                               
                           }
                       }
            
          
        }


        public function view_Quantity($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
        {/*SELECT * FROM Customers
      WHERE Country='Mexico';
      */
          
          $link = mysqli_connect("localhost", "root", "", "whmang");
       
                      // Check connection
                      if($link === false)
                      {
                          die("ERROR: Could not connect. " . mysqli_connect_error());
                      }
      
      
                      //  return $this->casename; 
                      $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                          $result = mysqli_query($link,$sql);
                          $resultCheck = mysqli_num_rows($result);
                          if( $resultCheck >0 ){
                              while ($row = mysqli_fetch_assoc($result)){
      
   
                               
                                 return  $row['Quantity']; 
                                 
                                  
                              }
                          }
               
             
           }







           
        public function view_Incoming($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
        {/*SELECT * FROM Customers
      WHERE Country='Mexico';
      */
          
          $link = mysqli_connect("localhost", "root", "", "whmang");
       
                      // Check connection
                      if($link === false)
                      {
                          die("ERROR: Could not connect. " . mysqli_connect_error());
                      }
      
      
                      //  return $this->casename; 
                      $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                          $result = mysqli_query($link,$sql);
                          $resultCheck = mysqli_num_rows($result);
                          if( $resultCheck >0 ){
                              while ($row = mysqli_fetch_assoc($result)){
      
   
                               
                                 return  $row['Incoming']; 
                                 
                                  
                              }
                          }
               
             
           }





           public function view_Outgoing($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
           {/*SELECT * FROM Customers
         WHERE Country='Mexico';
         */
             
             $link = mysqli_connect("localhost", "root", "", "whmang");
          
                         // Check connection
                         if($link === false)
                         {
                             die("ERROR: Could not connect. " . mysqli_connect_error());
                         }
         
         
                         //  return $this->casename; 
                         $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                             $result = mysqli_query($link,$sql);
                             $resultCheck = mysqli_num_rows($result);
                             if( $resultCheck >0 ){
                                 while ($row = mysqli_fetch_assoc($result)){
         
      
                                  
                                    return  $row['Outgoing']; 
                                    
                                     
                                 }
                             }
                  
                
              }
   

              public function view_Date_Of_Tans($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
              {/*SELECT * FROM Customers
            WHERE Country='Mexico';
            */
                
                $link = mysqli_connect("localhost", "root", "", "whmang");
             
                            // Check connection
                            if($link === false)
                            {
                                die("ERROR: Could not connect. " . mysqli_connect_error());
                            }
            
            
                            //  return $this->casename; 
                            $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                                $result = mysqli_query($link,$sql);
                                $resultCheck = mysqli_num_rows($result);
                                if( $resultCheck >0 ){
                                    while ($row = mysqli_fetch_assoc($result)){
            
         
                                     
                                       return  $row['DateOfTransc.']; 
                                       
                                        
                                    }
                                }
                     
                   
                 }




                 public function view_Note($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
                 {/*SELECT * FROM Customers
               WHERE Country='Mexico';
               */
                   
                   $link = mysqli_connect("localhost", "root", "", "whmang");
                
                               // Check connection
                               if($link === false)
                               {
                                   die("ERROR: Could not connect. " . mysqli_connect_error());
                               }
               
               
                               //  return $this->casename; 
                               $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                                   $result = mysqli_query($link,$sql);
                                   $resultCheck = mysqli_num_rows($result);
                                   if( $resultCheck >0 ){
                                       while ($row = mysqli_fetch_assoc($result)){
               
            
                                        
                                          return  $row['Note']; 
                                          
                                           
                                       }
                                   }
                        
                      
                    }







                    public function view_Trans_ID($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
                    {/*SELECT * FROM Customers
                  WHERE Country='Mexico';
                  */
                      
                      $link = mysqli_connect("localhost", "root", "", "whmang");
                   
                                  // Check connection
                                  if($link === false)
                                  {
                                      die("ERROR: Could not connect. " . mysqli_connect_error());
                                  }
                  
                  
                                  //  return $this->casename; 
                                  $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                                      $result = mysqli_query($link,$sql);
                                      $resultCheck = mysqli_num_rows($result);
                                      if( $resultCheck >0 ){
                                          while ($row = mysqli_fetch_assoc($result)){
                  
               
                                           
                                             return  $row['Trans_ID']; 
                                             
                                              
                                          }
                                      }
                           
                         
                       }
   






                    public function view_Warehouse_ID($trns_id)  //`ID`, `Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`
                    {/*SELECT * FROM Customers
                  WHERE Country='Mexico';
                  */
                      
                      $link = mysqli_connect("localhost", "root", "", "whmang");
                   
                                  // Check connection
                                  if($link === false)
                                  {
                                      die("ERROR: Could not connect. " . mysqli_connect_error());
                                  }
                  
                  
                                  //  return $this->casename; 
                                  $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                                      $result = mysqli_query($link,$sql);
                                      $resultCheck = mysqli_num_rows($result);
                                      if( $resultCheck >0 ){
                                          while ($row = mysqli_fetch_assoc($result)){
                  
               
                                           
                                             return  $row['Warehouse_ID']; 
                                             
                                              
                                          }
                                      }
                           
                         
                       }
                 

   /////////////////////////////////////////////////////////////////////////////////////////////
   public function Fetch_invoice_tran_id($trns_id)
     {
       $IcArray = array();
 
       $link = mysqli_connect("localhost", "root", "", "whmang");
  
       // Check connection
       if($link === false){
           die("ERROR: Could not connect. " . mysqli_connect_error());
       }
 
           $sql ="SELECT * FROM `item card` WHERE Trans_ID='$trns_id'";
                     $result = mysqli_query($link,$sql);
 
                     if(mysqli_num_rows($result) > 0)
                     {
                         while ($row = mysqli_fetch_assoc($result))
                         {
                             $IC = new item_card(); 
 
                           
                             ///////////////////////////////////
                             $IC->item_ID = $row['ID'];


                             $rec = $row['Item_ID'];
                             $sql2 ="SELECT * FROM `items` WHERE ID='$rec'";
                             $result2 = mysqli_query($link,$sql2);
                                while ($row2 = mysqli_fetch_assoc($result2))
                                  {
                                      $IC->Name = $row2['Name'];
                                  }

                             $IC->item_quntity = $row['Quantity'];
                             $IC->incoming = $row['Incoming'];
                             $IC->outgoing = $row['Outgoing'];
                             $IC->dmy = $row['DateOfTransc.'];
                             $IC->note = $row['Note'];
                             $IC->trns_id = $row['Trans_ID'];
                             $IC->Warehouse_ID = $row['Warehouse_ID']; 
 
                             array_push($IcArray , $IC);
                         }
                     } 
                   
                    
                     echo "<br>";
                     //echo "This Should be the statement before the return ";
                    return $IcArray;
 
       // echo "<br>";
       // print_r($IcArray);
     }
























}
    
 
    
?>
   
