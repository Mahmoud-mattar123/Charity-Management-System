<?php

session_start();

class item_card4
    {
      public $a;
      public $b;
      public $c;
      public $d;
      public $e;
      public $f;
      public $g;
      public $h;
      public $n;
      public $y;
      public $k;
      public $q;
      public $v;
      public $i;
      public $trns_id;
      public $trns;
      public $aa;
      public $bb;
      public $cc;
      public $dd;
      public $ee;
      public $ff;
      public $gg;
      public $hh;
      public $nn;
   

             //constructor
           public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g =NULL;
            $this->h=NULL;
            $this->n=NULL;
            $this->k=NULL;
            $this->y=NULL;
            $this->q=NULL;
            $this->v=NULL;
            $this->i=NULL;
            $this->trns_id=NULL;
            $this->trns=NULL;
            $this->aa =NULL;
            $this->bb =NULL;
            $this->cc =NULL;
            $this->dd =NULL;
            $this->ee =NULL;
            $this->ff =NULL;
            $this->gg =NULL;
            $this->hh=NULL;
            $this->nn=NULL;
           ;
        }
    }

    //$arrayinvoice=$_SESSION["arrayinvoice"];
    




 
echo'
<!Doctype html>
<html>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 10px;
}
.Head {
position: absolute;
  left:40%;
}
.line {
position: absolute;
  left:25%;
}
.line2 {
position: absolute;
  left:0%;
}

.right{
  position: absolute;
  left:90%;
}

.left{
  position: absolute;
  left:0%;
}


.btn-group .button {
  background-color: rgb(102, 255, 153); /* Green */
  border: 1px solid green;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  font-size: 16px;
  cursor: pointer;
  width: 150px;
  display: block;
}

.btn-group .button:not(:last-child) {
  border-bottom: none; /* Prevent double borders */
}

.btn-group .button:hover {
  background-color: #3e8e41;
}


</style>




<body>


<form action="item_card.controller.php" method="POST" >

  <div class="Head">
    <h1> Item Card Invoice </h1>
 </div>

<br>
<br>
<br>

    <div2 class="line">

    <h2>______________________________________________________</h2>
    </div2>

    
<br>
<br>
<br>

    <p>Row Number is:</p>';
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['item_ID']; 
                  echo '<br>';              
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>
        
<br>
<br>
<br>

    <p>Item Name:</p>';
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['Name'];
                  echo '<br>';  
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>

            
<br>
<br>
<br>

    <p>Quantity is:</p>';
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['item_quntity'];     
                  echo '<br>';    
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>


            
<br>
<br>
<br>

    <p>Incoming is:</p>';
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['incoming'];
                  echo '<br>';
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>


<br>
<br>
<br>

    <p>Outgoing is:</p>';
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['outgoing'];
                  echo '<br>';
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>



    <br>
<br>
<br>

    <p>Date Of the Transaction is:</p>';
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['dmy'];
                  echo '<br>';
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>


    <br>
<br>
<br>

    <p>Note:</p>';
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['note'];
                  echo '<br>';
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>


    <br>
<br>
<br>

    <p>The Transaction ID is:</p>';
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['trns_id'];
                  echo '<br>';
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>


    <br>
<br>
<br>

    <p>Warehouse ID is:</p>';
    
    
    if(isset($_SESSION["arrayinvoice"])){

      $arrayinvoice = json_decode( $_SESSION["arrayinvoice"] , true);  
          foreach ($arrayinvoice as $arrays)
          {
              echo '<tr><td>';
                  echo $arrays['Warehouse_ID'];
                  echo '<br>';
                  echo'</td>';                  
                  echo'</tr>';
          }
    }
    echo '
    <p>______________________________</p>


    <div2 class="line2">


<h2>____________________________________________________________________________________________________________________________________________________________________________</h2>
</div2>
    
<br>
<br>

<div2 class="right">
<p>Page 1 of 1</p>
</div2>


<div2 class="left">
<p>Receipt in Full</p>
</div2>
</form>

</body>



</html>
';



// if ($v->trns_id !='')
// {
//   $itemc= new item_card();
//   $RowNmuber=$itemc->view_Row_Number($trns);
//   $ItemID=$itemc->view_Item_ID($trns);
//   $Quantity=$itemc->view_Quantity($trns);
//   $Incoming=$itemc->view_Incoming($trns);
//   $Outgoing=$itemc->view_Outgoing($trns);
//   $Dateoftrns=$itemc->view_Date_Of_Tans($trns);
//   $Note=$itemc->view_Note($trns);
//   $TransID=$itemc->view_Trans_ID($trns);
//   $WarehouseID=$itemc->view_Warehouse_ID($trns);

//   echo $Quantity;
// }



?>