<?php

require_once 'item_card.controller.php';

class item_card3
    {
      public $a;
      public $b;
      public $c;
      public $d;
      public $e;
      public $f;
      public $g;
      public $h;
      public $n;
      public $y;
      public $k;
      public $q;
      public $i;
      public $trns_id;
      public $trns;


             //constructor
           public function __construct()
           {
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g =NULL;
           $this->h=NULL;
           $this->n=NULL;
            $this->k=NULL;
            $this->y=NULL;
            $this->q=NULL;
            $this->i=NULL;
            $this->trns_id=NULL;
            $this->trns=NULL;
        }
    }

   
     



    // if(isset($_POST['do'])){
    //   $v=new item_card2();
    //   $v->a = $_POST["item_quntity"];    
    //   $v->b = $_POST["incoming"];
    //   $v->c = $_POST["outgoing"];
    //   $v->d = $_POST["date_of_today"];
    //   $v->e = $_POST["note"];         
    //   $v->f = $_POST["do"]; 
    //   $v->g = $_POST["to_do"]; 
    // }

echo '
<html>

<head>

</head>

   






<style>

body {
  background-color: #8cd98c;

}

input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.btn-group .button {
  background-color: rgb(102, 255, 153); /* Green */
  border: 1px solid green;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  font-size: 16px;
  cursor: pointer;
  width: 150px;
  display: block;
}

.btn-group .button:not(:last-child) {
  border-bottom: none; /* Prevent double borders */
}

.btn-group .button:hover {
  background-color: #3e8e41;
}

input[type=submit] {
  width: 100%;
  background-color: rgb(102, 255, 153);
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: rgb(102, 255, 153);
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
 
}
a:link, a:visited {
  background-color: rgb(102, 255, 153);
  color: white;
  padding: 12px 58px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}

a:hover, a:active {
  background-color: rgb(102, 255, 153);
}


.button1 {
  position: absolute;
  left:80%;
  top:98%;
}

.movee{
  position: absolute;
  top: 50%;
  left: 70%;
}


.movee2{
  position: absolute;
  top: 59%;
  left: 80%;
}


</style>



























<body>

<div>
<h1 style="color:rgb(102, 255, 153);">Item Card</h1>

<form action="item_card.controller.php" method="POST" >
  <table>
  </tr>
  <tr>
  <td>Item Name:</td>
  <td><input type="value" name="Item_Name" ></td>
 </tr>
   <tr>
    <td>Item Quantity :</td>
    <td><input type="value" name="item_quntity" ></td>
   </tr>

   <tr>
    <td>Incoming :</td>
    <td><input type="value" name="incoming" ></td>
   </tr>
     <tr>
    <td>Outgoing :</td>
    <td><input type="value" name="outgoing" ></td>
   </tr>
    <tr>
    <td>Date of today :</td>
    <td><input type="date" name="date_of_today" ></td>
   </tr>
   <tr>
    <td>Note :</td>
    <td><input type="text" name="note" ></td>
   </tr>
   <tr>
   <td>Transaction ID : </td>
   <td><input type="value" name="Trans_ID" ></td>
  </tr>
   <tr>
    <td>Warehouse ID :</td>
    <td><input type="value" name="WarehouseID" ></td>
   </tr>
   
  <tr>

 
  

   </tr>
<td>



   <div class="btn-group">
  <button class="button onclick="myFunction() value="Insert" name="Insert" ">Insert</button>
</div>
<td>

<div class="movee2">
<div class="btn-group">
<button class="button onclick="myFunction5() value="Invoice" name="Invoice">Invoice</button>
</div>
</div>
</td>
</td>

   <tr>
   <a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
  <a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>

   

   </tr>

<div class="movee">
   
   Transaction Number : 
   <input type="value" name="Trans_ID2"  >
  
</div>


   </table> 
   




   
   <script>
   function myFunction() {

      $v=new item_card2();
       $v->a = $_POST["item_quntity"];    
      $v->b = $_POST["incoming"];
      $v->c = $_POST["outgoing"];
      $v->d = $_POST["date_of_today"];
      $v->e = $_POST["note"];    
      $v->h=  $_POST["WarehouseID"]   ;  
      $v->i = $_POST["Item_Name"];  
      $v->f = $_POST["Insert"]; 
      
    
   }
   </script>
   <script>
   function myFunction2() {

      $v=new item_card2();
      $v->g = $_POST["to_do"]; 
      $v->k=$_POST["Delete"];
    
   }
   </script>
   <script>
   function myFunction3() {

      $v=new item_card2();
      $v->g = $_POST["to_do"];
      $v->n=$_POST["Name"];
      $v->a = $_POST["item_quntity"];    
      $v->b = $_POST["incoming"];
      $v->c = $_POST["outgoing"];
      $v->d = $_POST["date_of_today"];
      $v->e = $_POST["note"];    
      $v->h=  $_POST["WarehouseID"];  
      $v->q=$_POST["Update"];
    
   }
   </script>
   <script>
   function myFunction4() {

      $v=new item_card2();
      $v->g = $_POST["to_do"]; 
      $v->y=$_POST["Search"];
    
   }
   </script>
 
   <script>
   function myFunction5() 
   {

      $v=new item_card2();
      
      $v->trns = $_POST["Trans_ID2"]; 
      $v->trns_id = $_POST["Invoice"];
      
    
   }
   </script>

  


     


   
 </form>
 </div>
</body>


</html>
';





?>