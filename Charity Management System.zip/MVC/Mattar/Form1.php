<!DOCTYPE HTML>
<html>

<head>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
 
}
a:link, a:visited {
  background-color: #45a049;
  color: white;
  padding: 12px 58px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}

a:hover, a:active {
  background-color: #45a049;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}



</style>



</head>
<body>
   
   
    <div>
      <h1 style="color:rgb(6, 172, 0);">Requsted Items</h1>
<form action="Requested_Item_Controller.php" method="POST" >
  <table>
   <tr>
    <td>Item ID </td>
    <td><input type="text" name="Reqid" placeholder="Your id.." ></td>
   </tr>

   <tr>
    <td>Requsted Type </td>
    <td><input type="text" name="Reqtype" placeholder="Your type.."></td>
   </tr>
     <tr>
    <td>Requsted Sender Name </td>
    <td><input type="text" name="Reqsendername" placeholder="Sender name.."></td>
   </tr>
    <tr>
    <td>Requsted Sender ID </td>
    <td><input type="text" name="Reqsenderid" placeholder="Sender id.."></td>
   </tr>
   <tr>
    <td>Is Accepted </td>
    <td><input type="text" name="isaccepted" placeholder="Is accepted.." ></td>
   </tr>
  <tr>
 



  


  <td><button class="button" class="button onclick="myFunction1() value="do1" name="do1" ">Insert</button></td>
  <td><button class="button" class="button onclick="myFunction3() value="do3" name="do3" ">Delete</button></td>

   </tr>

   <tr>

   <td><button class="button" class="button onclick="myFunction2() value="do2" name="do2" ">Update</button></td>
   <td><button class="button" class="button onclick="myFunction4() value="do4" name="do4" ">View</button></td>
 


   
   </tr>



   <script>
   function myFunction1() {
   $v=new requested_items2();        
    $v->a = $_POST["Reqid"];    
     $v->b = $_POST["Reqtype"];
     $v->c = $_POST["Reqsendername"];
     $v->d = $_POST["Reqsenderid"];
     $v->e = $_POST["isaccepted"];         
     $v->g1 = $_POST["do1"];      
   }
   </script>


   <script>
   function myFunction3() {
   $v=new requested_items2();        
    $v->a = $_POST["Reqid"];    
     $v->b = $_POST["Reqtype"];
     $v->c = $_POST["Reqsendername"];
     $v->d = $_POST["Reqsenderid"];
     $v->e = $_POST["isaccepted"];         
     $v->g3 = $_POST["do3"];      
   }
   </script>


   <script>
   function myFunction2() {
   $v=new requested_items2();        
    $v->a = $_POST["Reqid"];    
     $v->b = $_POST["Reqtype"];
     $v->c = $_POST["Reqsendername"];
     $v->d = $_POST["Reqsenderid"];
     $v->e = $_POST["isaccepted"];         
     $v->g2 = $_POST["do2"];      
   }
   </script>



   <script>
   function myFunction4() {
   $v=new requested_items2();        
    $v->a = $_POST["Reqid"];    
     $v->b = $_POST["Reqtype"];
     $v->c = $_POST["Reqsendername"];
     $v->d = $_POST["Reqsenderid"];
     $v->e = $_POST["isaccepted"];         
     $v->g4 = $_POST["do4"];      
   }
   </script>




   <a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>
   </table>

   
  
   


 </form>
    </div>
</body>


</html>