<?php 

require_once 'D:/Xamp new/htdocs/MVC/Database.php';
require_once 'D:/Xamp new/htdocs/MVC/Items/Items.Model.php';
require_once 'D:/Xamp new/htdocs/MVC/Case/Case.php';
require_once 'D:/Xamp new/htdocs/MVC/CaseType/CaseType.php';
require_once 'D:/Xamp new/htdocs/MVC/Brand/Brand.php';

class requested_items
    {
        public $ID;
        public $ItemID;
        public $ItemName;
        public $CaseID;
        public $CaseName;
        public $CaseType;
        public $BrandID;
        public $BrandName;
        public $TransID;
        public $IsAccepted;

            
             //constructor
        public function __construct(){
            $this->ID =NULL;
            $this->ItemID =NULL;
            $this->CaseID =NULL;
            $this->TransID =NULL;
            $this->IsAccepted =NULL;
            $this->ItemName =NULL;
            $this->CaseName =NULL;
            $this->CaseType =NULL;
            $this->BrandName =NULL;
            $this->BrandID =NULL;                 
        }


         ////////////////////////////////////////////////


         //setters
         //getters


        public function setreqid($ID)
        {           
            $this->ID=$ID;
        }
         
 
        public function getreqid()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items`";
            $result = $mysqli->query($sql_query);                          
                    
            while ($row = mysqli_fetch_assoc($result)){
                echo $this->ID=$row['ID'];
                echo "<br>";
            }                                 
        }

        public function setReqType($ReqType)
        {
            $this->ReqType=$ReqType;     
        }
 
        public function getReqType()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items`";
            $result = $mysqli->query($sql_query);
                    
            while ($row = mysqli_fetch_assoc($result)){
                echo $this->ReqType=$row['ReqType'];
                echo "<br>";
            }                                 
        }

        public function setReqSenderName($ReqSenderName)
        {                                      
            $this->ReqSenderName=$ReqSenderName;             
        }
 
        public function getReqSenderName()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items`";
            $result = $mysqli->query($sql_query);
                    
            while ($row = mysqli_fetch_assoc($result)){
                            echo $this->ReqSenderName=$row['ReqSenderName'];
                            echo "<br>"; 
            }         
        }

////////////////////////////////////////////////////////////////////

        public function setReqSenderID($ReqSenderID)
        {                             
            $this->ReqSenderID=$ReqSenderID;            
        }

        public function getReqSenderID()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items`";
            $result = $mysqli->query($sql_query);
               
            while ($row = mysqli_fetch_assoc($result)){
                echo $this->ReqSenderID=$row['ReqSenderID'];
                echo "<br>";
            }    
        }
//////////////////////////////////////////////////////////////////

        public function setIsAccepted($IsAccepted)
        {            
            $this->IsAccepted=$IsAccepted;            
        }

        public function getIsAccepted()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items`";
            $result = $mysqli->query($sql_query);
                
            while ($row = mysqli_fetch_assoc($result)){
                echo $this->IsAccepted=$row['IsAccepted'];
                echo "<br>";                        
            }                            
        }
 //////////////////////////////////////////////////////////////////////////

    //functions 
        public function CheckIfAccepted($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items` WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
              
            while($row=mysqli_fetch_array($sql)){                        
                return $row['IsAccepted'];                 
            }
        }
        
        public function CheckIfAcceptedandsendid($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items` WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);               
                   
            while($row=mysqli_fetch_array($sql_query)){                        
                return $row['ID'];                     
            }
        }
                
        public function InsertRequstedItem($ReqType,$ReqSenderName,$ReqSenderID,$IsAccepted)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "INSERT INTO  `requested items`(`ReqType`, `ReqSenderName`, `ReqSenderID`, `IsAccepted`) VALUES('$ReqType','$ReqSenderName','$ReqSenderID','$IsAccepted')";
            $result = $mysqli->query($sql_query);
          
            if(mysqli_query($mysqli, $sql_query)){
            echo "Records inserted successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }

        public function delete_Requested_Item($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "DELETE FROM `requested items` WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
            
            if(mysqli_query($mysqli, $sql_query)){
                echo "Record Deleted successfully.";
            } 
            else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }

        public function UpdateAll($ID, $ItemID , $BrandID , $CaseID , $TransID , $IsAccepted)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `requested items` SET `Item_ID`='$ItemID', `Brand_ID`='$BrandID' , `Case_ID`='$CaseID',`Trans_ID`='$TransID',`IsAccepted`='$IsAccepted' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
                    
            if(mysqli_query($mysqli, $sql_query)){
            echo "Record Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }

        public function Update_Requsted_Type($ID,$ReqType)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `requested items` SET `ReqType`='$ReqType' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
            
            if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }


        public function Update_Sender_Name($ID,$ReqSenderName)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `requested items` SET `ReqSenderName`='$ReqSenderName' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
          
            if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }


        public function Update_IsAccepted($ID,$IsAccepted)
        {   
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `requested items` SET `IsAccepted`='$IsAccepted' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
          
            if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }
        public function CheckNameofitem($Nameofitem)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `items` WHERE `Name`='$Nameofitem'";
            $result = $mysqli->query($sql_query);
           
            while($row=mysqli_fetch_array($result))
            {                
                return $row['ID'];                                            
            }
        }
        public function CheckNameofperson($Nameofperson)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `cases` WHERE `Name`='$Nameofperson'";
            $result = $mysqli->query($sql_query);
                   
            while($row=mysqli_fetch_array($result))
            {                        
                return $row['ID'];                                                                                        
            }
        }

        public function AddRequestedItem($Item_ID,$Case_ID,$Trans_ID,$IsAccepted)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "INSERT INTO  `requested items`(`Item_ID`, `Case_ID`, `Trans_ID`, `IsAccepted`) VALUES('$Item_ID','$Case_ID','$Trans_ID','$IsAccepted')";
            $result = $mysqli->query($sql_query);                       

            if(mysqli_query($mysqli, $result)){            
                echo "Records inserted successfully.";            
            }             
            // else{           
            //     echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
            // }                      
        }
              
    
        public function FetchData()
        {
            $IcArray = array();           
    
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `requested items`";
            $result = $mysqli->query($sql_query);
                
            while ($row = mysqli_fetch_assoc($result))
            {
                $IC = new requested_items();
                $Items = new Items();
                $Cases = new Cases();
                $CaseType = new CaseType();
                $Brand= new Brands();    
                
                
                $IC->ID = $row['ID']; 
                $IC->ItemID = $row['Item_ID'];
                $IC->ItemName = $Items->FetchName($IC->ItemID);                            
                $IC->CaseID = $row['Case_ID'];
                $IC->CaseName = $Cases->getcasename($IC->CaseID);
                $fetch = $Cases->getcasetype($IC->CaseID);
                $IC->CaseType = $CaseType->FetchType($fetch);                                
                $IC->BrandID = $row['Brand_ID'];
                $IC->BrandName = $Brand->FetchBrandName($IC->BrandID);                
                $IC->TransID = $row['Trans_ID'];
                $IC->IsAccepted = $row['IsAccepted'];
                                     
                array_push($IcArray , $IC);
            }                                 
                echo "<br>";
                return $IcArray;       
        }

        public function FetchDataItems($ID)
        {                        
            $SpecificItem = array();
    
            $db = Database::getInstance();
            $mysqli = $db->getConnection();                                                                                                

            $sql_query = "SELECT * FROM `items` WHERE `ID`= '$ID'";
            $result = $mysqli->query($sql_query);
            while ($row = mysqli_fetch_assoc($result))
            {
                $Details = new Items();
                $Details->ID = $row['ID'];
                $Details->Name = $row['Name'];
                array_push($SpecificItem , $Details); 
            }                            
            echo "<br>";
            return $SpecificItem;     
        }

        public function FetchDataCases($ID)
        {
           $CsArray = array();
           
           $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM cases WHERE `ID`= '$ID'";
            $result = $mysqli->query($sql_query);                    
                                                                    
                while ($row = mysqli_fetch_assoc($result))
                {
                    $Cs = new Cases(); 
                    $Cs->ID = $row['ID'];
                    $Cs->casename = $row['Name'];
                    $Cs->casetypeID = $row['Case_Type_ID'];
                    $Cs->caseage = $row['Age'];
                    $Cs->feedback = $row['Feedback'];
                    $Cs->gender = $row['Gender'];                                                                                      
                    array_push($CsArray , $Cs);
                }                                                  
                    echo "<br>";                         
                    return $CsArray;           
        }

    }
?>