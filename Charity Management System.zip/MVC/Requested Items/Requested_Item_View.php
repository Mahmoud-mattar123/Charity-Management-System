
<?php
require_once 'Requested_Item_Controller.php';


class requested_items3
    {
        public $a;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;


             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->e =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
           
        }
    }

    $v=new requested_items2();

    if(isset($_POST['do4'])){
      $v=new requested_items2();
      $v->a = $_POST["Reqid"];    
      $v->b = $_POST["Reqtype"];
      $v->c = $_POST["Reqsendername"];
      $v->d = $_POST["Reqsenderid"];
      $v->e = $_POST["isaccepted"];         
     
      $v->g4 = $_POST["do4"];

    }
 

echo'
<!DOCTYPE HTML>
<html>

<head>
<style>

body {
  background-color: #8cd98c;

}

input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
 
}
a:link, a:visited {
  background-color: #45a049;
  color: white;
  padding: 12px 58px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}

a:hover, a:active {
  background-color: #45a049;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}



</style>



</head>
<body>
   
   
    <div>
      <h1 style="color:rgb(6, 172, 0);">Requsted Items</h1>
<form action="Requested_Item_Controller.php" method="POST" >
  <table>
   <tr>
    <td>Name Of Item </td>
    <td><input type="text" name="Name_Of_Item" placeholder="Name of item" required ></td>
   </tr>

   <tr>
    <td>Name Of Person </td>
    <td><input type="text" name="Name_Of_Person" placeholder="Name Of Person" required></td>
   </tr>
     <tr>
    <td>Transaction ID </td>
    <td><input type="value" name="Transaction_ID" placeholder="Transaction ID" required></td>
   </tr>
   <td>State :</td>
   <td>
   <select name="State" id="State">
   <option value="1">Accept</option>
   <option value="0">Deny</option>
   <option value="2">Pending</option>
 </td>
  <tr>
 



  


  <td><button class="button" class="button onclick="myFunction1() value="do1" name="do1" ">Submit</button></td>


   </tr>

   


   <script>
   function myFunction1() {
   $v=new requested_items2();        
    $v->a = $_POST["Name_Of_Item"];    
     $v->b = $_POST["Name_Of_Person"];
     $v->c = $_POST["Transaction_ID"];
     $v->e = $_POST["State"];         
     $v->g1 = $_POST["do1"];      
   }
   </script>


  







 <a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
   <a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>
  
   </table>

   
  
   


 </form>
    </div>
</body>


</html>
';

// if($v->g4!='') //------------->view Accepted in db new record
// {
//     $userOne= new requested_items();
//     $check=$userOne->CheckIfAccepted($v->a);
//     $check2=$userOne->CheckIfAcceptedandsendid($v->a);
//     if($check == 1)
//     {
//       echo "Item ID Is ". $check2 ." your Request Is Accepted" ;
//     }
//     else{
//       echo "Item ID Is ". $check2 ." your Request Is Not Accepted" ;
//     }

  
// }

?>