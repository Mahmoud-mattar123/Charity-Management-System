<?php

echo ' 
<!DOCTYPE html>
<html>

<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  background-color: white;
}

body {
  background-color: #8cd98c;

}

th, td {
  padding: 10px;
}



.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.tab-2 input{display: block;margin-bottom: 10px}
.tab-2{margin-left: 1000px;margin-bottom: -250px}
tr:hover{background-color:#EEE;cursor: pointer}
tr{transition:all .25s ease-in-out}

.right{
  position: absolute;
  left:72%;
  top:5%;
}
a:link, a:visited {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  
}
</style>
</head>


<body>

<form action="Requested_Item_Controller.php" method="POST" >
<h2>Requested Items</h2>



<div class="tab tab-2">
        ID:<input type="number" name="ID" id="ID" required>
        Item ID:<input type="number" name="ItemID" id="ItemID" required>
        Brand ID:<input type="number" name="BrandID" id="BrandID" required>
        Case ID:<input type="number" name="CaseID" id="CaseID" required>
        Transaction ID:<input type="number" name="TransID" id="TransID" required>        
        <td>State :</td>
        <td>
        <select name="IsAccepted" id="IsAccepted">
        <option value="1">Accept</option>
        <option value="0">Deny</option>
        <option value="2">Pending</option>
      </td></select>
                                
                <button onclick="editHtmlTbleSelectedRow(); value="Edit" name="Edit" ">Edit</button>                                                
            </div>


<table id="table" style="width:50%">
  <tr>
    <th>ID</th>
    <th>Item ID</th> 
    <th>Name</th>
    <th>Brand ID</th>
    <th>Name</th>
    <th>Case ID</th>
    <th>Name</th>
    <th>Type</th>
    <th>Transaction ID</th>
    <th>Accepted Or Not</th>     
  </tr>';

if(isset($_SESSION["whatever"]))
{ 
         
      $array = json_decode( $_SESSION["whatever"] , true);
      
      foreach ($array as $arrays)
            {
              echo '<tr><td>';
              echo $arrays['ID'];
              echo'</td><td>';
              echo $arrays['ItemID'];
              echo'</td><td>';
              echo $arrays['ItemName'];
              echo'</td><td>';              
              echo $arrays['BrandID'];
              echo'</td><td>';
              echo $arrays['BrandName'];
              echo'</td><td>';
              echo $arrays['CaseID'];
              echo'</td><td>';
              echo $arrays['CaseName'];
              echo'</td><td>';
              echo $arrays['CaseType'];
              echo'</td><td>';
              echo $arrays['TransID'];
              echo'</td><td>';
              echo $arrays['IsAccepted'];
              echo'</td>';
              echo '<td>';
              echo '<button onclick="removeSelectedRow(); value="Remove" name="Remove"">Remove</button>';
              echo'</td>';   
              // echo '<td>';
              // echo '<button onclick="GetItemDetails(); value="GID" name="GID"">Get Item Details</button>';
              // echo'</td>'; 
              // echo '<td>';
              // echo '<button onclick="GetCaseDetails(); value="GCD" name="GCD"">Get Case Details</button>';
              // echo'</td>';
              echo'</tr>';
            }    
}

  
echo'</table>

<script>


function selectedRowToInput()
              {
                var table = document.getElementById("table");
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {                         
                         document.getElementById("ID").value = this.cells[0].innerHTML;
                         document.getElementById("ItemID").value = this.cells[1].innerHTML;
                         document.getElementById("BrandID").value = this.cells[3].innerHTML;
                         document.getElementById("CaseID").value = this.cells[5].innerHTML;
                         document.getElementById("TransID").value = this.cells[8].innerHTML;
                         document.getElementById("IsAccepted").value = this.cells[9].innerHTML;                                                  
                    };
                }                
              }
              
              selectedRowToInput();
                           
                function editHtmlTbleSelectedRow()
                {
                    var ID = document.getElementById("ID").value,
                        ItemID = document.getElementById("ItemID").value,
                        BrandID = document.getElementById("BrandID").value,
                        CaseID = document.getElementById("CaseID").value,
                        TransID = document.getElementById("TransID").value,
                        IsAccepted = document.getElementById("IsAccepted").value;                       
                        
                    var
                        W1 = $_POST["ID"],
                        W2 = $_POST["ItemID"],
                        W3 = $_POST["BrandID"],
                        W4 = $_POST["CaseID"],
                        W5 = $_POST["TransID"],
                        W6 = $_POST["IsAccepted"];                        

                } 
                function removeSelectedRow()
                {
                    var ID = document.getElementById("ID").value;
                        
                    var
                        W1 = $_POST["ID"];
                }   
                                

         </script>

         <div class="right">
<button class="button" class="button onclick="myFunction() value="Insert" name="Insert" ">Insert New Requested Item</button>
<a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
<script>
   function myFunction() {
       $n=new requested_items2(); 
    $FFF = $_POST[2];
    $n=$_POST[2];

   }
   </script>
</div>
</form>
</body>
</html>';







///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////


?>