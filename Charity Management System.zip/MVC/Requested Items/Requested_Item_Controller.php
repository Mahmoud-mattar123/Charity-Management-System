<?php
require_once 'Requested_Item_Module.php';
echo "<br>";

$ct_correct=0;
class requested_items2
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        //////////////////
        public $W1;
        public $W2;
        public $W3;
        public $W4;
        public $W5;
        public $W6;


             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
             ///////////////////////////
             $this->W1 =NULL;
             $this->W2 =NULL;
             $this->W3 =NULL;
             $this->W4 =NULL;
             $this->W5 =NULL;
             $this->W6 =NULL;
           
        }
    }

    $FFF = 1;

if(isset($_POST['Insert'])){    
      $FFF = 2;
    }
if(isset($_POST['do1'])){    
  $FFF = 2;
}
if(isset($_POST['Edit'])){
  $ct_correct=0;
    $ThisWillWork = new requested_items2();
    if (is_numeric($_POST["ID"])) { 
      if($_POST["ID"]>0)
      {
        $ThisWillWork->W1 = $_POST["ID"];
        $ct_correct+=1;


      }
      
     }
     if (is_numeric($_POST["ItemID"])) { 
      if($_POST["ItemID"]>0)
      {
        $ThisWillWork->W2 = $_POST["ItemID"];
        $ct_correct+=1;


      }
      
     }
     if (is_numeric($_POST["BrandID"])) { 
      if($_POST["BrandID"]>0)
      {
        $ThisWillWork->W3 = $_POST["BrandID"];
        $ct_correct+=1;


      }
      
     }
     if (is_numeric($_POST["CaseID"])) { 
      if($_POST["CaseID"]>0)
      {
        
        $ThisWillWork->W4 = $_POST["CaseID"];
        $ct_correct+=1;


      }
      
     }
     if (is_numeric($_POST["IsAccepted"])) { 
      if($_POST["IsAccepted"]==0||$_POST["IsAccepted"]==1||$_POST["IsAccepted"]==2)
      {
        $ThisWillWork->W6 = $_POST["IsAccepted"];
        $ct_correct+=1;


      }
      
     }

    

    
    
    if($ct_correct==5)
    {
      $userOne = new requested_items();
      $userOne->UpdateAll($ThisWillWork->W1 , $ThisWillWork->W2 , $ThisWillWork->W3 , $ThisWillWork->W4 , $ThisWillWork->W5 , $ThisWillWork->W6);  


    }
    
    
    
  }


  if(isset($_POST['Remove'])){
    
    $ThisWillWork = new requested_items2();
    $ThisWillWork->W1 = $_POST["ID"];        
    
    $userOne = new requested_items();        
    $userOne->delete_Requested_Item($ThisWillWork->W1);  
  }

  if(isset($_POST['GID'])){
    //echo "Dakhallll";
    $ThisWillWork = new requested_items();
    $ThisWillWork->W1 = $_POST["ItemID"];  
    $Arrayyyy2 = $ThisWillWork->FetchDataItems($ThisWillWork->W1);  
    $string2 = json_encode($Arrayyyy2);    
    $_SESSION["whatever2"] = $string2;

    //echo "The Value Is " . $ThisWillWork->W1;
  }

  if(isset($_POST['GCD'])){
    //echo "Dakhallll";
    $ThisWillWork = new requested_items();
    $ThisWillWork->W1 = $_POST["CaseID"];  
    $Arrayyyy3 = $ThisWillWork->FetchDataCases($ThisWillWork->W1);  
    $string3 = json_encode($Arrayyyy3);    
    $_SESSION["whatever3"] = $string3;

    //echo "The Value Is " . $ThisWillWork->W1;
  }



if($FFF==1)
{
    $userOne = new requested_items();
    
    $Arrayyyy = $userOne->FetchData();
    //print_r($Arrayyyy2);

    $string = json_encode($Arrayyyy);
    

    $_SESSION["whatever"] = $string;
    
    require_once 'ReqItTable.php';
    
}
else {
    # code...


    require_once 'Requested_Item_View.php';




    $v=new requested_items2();

    if(isset($_POST['do1']))
    {            $ct_correct=0;
        $FFF = 2;
        $v=new requested_items2();
        if (is_numeric($_POST["Name_Of_Item"])) { 
          
            //donothing
    
    
          }
          else{

            $v->a = $_POST["Name_Of_Item"]; 
            $ct_correct+=1;
          }
          if (is_numeric($_POST["Name_Of_Person"])) { 
          
            //donothing
    
    
          }
          else{

            $v->b = $_POST["Name_Of_Person"];
            $ct_correct+=1;
          }
          if (is_numeric($_POST["Transaction_ID"])) { 
          
            if( $_POST["Transaction_ID"]>0)
            {

              $v->c = $_POST["Transaction_ID"];
              $ct_correct+=1;
            }
           
    
          }
          
      if($ct_correct==3)
      {
        $v->d = $_POST["State"];

        $userOne= new requested_items();
        $receiveNameofItem=$userOne->CheckNameofitem($v->a);
        $receiveNameofperson=$userOne->CheckNameofperson($v->b);
        if($receiveNameofItem !=NULL && $receiveNameofperson !=NULL)
        {
            $userOne->AddRequestedItem($receiveNameofItem,$receiveNameofperson,$v->c,$v->d);

        }


      }
          
        
      
      }
   
   




           
            
  
        }
?>