<?php

require_once 'D:/Xamp new/htdocs/MVC/Database.php';

class CaseType
{
    public     $ID; 
    public     $Type;  

    public function __construct()
    {
        $this->ID=NULL;
        $this->Type=NULL;                        
    }

    public function FetchType($ID)
    {       
       $db = Database::getInstance();
       $mysqli = $db->getConnection(); 
       $sql_query = "SELECT * FROM `casetype` WHERE `ID` = '$ID'";
       $result = $mysqli->query($sql_query);                    
                                                               
        while ($row = mysqli_fetch_assoc($result))
        {
            $this->Type = $row['Case_Type'];                       
        }                                                                                       
        return $this->Type;
    }
}

?>