<!Doctype html>
<html>
<style>
a:link, a:visited {
  background-color: #f44336;
  font-size: 24px;
  width: 50%;
  height: 2%;
  color: white;
  padding: 40px 40px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: red;
}
.button1 {
  margin: 0;
  width: 22%;
  position: absolute;
  top: 20%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button2 {
  margin: 0;
  position: absolute;
  top: 45%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button3 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 22%;
  left: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button4 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 45%;
  left: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

.button5{
  margin: 0;
  width: 22%;
  position: absolute;
  top: 70%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
</style>
<body>
<div class="button1">
<a href="Form2.html">Date Report</a>
  </div>
</div>

<div class="button2">
  <a href="Form2.html">Warehouse State Report</a>
    </div>
</div>

<div class="button3">
  <a href="Form2.html">Item State Report</a>
    </div>
</div>

<div class="button4">
  <a href="Form2.html">Amount of Item Report</a>
    </div>
</div>


<div class="button5">
  <a href="Form2.html">Report Needed Items</a>
    </div>
</div>

</body>
</html>
