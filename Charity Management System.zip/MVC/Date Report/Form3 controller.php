<?php
//require_once '../Item Card/item card.php';
require_once '../Warehouse Manager/WarehouseManager.php';
require_once 'Form3 view.php';
echo "<br>";

class Form4
{
    public $a;
    public $b;
    public $IC_array;

    public function __construct()
    {
      $this->a =NULL;
      $this->b =NULL;
    }
}
$v=new Form4();
if(isset($_POST['do']))
{
    $v=new Form4();
    $v->a = $_POST['sdate'];    
    $v->b = $_POST['edate'];
}


$test = new Warehouse_Manager();

$test->Filter_Items_by_Date($v->a ,$v->b );

// function date_report($sdate,$edate)
// {
//   //echo $sdate;
//   //echo $edate;

//   $item=new item_card();
//   $itemdate=$item->get_date_of_item();
//   echo $itemdate;
//   if($sdate>=$itemdate & $edate<=$itemdate)
//   {
//       return 
//   }
  
// }

// //$Iarray = new item_card();
// //$report_array= $Iarray->FetchData();
// //print_r($report_array);
// date_report($v->a,$v->b);

?>