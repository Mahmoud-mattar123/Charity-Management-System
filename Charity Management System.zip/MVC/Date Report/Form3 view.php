<?php
require_once 'Form3 controller.php';

class Form5
{
    public $a;
    public $b;

    public function __construct()
    {
      $this->a =NULL;
      $this->b =NULL; 
    }
}

echo'
<!DOCTYPE html>
<html>
<body>
<h2>Date Report</h2>

<form method="POST" action="Form3 controller.php">
  <label for="Sdate">Start Date:</label><br>
  <input type="date" name="sdate"><br>
  <label for="Edate">End Date:</label><br>
  <input type="date" name="edate"><br><br>
  
  <button class="button onclick="myFunction() value="do" name="do" ">Submit</button>
  <script>
   function myFunction() {
    $v=new Form5();
    $v->a = $_POST["sdate"];    
    $v->b = $_POST["edate"];
    $v->c = $_POST["do"];  
   }
   </script>
</form> 
</body>
</html>
';


?>