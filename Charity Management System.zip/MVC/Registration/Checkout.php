<?php
// require_once 'Reg_controller.php';
require_once 'deco.php';
require_once 'Reg_Module.php';
session_start();

if(isset($_SESSION["RoleID1"]))
{
  $ReceiveRoleID=$_SESSION["RoleID1"];

}
if(isset($_SESSION["SendUserID1"]))
{
  $recieveID=$_SESSION["SendUserID1"];

}


if(isset($_SESSION["Count"]))
{
  $count=$_SESSION["Count"];
}

if(isset($_SESSION["ID"]))
{
  $id=$_SESSION["ID"];
}

if(isset($_SESSION["Namee"]))
{
  $name=$_SESSION["Namee"];
}

if(isset($_SESSION["EventCostt"]))
{
  $EventCost =$_SESSION["EventCostt"];
}

if(isset($_SESSION["Cost"]))
{
   
$rec=$_SESSION["Cost"];

}
if(isset($_SESSION["paymentType1"]))
{
  $recievepaymentType=$_SESSION["paymentType1"]; 

}
else
{
  $recievepaymentType=0;
}
// if(isset($_POST['Done']))
//   {
//     echo"dkhal";

//     echo $RPT;
//     echo $RRI;
//     echo $RI;
//     // $flag=1;
//     // $_SESSION["Flag"]=$flag;
//     // $_SESSION["RoleID"]=$ReceiveRoleID;
//     // $_SESSION["SendUserID"]=$recieveID;
//     // $_SESSION["paymentType"]=$recievepaymentType;
//     // $ispayed=1;
//     //   $userOne= new Reg2();
//     //     $userOne->SetRegistaration($ReceiveRoleID,$recieveID,$recievepaymentType,$ispayed);
//     // //  header("Location: http://localhost/MVC/Registration/Reg_controller.php");
//     //  header("Location:http://localhost/MVC/Thank%20You.php");

//   }
if($recievepaymentType==1)
{
  
  // header("Location:http://localhost/mvc/Registration/Insert.php");
echo'

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
   
    
    <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family:  Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    .button {
      background-color: #4CAF50;
      border: none;
      color: white;
      padding: 15px 32px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
    }
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }


    .button {
      background-color: #4CAF50;
      border: none;
      color: white;
      padding: 15px 32px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 16px;
      margin: 4px 2px;
      cursor: pointer;
    }

    </style>
</head>

<body>
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                                <img src="https://pbs.twimg.com/profile_images/413271260437573632/J3ugOuLe_400x400.png" style="width:100%; max-width:300px;">
                            </td>
                            
                            <td>
                                Invoice #: 123<br>
                                Created: January 4, 2021<br>
                                Due: February 4, 2021
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td>
                            251 Ahmed Artab/Sad Ibn Obada, First 6th of October, Giza Governorate
                            </td>
                            
                            <td>
                                Charity Corp.<br>
                                Charity Org<br>
                                Charity@gmail.com
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Payment Method
                </td>
                
                <td>
                    Cash #
                </td>
            </tr>
            
            <tr class="details">
                <td>
                    Cash
                </td>                                
            </tr>
            
            <tr class="heading">
                <td>
                    Item
                </td>
                
                <td>
                    Price
                </td>
            </tr>
            
            <tr class="item">
            <td>
            ';
            if(isset($_SESSION["Bus"]))
            {
                $Bus=$_SESSION["Bus"];
                echo $Bus ."       ".$_SESSION["Bus_Cost"]." L.E" ;
                $Bus=0; 
                echo "<br>";
            }
            if(isset($_SESSION["Breakfast"]))
            {
                $Breakfast=$_SESSION["Breakfast"];
                echo $Breakfast ."  ". $_SESSION["breakfast_Cost"]." L.E" ;
                $Breakfast=0;
                echo "<br>";
            }
          
            if(isset($_SESSION["Snacks"]))
            {
                $Snacks=$_SESSION["Snacks"];
                echo $Snacks ."  ". $_SESSION["snacksCost"]." L.E" ;
                $Snacks=0;
                echo "<br>";
            }
           
            if(isset($_SESSION["dinner"]))
            {
                $dinner=$_SESSION["dinner"];
                echo $dinner ."  ".$_SESSION["Dinner_Cost"]." L.E" ;
                $dinner=0;
                echo "<br>";
            }
            
            if(isset($_SESSION["place_to_stay"]))
            {
                $place_to_stay=$_SESSION["place_to_stay"];
                echo $place_to_stay ."    ". $_SESSION["place_to_stay_Cost"]." L.E" ;
                $place_to_stay=0;
                echo "<br>";
            }
           
            if(isset($_SESSION["more_conf_bus"]))
            {
                $more_conf_bus=$_SESSION["more_conf_bus"];
                echo  $more_conf_bus ."  ". $_SESSION["more_conf_bus_cost"]." L.E"  ;
                $more_conf_bus=0;
                echo "<br>";
            }
            echo $name . "  " . $EventCost . "L.E";
              echo'
              </td>
            </tr>
            
            
            <tr class="total">
                <td></td>
                
                <td>
                   Total: ';echo $rec; echo' L.E
                </td>
            </tr>
            <td>

          
         
    
            <form action="Reg_controller.php" method="POST" >
            ';
   
            // header("Location: http://localhost/MVC/Registration/Reg_controller.php");
            echo '
            <input type="hidden"  name="RRI" value="';echo $ReceiveRoleID; echo'">
            <input type="hidden"  name="RI" value="';echo $recieveID; echo'">
            <input type="hidden"  name="RPT" value="';echo $recievepaymentType; echo'">
            <input type="hidden"  name="ID" value="';echo $id; echo'">
            <button class="button" value="Done" name="Done">Done</button>
          
            </form>
            ';
          
               
            echo '
            
            </td>
        </table>
    </div>
</body>
</html>

';
// header("Location: http://localhost/MVC/Registration/Reg_controller.php");
}
if($recievepaymentType==2)
{
echo'
<!DOCTYPE HTML>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
</head>
<body>

<h2>Checkout Form</h2>

<div class="row">
  <div class="col-75">
    <div class="container">
    <form action="Reg_controller.php" method="POST" >
      
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="firstname" placeholder="John M. Doe" required>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="john@example.com" required>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street" required>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="Cairo" required>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="6th of October" required>
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="10001" required>
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="John More Doe" required>
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" required>
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="11" required>
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018" required>
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352" required>
              </div>
            </div>
          </div>
          
        </div>


        ';

        // header("Location: http://localhost/MVC/Registration/Reg_controller.php");
        echo '
        <input type="hidden"  name="RRI" value="';echo $ReceiveRoleID; echo'">
        <input type="hidden"  name="RI" value="';echo $recieveID; echo'">
        <input type="hidden"  name="RPT" value="';echo $recievepaymentType; echo'">
        <button class="button" value="Done" name="Done">Done</button>
      
        
        ';
      
           
        echo '
        
  
    </div>
  </div>
  <div class="col-25">
    <div class="container">
      <h4>Cart <span class="price" style="color:black"><i class="fa fa-shopping-cart"></i> <b>';echo $count; echo'</b></span></h4>
     <p> ';
     if(isset($_SESSION["Bus"]))
     {
         $Bus=$_SESSION["Bus"];
         echo $Bus ."  ".$_SESSION["Bus_Cost"]." L.E" ;
         $Bus=0; 
         echo "<br>";
     }
     if(isset($_SESSION["Breakfast"]))
     {
         $Breakfast=$_SESSION["Breakfast"];
         echo $Breakfast ."  ". $_SESSION["breakfast_Cost"]." L.E" ;
         $Breakfast=0;
         echo "<br>";
     }
   
     if(isset($_SESSION["Snacks"]))
     {
         $Snacks=$_SESSION["Snacks"];
         echo $Snacks ."  ". $_SESSION["snacksCost"]." L.E" ;
         $Snacks=0;
         echo "<br>";
     }
    
     if(isset($_SESSION["dinner"]))
     {
         $dinner=$_SESSION["dinner"];
         echo $dinner ."  ". $_SESSION["Dinner_Cost"]." L.E" ;
         $dinner=0;
         echo "<br>";
     }
     
     if(isset($_SESSION["place_to_stay"]))
     {
         $place_to_stay=$_SESSION["place_to_stay"];
         echo $place_to_stay ."  ". $_SESSION["place_to_stay_Cost"]." L.E" ;
         $place_to_stay=0;
         echo "<br>";
     }
    
     if(isset($_SESSION["more_conf_bus"]))
     {
         $more_conf_bus=$_SESSION["more_conf_bus"];
         echo  $more_conf_bus ."  ". $_SESSION["more_conf_bus_cost"]." L.E"  ;
         $more_conf_bus=0;
         echo "<br>";
     }
   
    

     

    

      

     
 
      

       echo'
        </p>
      <p>Total <span class="price" style="color:black"><b>';echo $rec; echo' L.E </b></span></p>
    </div>
  </div>
</div>
</form>
</body>




</html>
';

  }



session_destroy();
?>