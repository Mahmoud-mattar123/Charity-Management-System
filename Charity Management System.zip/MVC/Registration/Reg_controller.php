<?php


ob_start();
require_once 'deco.php';
require_once 'RegistertionEvents.php';
require_once 'Reg_Module.php';
require_once 'D:/Xamp new/htdocs/MVC/RegulerUser/RegularUser.php';
echo "<br>";


$new = 0 ;


class Reg
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        public $f;
        public $recievepaymentType;

             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
           
        }
    }

    $ppp = 1;



    



   
    $v=new Reg();

    if(isset($_POST['do1'])){
        $v=new Reg();
        $v->a = $_POST["ID"];    
      $v->b = $_POST["user_id"];
      $v->c = $_POST["payment_method_id"];
      $v->d = $_POST["is_payed"];
      $v->e = $_POST["role_id"];         
             
        $v->g1 = $_POST["do1"]; 
        
 
      }
      if(isset($_POST['do2'])){
        $v=new Reg();
        $v->a = $_POST["ID"];    
      $v->b = $_POST["user_id"];
      $v->c = $_POST["payment_method_id"];
      $v->d = $_POST["is_payed"];
      $v->e = $_POST["role_id"];         
            
        
        $v->g2 = $_POST["do2"];
       
 
      }
      if(isset($_POST['do3'])){
        $v=new Reg();
        $v->a = $_POST["ID"];    
      $v->b = $_POST["user_id"];
      $v->c = $_POST["payment_method_id"];
      $v->d = $_POST["is_payed"];
      $v->e = $_POST["role_id"];         
             
       
        $v->g3 = $_POST["do3"];
        
 
      }
      if(isset($_POST['do4'])){
        $v=new Reg();
        $v->a = $_POST["ID"];    
        $v->b = $_POST["user_id"];
        $v->c = $_POST["payment_method_id"];
        $v->d = $_POST["is_payed"];
        $v->e = $_POST["role_id"];         
              
       
        $v->g4 = $_POST["do4"];
 
      }

      if(isset($_SESSION["SendUserID"]))
      {
      $recieveID= $_SESSION["SendUserID"];
      $id = $_SESSION["ID"];  
      $name = $_SESSION["Name"];
      $EventCost = $_SESSION["EventCost"]; 
      //echo "The ID iS" . $id; 
      }

      if(isset($_POST['Submit']))
      {
        
        // $recievePaymentMethod=$_POST["PaymentMethod"];
        // $recievepayment=0;
        $v=new Reg();
        $v->a = $_POST["bus"];    
        $v->b = $_POST["breakfast"];
        $v->c = $_POST["snacks"];
        $v->d = $_POST["dinner"];
        $v->e = $_POST["place_to_stay"];         
        $v->f = $_POST["more_conf_bus"];
        $email = $_POST["email"];
        $website = $_POST["website-8"];
        $sms = $_POST["sms-9"];
        $ReceiveRoleID = $_POST["RoleID"];
        $recievepaymentType=$_POST["PaymentMethod"];
        $recieveRole=$ReceiveRoleID;
        $recievepayment=$recievepaymentType;
        $deco=0;
        $cost=0;
        $count=0;
        // $recievepaymentType=$v->paymentType;
        $Bus=0; 
        $Breakfast=0;
        $Snacks=0;
        $dinner=0;
        $place_to_stay=0;
        $more_conf_bus=0;
        if($email==2)
        {
          $notify= new RUser();
          $notify->subscribtion($recieveID,$email);
        
        }
        if($website==3)
        {
          $notify= new RUser();
          $notify->subscribtion($recieveID,$website);
        }
        if($sms==1)
        {
          $notify= new RUser();
         $notify->subscribtion($recieveID,$sms);
        }
        if($v->a==1)
        {
            $deco = new basic_bus();
            $cost=$deco->cost();
            $bus='Bus';
            $_SESSION["Bus"]=$bus;
            $Bus=''; 
            
            $count=$count+1;
            //  header("Location:Reg_controller.php");
        }
        if($v->b==2 && $v->a==1)
        {
          $deco = new breakfast($deco);
          $Breakfast='Breakfast';
          $_SESSION["Breakfast"]=$Breakfast;
          $Breakfast='';
          $cost=$deco->cost();
          $count=$count+1;

        }  
        if($v->c==3 && $v->a==1)
        {
        $deco = new snacks($deco); 
        $Snacks='Snacks';
        $_SESSION["Snacks"]=$Snacks;
        $Snacks='';

        $cost=$deco->cost();
        $count=$count+1;
        // $desc=$deco->description();
        }
        if($v->d==4 && $v->a==1)
        {
          $deco = new dinner($deco);
          $dinner='dinner';
          $cost=$deco->cost();
          $_SESSION["dinner"]=$dinner;
          $dinner='';
          $count=$count+1;

        }
        if($v->e==5 && $v->a==1)
        {
          $deco = new place_to_stay($deco); 
          $place_to_stay='Place to stay';
          $_SESSION["place_to_stay"]=$place_to_stay;
          $place_to_stay='';
          $cost=$deco->cost();
          $count=$count+1;
        // $desc=$deco->description();
        }
        if($v->f==6 && $v->a==1)
        {
          $deco = new more_conf_bus($deco); 
          $more_conf_bus='More Comfortable Bus';
          $_SESSION["more_conf_bus"]=$more_conf_bus;
          $more_conf_bus='';
          $cost=$deco->cost();
          $count=$count+1;
        // $desc=$deco->description();
        }
       
          $Bus=0; 
          $Breakfast=0;
          $Snacks=0;
          $dinner=0;
          $place_to_stay=0;
          $more_conf_bus=0;


        $v->a =0;    
        $v->b = 0;
        $v->c = 0;
        $v->d =0;
        $v->e = 0;         
        $v->f = 0;
        $flag=1;
   

        $TotalCost = $cost + $EventCost;
        $_SESSION["RoleID1"]=$ReceiveRoleID;
        $_SESSION["SendUserID1"]=$recieveID;
        $_SESSION["paymentType1"]=$recievepaymentType;
        $_SESSION["Count"]=$count;
        $_SESSION["Cost"]=$TotalCost;
        $_SESSION["ID"]=$id;
        $_SESSION["EventCostt"]=$EventCost;
        $_SESSION["Namee"]=$name;
        
        $new = 1 ;
        

        
      }

      if($new == 1)
      {
        header("Location: Checkout.php");
      }
      // if($flag==1)
      // {
          if(isset($_POST['Done']))
        {
         
          if(isset($_POST['RRI']))
          {
            
          $recieveRole = $_POST["RRI"];
          }   
          
          $recieveID = $_POST["RI"];
          $id = $_POST["ID"];
          $recievepaymentType = $_POST["RPT"];
    
          echo $recieveRole;
        echo $recieveID;
        echo $recievepaymentType;
        $ispayed=1;
        $userOne= new Reg2();
        $userOne->SetRegistaration($recieveRole,$recieveID,$recievepaymentType,$ispayed);
        $Fetcher = $userOne->FetchLastReg();
        $userOne->SetRegistarationDetails($Fetcher , $id);
        $user= new RUser();
        $user->register_observer($recieveID);
         header("Location:http://localhost/MVC/Thank%20You.php");
        }

        ob_end_flush();
   
?>