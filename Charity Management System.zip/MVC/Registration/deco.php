<?php
// session_start();
interface bus {
    function cost();
    // function description();
  }


  class basic_bus implements bus {
    function cost()
    {
        $_SESSION["Bus_Cost"]=200;
      return 200;
    }
 
    // function description ()
    // {
    //   return "basic bus";
    // }
}
/////////////////////////////////////////////
abstract class additevs implements bus {
    protected $x;
  
    function __construct(bus $x)
    {
      $this->x = $x;
    }
    abstract function cost();
    
    // abstract function description();
  }
//////////////////////////////////////------>
 
class more_conf_bus extends additevs {
    function cost ()
    {
        $_SESSION["more_conf_bus_cost"]=2000;
        return $this->x->cost() + 2000;
    }

    // function description()
    // {
    //     return $this->x->description() . ",  more conf. bus";
    // }
}
class snacks extends additevs {
    function cost ()
    {
        $_SESSION["snacksCost"]=1500;
        return $this->x->cost() + 1500;
    }

    // function description()
    // {
    //     return $this->x->description() . ",  snacks";
    // }
}
class breakfast extends additevs {
    function cost ()
    {
        $_SESSION["breakfast_Cost"]=500;
        return $this->x->cost() + 500;
    }

    // function description()
    // {
    //     return $this->x->description() . ",  breakfast";
    // }
}
class dinner extends additevs {
    function cost ()
    {
        $_SESSION["Dinner_Cost"]=50;
        return $this->x->cost() + 50;
    }

    // function description()
    // {
    //     return $this->x->description() . ",  dinner";
    // }
}
class place_to_stay extends additevs {
    function cost ()
    {
        $_SESSION["place_to_stay_Cost"]=500;
        return $this->x->cost() + 500;
    }

    // function description()
    // {
    //     return $this->x->description() . ",  place to stay";
    // }
}

// header("Location:Checkout.php");


?>