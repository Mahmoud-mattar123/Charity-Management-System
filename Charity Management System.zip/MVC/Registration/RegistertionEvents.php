<?php
 //require_once 'Reg_controller.php';
// session_start();
// $rec=$_SESSION["Deco"];

echo'
<!DOCTYPE HTML>
<html>

<head>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
 
}
a:link, a:visited {
  background-color: #45a049;
  color: white;
  padding: 12px 58px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}

a:hover, a:active {
  background-color: #45a049;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

#checkbox-2 {
  display: none;
}

#checkbox-1:checked ~ #checkbox-2 {
  display: table-cell;
 
}
#checkbox-1:checked ~ #checkbox-3 {
  display: table-cell;
  
}
#checkbox-3 {
  display: none;
}
#checkbox-1:checked ~ #checkbox-4 {
  display: table-cell;
}
#checkbox-4 {
  display: none;
}
#checkbox-1:checked ~ #checkbox-5 {
  display: table-cell;
}
#checkbox-5 {
  display: none;
}
#checkbox-1:checked ~ #checkbox-6 {
  display: table-cell;
}
#checkbox-6 {
  display: none;
}
h3 {
  color: green;
}
text {
  color: green;
  font: 12px;
}

</style>



</head>
<body>
   
   
    <div>
      <h1 style="color:rgb(6, 172, 0);">Events Registration</h1>
<form action="Reg_controller.php" method="POST" >
  <table>
<tr>
<td>
<h3> Add more fun for the trip? </h3>
<text> Select Bus to open other extras </text>
<br>

   <input type="checkbox" id="checkbox-1" name="bus" value="1" >Bus 200 L.E <BR>
   
   <input type="checkbox" id="checkbox-2" name="breakfast" value="2" >Breakfast  500 L.E <BR>

   <input type="checkbox" id="checkbox-3" name="snacks" value="3" >Snacks 1500  L.E <BR>
 
  
   <input type="checkbox" id="checkbox-4" name="dinner" value="4" >Dinner 50  L.E <BR>

  
   <input type="checkbox" id="checkbox-5" name="place_to_stay" value="5" >Place To Stay 500  L.E <BR>

  
  <input type="checkbox" id="checkbox-6" name="more_conf_bus" value="6" >More Comfortable Bus 2000  L.E  <BR>
<br>

<h3>How do you want to receive notifications</h3>
   <input type="checkbox" id="email" name="email" value="2" >
   <label for="email">Email Notifications</label><br>

   <input type="checkbox" id="website-8" name="website-8" value="3" >
   <label for="website">Website Notifications</label><br>

   <input type="checkbox" id="sms-9" name="sms-9" value="1" >
   <label for="sms">Sms Notifications</label><br>
<br>

  Payment Method :
  <select name="PaymentMethod" id="State">
   <option value="1" >Cash</option>
   <option value="2" >Visa</option>
 </select>

  Role ID :
   <select name="RoleID" id="State2">
    <option value="1" >Attender</option>
    <option value="2" >Organizer</option>
</select>
   
   
</td>
   </tr>
   <td><button class="button" value="Submit" name="Submit" ">Submit</button></td>
   <a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>
   </table>
 </form>

    </div>
</body>


</html>
';




?>