
<?php
require_once 'Reg_controller.php';


class Reg
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        public $f;


             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
           
        }
    }

    $v=new Reg2();

    if(isset($_POST['do4'])){
      $v=new Reg2();
      $v->a = $_POST["ID"];    
      $v->b = $_POST["user_id"];
      $v->c = $_POST["payment_method_id"];
      $v->d = $_POST["is_payed"];
      $v->e = $_POST["role_id"];    
     
      $v->g4 = $_POST["do4"];

    }
 

echo'
<!DOCTYPE HTML>
<html>

<head>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

div {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
 
}
a:link, a:visited {
  background-color: #45a049;
  color: white;
  padding: 12px 58px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  
}

a:hover, a:active {
  background-color: #45a049;
}


.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

#checkbox-2 {
  display: none;
}

#checkbox-1:checked ~ #checkbox-2 {
  display: table-cell;
 
}
#checkbox-1:checked ~ #checkbox-3 {
  display: table-cell;
  
}
#checkbox-3 {
  display: none;
}
#checkbox-1:checked ~ #checkbox-4 {
  display: table-cell;
}
#checkbox-4 {
  display: none;
}
#checkbox-1:checked ~ #checkbox-5 {
  display: table-cell;
}
#checkbox-5 {
  display: none;
}
#checkbox-1:checked ~ #checkbox-6 {
  display: table-cell;
}
#checkbox-6 {
  display: none;
}

</style>



</head>
<body>
   
   
    <div>
      <h1 style="color:rgb(6, 172, 0);">Registration</h1>
<form action="Reg_controller.php" method="POST" >
  <table>
   <tr>
    <td>Registration ID </td>
    <td><input type="text" name="ID" placeholder="Registration ID.." ></td>
   </tr>

   <tr>
    <td>User ID </td>
    <td><input type="text" name="user_id" placeholder="User ID.."></td>
   </tr>
     <tr>
    <td>Payment Method </td>
    <td><input type="text" name="payment_method_id" placeholder="Payment Method.."></td>
   </tr>
    <tr>
    <td>Is Payed </td>
    <td><input type="text" name="is_payed" placeholder="Is Payed.."></td>
   </tr>
   <tr>
    <td>Role Id </td>
    <td><input type="text" name="role_id" placeholder="Role Id.." ></td>
   </tr>
  



  


  <td><button class="button" class="button onclick="myFunction1() value="do1" name="do1" ">Insert</button></td>
  <td><button class="button" class="button onclick="myFunction3() value="do3" name="do3" ">Delete</button></td>

   </tr>

   <tr>

   <td><button class="button" class="button onclick="myFunction2() value="do2" name="do2" ">Update</button></td>
   <td><button class="button" class="button onclick="myFunction4() value="do4" name="do4" ">View</button></td>
 


   
   </tr>
<tr>
<td>
   <input type="checkbox" id="checkbox-1" name="bus" value="0">Bus<BR>
   
   <input type="checkbox" id="checkbox-2" name="breakfast" value="1">Breakfast<BR>

   <input type="checkbox" id="checkbox-3" name="snacks" value="2">Snacks<BR>
 
  
   <input type="checkbox" id="checkbox-4" name="dinner" value="3">Dinner<BR>

  
   <input type="checkbox" id="checkbox-5" name="place_to_stay" value="4">Place To Stay<BR>

  
  <input type="checkbox" id="checkbox-6" name="more_conf_bus" value="5">More Comfortable Bus<BR>

 
</td>
   </tr>
   
      
  <input type="submit" value="Submit">

   <a href="http://localhost/MVC/User/Module/Login.php">Sign Out</a>
   </table>
 </form>

    </div>
</body>


</html>
';



?>