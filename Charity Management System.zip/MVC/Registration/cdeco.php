<?php
// require_once 'deco.php';
//  require_once 'Reg_controller.php';
 

class Reg4
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        public $f;


             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
           
        }
    }
//al if gowa al () htkteb le kol check box rakam law at722 y5osh gowa al if we yshof sho8lo ma3 nfso 
    $v=new Reg4();
    $v->a=$_SESSION["bus"];
    $v->b=$_SESSION["breakfast"];
    $v->c=$_SESSION["snacks"];
    $v->d=$_SESSION["dinner"];
    $v->e= $_SESSION["place_to_stay"];
    $v->f= $_SESSION["more_conf_bus"];


// $deco=0;

// if($v->a==0)
// {
//     $deco = new basic_bus();

//     //  header("Location:Reg_controller.php");
// }
// if($v->b==1 && $v->a==0)
// {
    
// $deco = new more_conf_bus($deco); 

// }  
// if($v->c==2&& $v->a==0)
// {
// $deco = new snacks($deco); 

// }
// if($v->d==3 && $v->a==0)
// {
// $deco = new breakfast($deco);

// }
// if($v->e==4 && $v->a==0)
// {
// $deco = new dinner($deco);

// }
// if($v->f==5 && $v->a==0)
// {
// $deco = new place_to_stay($deco); 

// }

//  $_SESSION["Deco"]=$deco;
//  header("Location:Checkout.php");
//  header("Location:RegistertionEvents.php");
// echo $deco-> description();  //---->mknhom post yro7 lel  view bshkl gamed
// echo $deco-> cost();










?>