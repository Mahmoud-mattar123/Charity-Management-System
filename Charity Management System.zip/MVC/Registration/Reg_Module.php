<?php 
require_once 'D:/Xamp new/htdocs/MVC/Database.php';

class Reg2
    {
        public $ID;
        public $user_id;
        public $payment_method_id;
        public $is_payed;
        public $role_id;
        


             //constructor
        public function __construct(){
            $this->ID =NULL;
            $this->user_id =NULL;
            $this->payment_method_id =NULL;
            $this->is_payed =NULL;
            $this->role_id =NULL;                    
        }


        public function setreqid($ID)
        {           
            $this->ID=$ID;
        }
         
        public function getreqid()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `registration`";
            $result = $mysqli->query($sql_query);
               
            $resultCheck = mysqli_num_rows($result);
            if( $resultCheck >0 ){
                while ($row = mysqli_fetch_assoc($result))
                {
                    $this->ID=$row['ID'];                                          
                }
            } 
            return  $this->ID;        
        }

        public function setuser_id($user_id)
        {
            $this->user_id=$user_id;           
        }
 
        public function getuser_id()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `registration`";
            $result = $mysqli->query($sql_query);
               
            $resultCheck = mysqli_num_rows($result);
            if( $resultCheck >0 ){
                while ($row = mysqli_fetch_assoc($result)){
                    $this->user_id=$row['user_id'];                         
                }
            }             
        }

         public function setpayment_method_id($payment_method_id)
         {                                          
            $this->payment_method_id=$payment_method_id;             
         }
 
        public function getpayment_method_id()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `registration`";
            $result = $mysqli->query($sql_query);
               
            $resultCheck = mysqli_num_rows($result);
            if( $resultCheck >0 ){
                while ($row = mysqli_fetch_assoc($result)){
                    $this->payment_method_id=$row['payment_method_id'];                            
                }
            }
                return $this->payment_method_id;             
        }

////////////////////////////////////////////////////////////////////

        public function setis_payed($is_payed)
        {                             
            $this->is_payed=$is_payed;            
        }

        public function getis_payed()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `registration`";
            $result = $mysqli->query($sql_query);

                $resultCheck = mysqli_num_rows($result);
                if( $resultCheck >0 ){
                    while ($row = mysqli_fetch_assoc($result)){
                        $this->is_payed=$row['is_payed'];                                           
                    }
                }
            return $this->is_payed;            
        }
//////////////////////////////////////////////////////////////////

        public function setrole_id($role_id)
        {            
            $this->role_id=$role_id;            
        }

        public function getrole_id($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT Role_ID FROM registration WHERE User_ID = '$ID'";
            $result = $mysqli->query($sql_query);
                         
            $resultCheck = mysqli_num_rows($result);
            if( $resultCheck >0 ){
                while ($row = mysqli_fetch_assoc($result)){
                    $this->role_id=$row['Role_ID'];
                }
            }
            return $this->role_id;
        }
         

        public function InsertReg($user_id,$payment_method_id,$is_payed,$role_id)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "INSERT INTO  `registration`(`user_id`, `payment_method_id`, `is_payed`, `role_id`) VALUES('$user_id','$payment_method_id','$is_payed','$role_id')";
            $result = $mysqli->query($sql_query);
                       
           if(mysqli_query($mysqli, $result)){
            echo "Records Inserted successfully.";
            } 
            // else{
            // echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
            // }

        }



        public function delete_Reg($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "DELETE FROM `registration` WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
          
            if(mysqli_query($mysqli, $sql_query)){
                echo "Records Deleted successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }

        }

    
        public function Update_user_id($ID,$user_id)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `registration` SET `user_id`='$user_id' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
        
           if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }


        public function Update_payment_method_id($ID,$payment_method_id)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `registration` SET `payment_method_id`='$payment_method_id' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);

            if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }


        public function Update_is_payed($ID,$is_payed)
        {   
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `registration` SET `is_payed`='$is_payed' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
          
            if(mysqli_query($mysqli, $sql_query)){
                echo "Records Updated successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }




        
        public function Update_role_id($ID,$role_id)
        {   
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = " UPDATE `registration` SET `role_id`='$role_id' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
          
            if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }

        public function SetRegistaration($role_id,$ID,$payment_method_id,$is_payed)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "INSERT INTO `registration`(`User_ID`, `Payment_Method_ID`, `IsPayed`, `Role_ID`) VALUES('$ID','$payment_method_id','$is_payed','$role_id')";
            $result = $mysqli->query($sql_query); 
            
            if(mysqli_query($mysqli, $result)){
                echo "Records Updated successfully.";
            } 
                // else{
                // echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
                // }
        }


        public function FetchLastReg()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT `ID` FROM `registration`";
            $result = $mysqli->query($sql_query);           

            while ($row = mysqli_fetch_assoc($result))
            {
                $this->ID = $row['ID'];
            }

            return $this->ID;
        }


        public function SetRegistarationDetails($RegID , $EventID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "INSERT INTO `registration details`(`Registration_ID`, `Event_ID`) VALUES ('$RegID','$EventID')";
            $result = $mysqli->query($sql_query);
           
            if(mysqli_query($mysqli, $result)){
                echo "Records Updated successfully.";
                } 
                // else{
                // echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                // }
        }
}
?>