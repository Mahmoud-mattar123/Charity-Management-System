<?php 
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'whmang');
 
/* Attempt to connect to MySQL database */
$link = mysqli_connect("localhost", "root", "", "whmang");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());

    echo "Didn't Connect";
}



// include ('../Database.php');
include ('../Item Card/item card module.php');
require_once 'D:/Xamp new/htdocs/MVC/Items/Items.Model.php';


class Warehouse_Manager
{
    ///////////////////// Properties
    public $date_from;
    public $date_to;
    public $item_ID_query;
    public $caseage;
    public $IcArray;   
    
    
    
    
    ///////////////////// Constructor
    public function __construct()
    {
        $this->FetchData();      
    }

    public function FetchData()
    {
      $IcArray = array();

      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

          $sql ="SELECT * FROM `item card`";
                    $result = mysqli_query($link,$sql);
                    
                    if(mysqli_num_rows($result) > 0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {         
                            $IC = new item_card(); 
                            $Items = new Items();
                                   
                            $IC->ID = $row['ID'];
                            $IC->item_ID = $row['Item_ID'];
                            $IC->Name = $Items->FetchName($IC->item_ID);
                            $IC->item_quntity = $row['Quantity'];                            
                            $IC->incoming = $row['Incoming'];
                            $IC->outgoing = $row['Outgoing'];
                            $IC->dmy = $row['DateOfTransc.'];
                            $IC->note = $row['Note'];  
                            $IC->trns_id = $row['Trans_ID'];
                            $IC->Warehouse_ID = $row['Warehouse_ID']; 
                            
                            array_push($IcArray , $IC);
                        }                        
                    } 
                   
                    //echo "This Should be the statement before the return ";
                    return $IcArray;                             
    }

    ///////////////////// Set
    public function setdate_from($date_from)
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }
        // Attempt insert query execution
        $sql = "INSERT INTO warehouse (Sdmy) VALUES ('$date_from')";
        if(mysqli_query($link, $sql))
        {
          echo "Records inserted successfully.";
        }
        else
        {
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
        }
        $this->date_from=$date_from;
    }

    public function setdate_to($date_to)
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }
        // Attempt insert query execution
        $sql = "INSERT INTO warehouse (Edmy) VALUES ('$date_to')";
        if(mysqli_query($link, $sql))
        {
          echo "Records inserted successfully.";
        }
        else
        {
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
        }
        $this->date_to=$date_to;
    }

    public function setitem_ID_query($item_ID_query)
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

        // Attempt insert query execution
        $sql = "INSERT INTO warehouse (item_ID_query) VALUES ('$item_ID_query')";
        if(mysqli_query($link, $sql))
        {
          echo "Records inserted successfully.";
        }
        else
        {
          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
        }
        $this->item_ID_query=$item_ID_query;
    }

    public function set_Report($Report)
    {
        
        $this->Report=$Report;
    }

    ///////////////////// Get
    public function getdate_from()
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

      $sql ="SELECT * FROM warehouse";
          $result = mysqli_query($link,$sql);
          $resultCheck = mysqli_num_rows($result);
              if( $resultCheck >0 ){
                  while ($row = mysqli_fetch_assoc($result)){

                            echo $row['Sdmy'] . "<br>";
                  }
                }

    }

    public function getdate_to()
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

      $sql ="SELECT * FROM warehouse";
          $result = mysqli_query($link,$sql);
          $resultCheck = mysqli_num_rows($result);
              if( $resultCheck >0 ){
                  while ($row = mysqli_fetch_assoc($result)){

                            echo $row['Edmy'] . "<br>";
                  }
                } 
    }

    public function getitem_ID_query()
    {
        return $this->item_ID_query; 
    }

    public function getReport()
    {
        return $this->Report; 
    }

    ///////////////////// Functions

    public function UpdateAll($ID , $ItemID ,$Quan , $Inc ,$Out , $dms , $Note , $TransID , $WhID)
    {                

            $link = mysqli_connect("localhost", "root", "", "whmang");

            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

          
           $sql ="UPDATE `item card` SET `Item_ID`='$ItemID',`Quantity`='$Quan',`Incoming`='$Inc',`Outgoing`='$Out',`DateOfTransc.`='$dms',`Note`='$Note',`Trans_ID`='$TransID',`Warehouse_ID`='$WhID' WHERE `ID`='$ID'";



           if(mysqli_query($link, $sql)){
            echo "Record Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }


    }

    public function DeleteRow($ID)
    {                

            $link = mysqli_connect("localhost", "root", "", "whmang");

            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

          
           $sql ="DELETE FROM `item card` WHERE `ID`='$ID'";



           if(mysqli_query($link, $sql)){
            echo "Record Deleted successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }


    }



    public function view_item($ID)
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

      $sql=mysqli_query($link,"SELECT * FROM `item card` WHERE `ID`='$ID'");

      while($row=mysqli_fetch_array($sql)){
    
        echo $row['ID']. " | ";
        echo $row['Quantity']. " | ";
        echo $row['Incoming']. " | ";
        echo $row['Outgoing']. " | ";
        echo $row['DateOfTransc.']. " | ";
        echo $row['Note'];
        echo "<br>"; 
        }
        
    }
    public function add_new_item_in_item_card($Quan , $Inc , $Out , $Dmy , $Note)
    {
      $IC = new item_card(); 
      

      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
                    if($link === false){
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }
                          // Attempt insert query execution
                       $sql = "INSERT INTO `item card`(`Quantity`, `Incoming`, `Outgoing`, `DateOfTransc.`, `Note`) VALUES ('$Quan','$Inc','$Out','$Dmy','$Note')";
      
                       if(mysqli_query($link, $sql)){
                          echo "New Item card Data inserted successfully.";
                       } else{
                          echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                       } 
                          
                    $this->FetchData();
    }
    public function AddNewDocumenters()
    {
        
    }
    public function ViewDocumenters()
    {
        
    }
    
    public function Filter_specific_item($ID1 , $ID2)
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
                    if($link === false){
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }
                          // Attempt insert query execution                      

                       $sql=mysqli_query($link,"SELECT * FROM `item card` WHERE(ID BETWEEN '$ID1' AND '$ID2')");

      while($row=mysqli_fetch_array($sql)){
    
        echo $row['ID']. " | ";
        echo $row['Quantity']. " | ";
        echo $row['Incoming']. " | ";
        echo $row['Outgoing']. " | ";
        echo $row['DateOfTransc.']. " | ";
        echo $row['Note'];
        echo "<br>"; 
        }
      
                       
    }
    public function Filter_Items_by_Date($date_from, $date_to)
    {
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
                    if($link === false){
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }
                          // Attempt insert query execution                      

                       $sql=mysqli_query($link,"SELECT * FROM `item card` WHERE(`DateOfTransc.` BETWEEN '$date_from' AND '$date_to')");

      while($row=mysqli_fetch_array($sql)){
    
        echo $row['ID']. " | ";
        echo $row['Quantity']. " | ";
        echo $row['Incoming']. " | ";
        echo $row['Outgoing']. " | ";
        echo $row['DateOfTransc.']. " | ";
        echo $row['Note'];
        echo "<br>"; 
        }
    }
    public function Sort_Items_Desc()
    {
      

      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
                    if($link === false){
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }
                          // Attempt insert query execution                      

                       $sql=mysqli_query($link,"SELECT * FROM `item card` ORDER BY `item card`.`ID` DESC");

      while($row=mysqli_fetch_array($sql)){
    
        echo $row['ID']. " | ";
        echo $row['Quantity']. " | ";
        echo $row['Incoming']. " | ";
        echo $row['Outgoing']. " | ";
        echo $row['DateOfTransc.']. " | ";
        echo $row['Note'];
        echo "<br>"; 
        }
    }
    public function Sort_Items_By_Quantity_Desc()
    {
      
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
                    if($link === false){
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }
                          // Attempt insert query execution                      

                       $sql=mysqli_query($link,"SELECT * FROM `item card` ORDER BY `item card`.`Quantity` DESC");

      while($row=mysqli_fetch_array($sql)){
    
        echo $row['ID']. " | ";
        echo $row['Quantity']. " | ";
        echo $row['Incoming']. " | ";
        echo $row['Outgoing']. " | ";
        echo $row['DateOfTransc.']. " | ";
        echo $row['Note'];
        echo "<br>"; 
        }

    }

    public function Sort_Items_By_Quantity_Asc()
    {
      
      $link = mysqli_connect("localhost", "root", "", "whmang");
 
      // Check connection
                    if($link === false){
                        die("ERROR: Could not connect. " . mysqli_connect_error());
                    }
                          // Attempt insert query execution                      

                       $sql=mysqli_query($link,"SELECT * FROM `item card` ORDER BY `item card`.`Quantity` ASC");

      while($row=mysqli_fetch_array($sql)){
    
        echo $row['ID']. " | ";
        echo $row['Quantity']. " | ";
        echo $row['Incoming']. " | ";
        echo $row['Outgoing']. " | ";
        echo $row['DateOfTransc.']. " | ";
        echo $row['Note'];
        echo "<br>"; 
        }

    }

    public function Sort_Cases()
    {
        
    }
    public function view_donors_info($y)
    {
        
    }

}
?>