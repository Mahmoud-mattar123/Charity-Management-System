<?php 
require_once 'WarehouseManager.php';
$ct_correct=0;
class Warehouse_Manager2
    {       
        public $W1;
        public $W2;
        public $W3;
        public $W4;
        public $W5;
        public $W6;
        public $W7;
        public $W8;
        public $W9;


             //constructor
           public function __construct(){          
            $this->W1 =NULL;
            $this->W2 =NULL;
            $this->W3 =NULL;
            $this->W4 =NULL;
            $this->W5 =NULL;
            $this->W6 =NULL;
            $this->W7 =NULL;
            $this->W8 =NULL;
            $this->W9 =NULL;             
        }
    }

$TTT = 1;    

    if(isset($_POST['Insert'])){      
        $TTT = 2;
      }

if(isset($_POST['Edit'])){
    
    $ThisWillWork = new Warehouse_Manager2();
    if (is_numeric($_POST["ID"])) { 
      if($_POST["ID"]>0)
      {
        $ct_correct+=1;


      }
      
     }
     
      if (is_numeric($_POST["ItemID"])) { 
        if($_POST["ItemID"]>0)
        {
          $ct_correct+=1;
  
  
        }
        
       }
       
        if (is_numeric($_POST["Quantity"])) { 
          if($_POST["Quantity"]>=0)
          {
            $ct_correct+=1;
    
    
          }
          
         }
         
          if (is_numeric($_POST["Incoming"])) { 
            if($_POST["Incoming"]>=0)
            {
              $ct_correct+=1;
      
      
            }
            
           }
           
            if (is_numeric($_POST["Outgoing"])) { 
              if($_POST["Outgoing"]>=0)
              {
                $ct_correct+=1;
        
        
              }
              
             }
              
              // if (is_numeric($_POST["DateOfTrans"])) { 
              //   if($_POST["DateOfTrans"]>0)
              //   {
              //     $ct_correct+=1;
          
          
              //   }
                
              //  }
                else { echo "No"; }
                if (is_numeric($_POST["Note"])) { 
                 //donothing
                  
                 }
                 else{
                  $ct_correct+=1;

                 }
                 
                  if (is_numeric( $_POST["TransID"])) { 
                    if( $_POST["TransID"]>0)
                    {
                      $ct_correct+=1;
              
              
                    }
                    
                   }
                   
                    if (is_numeric($_POST["WarehouseID"])) { 
                      if($_POST["WarehouseID"]>0)
                      {
                        $ct_correct+=1;
                
                
                      }
                      
                     }
                      
 // echo $ct_correct;
    if($ct_correct==8)
    {
      $ThisWillWork->W1 = $_POST["ID"];
    $ThisWillWork->W2 = $_POST["ItemID"];
    $ThisWillWork->W3 = $_POST["Quantity"];
    $ThisWillWork->W4 = $_POST["Incoming"];
    $ThisWillWork->W5 = $_POST["Outgoing"];
    $ThisWillWork->W6 = $_POST["DateOfTrans"];
    $ThisWillWork->W7 = $_POST["Note"];
    $ThisWillWork->W8 = $_POST["TransID"];
    $ThisWillWork->W9 = $_POST["WarehouseID"];
    $userOne = new Warehouse_Manager();
    $userOne->UpdateAll($ThisWillWork->W1 , $ThisWillWork->W2 ,$ThisWillWork->W3 , $ThisWillWork->W4 ,$ThisWillWork->W5 , $ThisWillWork->W6 , $ThisWillWork->W7 , $ThisWillWork->W8 , $ThisWillWork->W9);


    }
    
    

    

  }

  if(isset($_POST['Remove'])){
 

    $ThisWillWork = new Warehouse_Manager2();
    $ThisWillWork->W1 = $_POST["ID"];            

    $userOne = new Warehouse_Manager();        
    $userOne->DeleteRow($ThisWillWork->W1);
    
    
  }

  if ($TTT == 1)
  {
    $userOne = new Warehouse_Manager();
    $Arrayyyy = $userOne->FetchData();
    
    
    $string = json_encode($Arrayyyy);
    $_SESSION["whatever"] = $string;
    require_once 'WarehouseManager.View.php'; 
  }
  else
  {      
    //require_once ('../Item Card/item_carde_view.php');
    header("Location: http://localhost/MVC/Item%20Card/item_card.controller.php");
  }



?>