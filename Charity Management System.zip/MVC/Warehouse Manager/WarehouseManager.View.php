
<?php


echo ' 
<!DOCTYPE html>
<html>

<head>
<style>
body {
  background-color: #8cd98c;

}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  background-color: white;
}
th, td {
  padding: 10px;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.tab-2 input{display: block;margin-bottom: 10px}
.tab-2{margin-left: 1000px;margin-bottom: -500px}
tr:hover{background-color:#EEE;cursor: pointer}
tr{transition:all .25s ease-in-out}


.button1 {
  position: absolute;
  left:73%;
  top:2%;
}

a:link, a:visited {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  
}

</style>
</head>


<body>
<form action="WarehouseMang.contr.php" method="POST" >
<h1 style="color:rgb(6, 172, 0);"> Items</h1>



<div class="tab tab-2">
        ID:<input type="number" name="ID" id="ID" required>
        Item ID:<input type="number" name="ItemID" id="ItemID" required>
        Quantity:<input type="number" name="Quantity" id="Quantity" required>
        Incoming:<input type="number" name="Incoming" id="Incoming" required>
        Outgoing:<input type="number" name="Outgoing" id="Outgoing" required>
        Date Of Transaction:<input type="date" name="DateOfTrans" id="DateOfTrans" required>
        Note:<input type="text" name="Note" id="Note" required>
        Transaction ID:<input type="number" name="TransID" id="TransID" required>
        Warehouse ID:<input type="number" name="WarehouseID" id="WarehouseID" required>
                                
                <button onclick="editHtmlTbleSelectedRow(); value="Edit" name="Edit" ">Edit</button>
                
            </div>

<table id="table" style="width:60%">
  <tr>
    <th>ID</th>
    <th>Item ID</th> 
    <th>Name</th>
    <th>Quantity</th>
    <th>Incoming</th>
    <th>Outgoing</th>
    <th>Date Of Transaction </th>
    <th>Note</th>
    <th>Transaction ID</th>
    <th>Warehouse ID</th>
  </tr>';

  if(isset($_SESSION["whatever"])){

    $array = json_decode( $_SESSION["whatever"] , true); 
      
      foreach ($array as $arrays)
            {
               echo '<tr><td>';
                    echo $arrays['ID'];                                        
                    echo'</td><td>';
                    echo $arrays['item_ID'];                                        
                    echo'</td><td>';
                    echo $arrays['Name'];                                        
                    echo'</td><td>';
                    echo $arrays['item_quntity'];
                    echo'</td><td>';
                    echo $arrays['incoming'];
                    echo'</td><td>';
                    echo $arrays['outgoing'];
                    echo'</td><td>';
                    echo $arrays['dmy'];
                    echo'</td><td>';
                    echo $arrays['note'];
                    echo'</td><td>';
                    echo $arrays['trns_id'];
                    echo'</td><td>';
                    echo $arrays['Warehouse_ID'];
                    echo'</td>';
                    echo'<td>';
                    echo '<button onclick="removeSelectedRow(); value="Remove" name="Remove"">Remove</button>';
                    echo'</td>';
                    echo '</tr>';
            }

    }       
  
echo'</table>

<script>


function selectedRowToInput()
            {
                var table = document.getElementById("table");
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {                                                                    
                         document.getElementById("ID").value = this.cells[0].innerHTML;
                         document.getElementById("ItemID").value = this.cells[1].innerHTML;
                         document.getElementById("Quantity").value = this.cells[3].innerHTML;
                         document.getElementById("Incoming").value = this.cells[4].innerHTML;
                         document.getElementById("Outgoing").value = this.cells[5].innerHTML;
                         document.getElementById("DateOfTrans").value = this.cells[6].innerHTML;  
                         document.getElementById("Note").value = this.cells[7].innerHTML;
                         document.getElementById("TransID").value = this.cells[8].innerHTML;  
                         document.getElementById("WarehouseID").value = this.cells[9].innerHTML;                     
                    };
                }
              }
              
              selectedRowToInput();
                           
                function editHtmlTbleSelectedRow()
                {
                    var ID = document.getElementById("ID").value,
                        ItemID = document.getElementById("ItemID").value,
                        Quantity = document.getElementById("Quantity").value,
                        Incoming = document.getElementById("Incoming").value,
                        Outgoing = document.getElementById("Outgoing").value,
                        DateOfTrans = document.getElementById("DateOfTrans").value,
                        Note = document.getElementById("Note").value,
                        TransID = document.getElementById("TransID").value,
                        WarehouseID = document.getElementById("WarehouseID").value;
                        
                   
                    var W1 = $_POST["ID"],
                        W2 = $_POST["ItemID"],
                        W3 = $_POST["Quantity"],
                        W4 = $_POST["Incoming"],
                        W5 = $_POST["Outgoing"],
                        W6 = $_POST["DateOfTrans"],
                        W7 = $_POST["Note"],
                        W8 = $_POST["TransID"],
                        W9 = $_POST["WarehouseID"];

                } 
                function removeSelectedRow()
                {
                    var ID = document.getElementById("ID").value;
                        
                    var
                        W1 = $_POST["ID"];
                }                      
         </script>
                 
<div class="button1">
        <button class="button" class="button onclick="myFunction() value="Insert" name="Insert" ">Insert New Item</button>
        <a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
<script>
   function myFunction() {
       $n=new requested_items2(); 
    $TTT = $_POST[2];
    $n=$_POST[2];

   }

     </script>
</div>


</form>
</body>
</html>';







///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////


?>