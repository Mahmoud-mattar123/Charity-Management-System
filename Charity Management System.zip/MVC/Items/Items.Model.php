<?php
require_once 'D:/Xamp new/htdocs/MVC/Database.php';

class Items
{
    public     $ID; 
    public     $Name;  

    public function __construct()
    {
        $this->ID=NULL;
        $this->Name=NULL;                        
    }

    public function FetchName($ID)
    {       
       $db = Database::getInstance();
       $mysqli = $db->getConnection(); 
       $sql_query = "SELECT * FROM `items` WHERE `ID` = '$ID'";
       $result = $mysqli->query($sql_query);                    
                                                               
        while ($row = mysqli_fetch_assoc($result))
        {
            $this->Name = $row['Name'];                       
        }                                                                                       
        return $this->Name;
    }
}

?>