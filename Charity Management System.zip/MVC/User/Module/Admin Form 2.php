<?php

echo'
<!Doctype html>
<html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
a:link, a:visited {
  background-color: #00bfff;
  font-size: 24px;
  width: 50%;
  /* height: 2%; */
  color: white;
  padding: 40px 40px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
 
}

a:hover, a:active {
  background-color: grey;
}
.button1 {
  margin: 0;
  width: 22%;
  
  position: absolute;
  top: 20%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
 
}
.button2 {
  margin: 0;
  position: absolute;
  top: 45%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button3 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 22%;
  left: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.button4 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 45%;
  left: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}


.button5 {
  margin: 0;
  width: 20%;
  position: absolute;
  top: 70%;
  left: 25%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}


.last{
  margin: 0;
  width: 20%;
  position: absolute;
  top: 90%;
  left: 80%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}


.right{
  margin: 0;
  width: 20%;
  position: absolute;
  top: 88%;
  left: 2%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

.notification {
  background-color: #555;
  color: white;
  text-decoration: none;
  padding: 15px 26px;
  position: absolute;
  right: 5%;
  top: 5%;
  display: inline-block;
  border-radius: 2px;
}

.notification:hover {
  background: red;
}

.notification .badge {
  position: absolute;
  top: -10px;
  right: -10px;
  padding: 5px 10px;
  border-radius: 50%;
  background-color: red;
  color: white;
}  


.center {
  position: absolute;
  top: 100px;
  right: -150px;
 
} 


.signout {
  position: absolute;
  top: 700px;
  right: 20px;
  width: 350px;
}

.themeone {
  position: absolute;
  top: -80px;
  right: 20px;
  width: 390px;
}

body {
  background-color: #cce6ff;

}

</style>
<body>




<h1 style="color:rgb(0, 128, 255);">Welcome Admin</h1>



<div class="container center">



<a href="http://localhost/MVC/Case/Case.controller.php" class="btn btn-info" role="button" >Cases</a>



<a href="http://localhost/MVC/Requested%20Items/Requested_Item_Controller.php" class="btn btn-info" role="button">Requsted Items</a>
  


<a href="http://localhost/MVC/Warehouse%20Manager/WarehouseMang.contr.php" class="btn btn-info" role="button"> Items</a>

 
   


<a href="Form2.html" class="btn btn-info" role="button"> Amount of Item Report</a>


  
  




<a href="http://localhost/MVC/Schudle/cevent.php" class="btn btn-info" role="button"> Schedule</a>

  

  




<div class="signout">
<a href="http://localhost/MVC/User/Module/Login.php" class="btn btn-info" role="button"> Sign Out</a>

  </div>




<a href="http://localhost/MVC/Form2.php" class="btn btn-info" role="button">Types Of Report</a>





</div>
</body>
</html>

';
?>