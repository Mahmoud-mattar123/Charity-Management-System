<!Doctype html>
<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
  height: 100%;
  margin: 0;
}

.bg {
  /* The image used */
  background-image: url("1.jpg");

  /* Full height */
  height: 100%; 

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: #4CAF50;
}

.move 1{
position: absolute;
  top: 20px;
  right: 20px;
}

.active {
  background-color: #4CAF50;
}


</style>
</head>

<body>

<ul>
  <li><a class="active" href="#home">Home</a></li>
  <li><a href="http://localhost/MVC/Case/Case.controller.php">Cases</a></li>
  <li><a href="http://localhost/MVC/Requested%20Items/Requested_Item_Controller.php">Requsted Items</a></li>
  <li><a href="http://localhost/MVC/Warehouse%20Manager/WarehouseMang.contr.php">Items</a></li>
  <li><a href="http://localhost/MVC/Schudle/cevent.php">Schedule</a></li>
  <li><a href="http://localhost/MVC/RegulerUser/RegularUserControler.php">Events</a></li>
  <li><a href="http://localhost/MVC/Form2.php">Types Of Report</a></li>
  <li><a href="http://localhost/MVC/User/Module/Admin%20Form%202.php">Theme Two</a></li>
  <li style="float:right"><a class="active" href="http://localhost/MVC/Home%20Page.php#home">Sign Out</a></li>
</ul>



<section>
  <img class="mySlides" src="1.jpg" style="width:100%">
  <img class="mySlides" src="2.jfif" style="width:100%">
  <img class="mySlides" src="3.jpg" style="width:100%">
</section>


<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}
  x[myIndex-1].style.display = "block";
  setTimeout(carousel, 3000);
}
</script>


<form action="User.Contr.php"  method="POST">

</form>

</body>
</html>








