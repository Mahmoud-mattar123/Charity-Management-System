<?php

require_once 'User.php';



$userOne= new User();

if(isset($_SESSION["UserID"]))
{
   
        $x=$userOne->get_htmlll(2);

        echo $x;
    

}

echo "<br>";


if(isset($_POST['theme_two']))
{
    $theme = $_POST["theme_two"];
    $_SESSION["theme_two"]= $theme;

}


if(isset($_POST['login']))
{
    $d = $_POST["Usernamelogin"];

    $e = $_POST["Passwordlogin"];         


    if ($d != '' || $e !='' ) 


    {
     
        // include 'Login.php';
        $userOne= new User();
        $userOne->Login($d,$e);
    

    }
}
if(isset($_POST['signup']))
{
     
    $a = $_POST["Usernamesignup"];    
    $b = $_POST["Passwordsignup"];
    $c = $_POST["Confirmsignup"];
    if ($a != '' ) ////&& $b !='' && $c !=''

    {
  
    if($b == $c)
    {
        // include 'Sign_up.php';
        $userOne= new User();
        $userOne->Signup($a,$b);
    }
    }
}





// $userOne->setUsername('omar hazem kamall');
// 
// $userOne = new User();
// $userOne->setUsername('Youssef Maged');

// echo "<br>";

// $userOne->setPassword('01203025721');
// echo $userOne->getPassword();
// echo "<br>";

// $userOne->setID('193343');
// echo $userOne->getID();
// echo "<br>";

// $userOne->setPhone('*01203025721*');
// echo $userOne->getPhone();
// echo "<br>";

// $userOne->setSalary('100000');
// echo $userOne->getSalary();
// echo "<br>";




?>