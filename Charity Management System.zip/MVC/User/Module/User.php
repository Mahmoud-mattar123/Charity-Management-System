<?php
session_start();
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'whmang');
//   session_start();
/* Attempt to connect to MySQL database */
$link = mysqli_connect("localhost", "root", "", "whmang");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());

    echo "Didn't Connect";
}



class User  {

private $UserName;
private $Password;
private $confirmPassword;
private $Salary;
private $ID;
private $Phone;
private $UserTypeid;
public $sql2;

public function __construct(){
    $this->Username = NULL;
    $this->Password = NULL;
    $this->Salary = NULL;
    $this->ID = NULL;
    $this->Phone = NULL;
    $this->UserTypeid=Null;
    $this->confirmPassword=NULL;
    $this->sql2=NULL;
}

public function setUserTypeid($UTI)
{

   
   $this->UserTypeid = $UTI;
}
public function getUserTypeid()
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                //  return $this->casename; 
                $sql ="SELECT * FROM users";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){
                            
                        //     echo $row['Name'] . "<br>";
                            $this->UserTypeid=$row['UserTypeid']; 
                            

                        }
                    }
}
public function setUsername($UN)
{

  

   $this->Username = $UN;
}

public function getUsername($ID)
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }


                //  return $this->casename; 
                $sql ="SELECT UserName FROM users WHERE ID = '$ID' ";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){ 
                            $this->Username=$row['UserName']; 
                        }
                    }

                    return $this->Username;
}

public function setPassword($Pass)
{   
   

   $this->Password = $Pass;
}

public function getPassword()
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                //  return $this->casename; 
                $sql ="SELECT * FROM users";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){
                            
                        //     echo $row['Name'] . "<br>";
                            $this->Password=$row['Password']; 
                            

                        }
                    };
}

public function setID($ID)
{
  

   $this->ID = $ID;
}

public function getID()
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                //  return $this->casename; 
                $sql ="SELECT * FROM users";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){
                            
                        //     echo $row['Name'] . "<br>";
                            $this->ID=$row['ID']; 
                            

                        }
                    }
}

public function setPhone($Phone)
{
  

   $this->Phone = $Phone;
}

public function getPhone()
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                //  return $this->casename; 
                $sql ="SELECT * FROM users";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){
                            
                        //     echo $row['Name'] . "<br>";
                            $this->Phone=$row['Phone']; 
                            

                        }
                    }
}

public function setSalary($Salary)
{
   

   $this->Salary = $Salary;
}

public function getSalary()
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
   // Check connection
   if($link === false){
       die("ERROR: Could not connect. " . mysqli_connect_error());
   }


   //  return $this->casename; 
   $sql ="SELECT * FROM users";
       $result = mysqli_query($link,$sql);
       $resultCheck = mysqli_num_rows($result);
       if( $resultCheck >0 ){
           while ($row = mysqli_fetch_assoc($result)){
               
           //     echo $row['Name'] . "<br>";
               $this->Salary=$row['Salary']; 
               

           }
       }
}










public function get_html($ID)
{$link = mysqli_connect("localhost", "root", "", "whmang");

    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    //  return $this->casename; 
   
        
       
               
}




public function Login($UserName,$Password)
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
    // Check connection
    if($link === false){
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    $sql=mysqli_query($link,"SELECT * FROM users WHERE UserName='$UserName' AND `Password`='$Password'" );
    while($row=mysqli_fetch_array($sql))
    {
       $sql2=mysqli_query($link,"SELECT UserTypeid From users WHERE UserName='$UserName'");
       while ($row=mysqli_fetch_array($sql2)) 
       {
        if($row['UserTypeid']==0)
        {
         
            
            //header("location: http://localhost/MVC/Admin%20Form.php");
           
                                                  
          $sql=mysqli_query($link,"SELECT * FROM users WHERE UserName='$UserName'" );
          while($row=mysqli_fetch_array($sql))
          {
              $recieveid=$row['ID'];

          }
          $_SESSION["UserID"] =$recieveid ;
          return;   
        //    echo $x;
        }
        if($row['UserTypeid']==1)
        {
            echo "<br>"; 
           
            header("location: http://localhost/MVC/WareHouse%20Manger.php");
        }
        if($row['UserTypeid']==2)
        {
            echo "<br>"; 
           
            header("location: http://localhost/MVC/WareHouse%20Documenter.php");
        }
        if($row['UserTypeid']==3)
        {
                                                    
            $sql=mysqli_query($link,"SELECT * FROM users WHERE UserName='$UserName'" );
            while($row=mysqli_fetch_array($sql))
            {
                $recieveid=$row['ID'];

            }
            echo "<br>"; 
            echo"User";
             $_SESSION["UserID"] =$recieveid ;
             header("location: http://localhost/MVC/RegulerUser/RegularUserControler.php");
        }




       }
    }
}
public function Signup($UserName,$Password)
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
   // Check connection
   if($link === false){
       die("ERROR: Could not connect. " . mysqli_connect_error());
   }

  $sql = "INSERT INTO  `users`(`UserName`, `Password`) VALUES('$UserName','$Password')";
   
  if(mysqli_query($link, $sql)){
   echo "You Signup is Done.";
   } 
   else{
   echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
   }

}
public function Logout()
{
   
}

public function ResetPassword($Password)
{
   
}

public function ForgetPassword()
{
   
}
public function CheckUserType()
{
    $link = mysqli_connect("localhost", "root", "", "whmang");
 
   // Check connection
   if($link === false){
       die("ERROR: Could not connect. " . mysqli_connect_error());
   }

}

public function change_user_type($ID,$newtype)
{
   $link = mysqli_connect("localhost", "root", "", "whmang");
 
   // Check connection
   if($link === false){
       die("ERROR: Could not connect. " . mysqli_connect_error());
   }

 
  $sql =" UPDATE users SET `UserTypeid`='$newtype' WHERE `ID`='$ID'";



  if(mysqli_query($link, $sql)){
   echo "Records Update successfully.";
   } 
   else{
   echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
   }

}


public function get_htmlll($ID)
{$link = mysqli_connect("localhost", "root", "", "whmang");

    // Check connection
    if($link === false)
    {
        die("ERROR: Could not connect. " . mysqli_connect_error());
    }


    //  return $this->casename; 
    $sql ="SELECT * FROM userpages  WHERE ID='$ID'";
        $result = mysqli_query($link,$sql);
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 ){
            while ($row = mysqli_fetch_assoc($result)){



               return  $row['HTML']; 


            }
        }
               
}


}

?>