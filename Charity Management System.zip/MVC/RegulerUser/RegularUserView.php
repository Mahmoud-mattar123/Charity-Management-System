<?php
require_once '../RegulerUser/RegularUserControler.php';

echo '<!Doctype html>
<html>
<style>
a:link, a:visited {
  background-color: green;
  font-size: 24px;
  width: 50%;
  /* height: 2%; */
  color: white;
  padding: 40px 40px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
 
}

a:hover, a:active {
  background-color: grey;
}
.button1 {
    background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
 
}
.button2 {
    position: absolute;
  top: -10px;
  right: -10px;
  padding: 5px 10px;
  border-radius: 50%;
  background-color: green;
  color: white;
}
.button3 {
    position: absolute;
  top: -10px;
  right: -10px;
  padding: 5px 10px;
  border-radius: 50%;
  background-color: green;
  color: white;
}

.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;

  margin: 0;
  position: absolute;
  top: 40%;

  -ms-transform: translateY(-40%);
  transform: translateY(-40%);

  -ms-transform: translateX(520%);
  transform: translateX(520%);
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown .badge {
  position: absolute;
  top: -10px;
  right: -10px;
  padding: 5px 10px;
  border-radius: 50%;
  background-color: green;
  color: white;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 140px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  margin: 0;
 
  top: 50%;

 
 
 
  
  -ms-transform: translateX(430%);
  transform: translateX(430%);

  -ms-transform: translateY(40%);
}

.dropdown-content a {
  color: black;
  padding: 12px 12px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}
.dropdown:hover .dropdown-content {display: block;}
.dropdown:hover .dropbtn {background-color: #3e8e41;}

.nice {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.move{
  position: absolute;
  top: 50%;
  left: 550%;
}



</style>
<body>
<p>
<h1 style="color:rgb(6, 172, 0);">Welcome To Our Website</h1>
</p>




<div class="nice">
<form action="RegularUserControler.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <input  type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">

</div>
';
echo'
<div class="dropdown">

  <button class="dropbtn">Notifications</button>
  <div class="move">
  <div class="dropdown-content">


    <a>';
    if(isset($_SESSION["type"]))
    {
      //$array = json_decode( $_SESSION["type"], true);
      //$string = json_encode($type);
      $array=$_SESSION["type"];
      echo "The event ".$_SESSION["eventname"]." updated fees to ".$_SESSION["eventfees"]." notified by "." ".$array;
    }
    echo'</a>
   
</div>
</div>
</div>

<br><br><br><br><br>
  <button class="button1" onclick="Events(); value="Events" name="Events" ">Events</button>
</form>
<script>
function Events() {    
 $TTT = $_POST[2];
 $n=$_POST[2];
    </script>

</body>
</html>';
?>