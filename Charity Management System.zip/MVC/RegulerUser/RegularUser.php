<?php
require_once '../Database.php';
require_once '../User/Module/User.php';
require_once '../Event/Event_module.php';
require_once '../InterFaceClass Subject/Subject.php';

class RUser implements Subject{

////////////////////////////Subject Functions
public function register_observer($User_ID)
{
  array_push($this->Subscribers,$User_ID);
}
public function remove_observer($User_ID)
{
  $length=count($this->Subscribers);
  for($i=0;$i<$length;$i++)
  {
     if($this->Subscribers[i] == $User_ID)
     {
      $this->Subscribers[i]= 0;
     }
  }
}
public function notify_observer($Event_ID)
{
  $E=new Event();
  $link = mysqli_connect("localhost", "root", "", "whmang");
  if($link === false)
  {
    die("ERROR: Could not connect. " . mysqli_connect_error());
  }

  //Event ID From User ID
  $sql="SELECT `Event_Name`,`Event_Fees` FROM `events` WHERE `Event_ID` = '$Event_ID'";
  $result = mysqli_query($link,$sql);
  $resultCheck = mysqli_num_rows($result);
  if( $resultCheck >0 )
  {
    while ($row = mysqli_fetch_assoc($result))
    {
      $name=$row['Event_Name'];
      $fees=$row['Event_Fees'];
    }
  }

  $j=0;
  //Reg ID
  $sql1="SELECT `Registration_ID` FROM `registration details` WHERE `Event_ID` = '$Event_ID'";
  $result1 = mysqli_query($link,$sql1);
  $resultCheck1 = mysqli_num_rows($result1);
  if( $resultCheck1 >0 )
  {
    while ($row = mysqli_fetch_assoc($result1))
    {
      $registerid=$row['Registration_ID'];

      //User ID From Reg ID
      $sql2="SELECT `User_ID` FROM `registration` WHERE `ID` = '$registerid'";
      $result2 = mysqli_query($link,$sql2);
      $resultCheck2 = mysqli_num_rows($result2);
      if( $resultCheck2 >0 )
      {
        while ($row = mysqli_fetch_assoc($result2))
        {
          $userid=$row['User_ID'];

          //Notification ID
          $sql3="SELECT `Notification_ID` FROM `notificationdetails` WHERE `User_ID` = '$userid'";
          $result3 = mysqli_query($link,$sql3);
          $resultCheck3 = mysqli_num_rows($result3);
          if( $resultCheck3 >0 )
          {
            $j=0;
            $type=array();
            while ($row = mysqli_fetch_assoc($result3))
            {
              $notificationid = $row['Notification_ID'];

              //Notification Type
              $sql4="SELECT `Type` FROM `notificationtype` WHERE `ID` = '$notificationid'";
              $result4 = mysqli_query($link,$sql4);
              $resultCheck4 = mysqli_num_rows($result4);
              if( $resultCheck4 >0 )
              {
                while ($row = mysqli_fetch_assoc($result4))
                {
                  $notify=$row['Type'];
                  array_push($type,$notify);
                }
              }
              $E->update($name,$fees,$type);
            }
          }
        }
      }
    }
  }

}

////////////////////////////Subject Functions
public function subscribtion($User_ID,$Notification_ID)
{
  $db = Database::getInstance();
  $mysqli = $db->getConnection(); 
  $sql_query = "INSERT INTO `notificationdetails` (`User_ID`, `Notification_ID`) VALUES ('$User_ID','$Notification_ID')";
  $result = $mysqli->query($sql_query);    
  if(mysqli_query($mysqli, $result))
  {
   echo "Records inserted successfully.";
   } 
}
  public function HashUploadss($ID)
  {  
      $target_dir = "D:/Xamp new/htdocs/MVC/RegulerUser/";
  
      $HashedDir = password_hash($target_dir , PASSWORD_DEFAULT);
      
      $target_file = $HashedDir . basename($_FILES["fileToUpload"]["name"]);
      $uploadOk = 1;
      $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
      
      // Check if image file is a actual image or fake image
      if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
          echo "File is an image - " . $check["mime"] . ".";
          $uploadOk = 1;
        } else {
          echo "File is not an image.";
          $uploadOk = 0;
        }
      }
      
      // Check if file already exists
      if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
      }
      
      // Check file size
      if ($_FILES["fileToUpload"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
      }
      
      // Allow certain file formats
      if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
      && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
      }
      
      // Check if $uploadOk is set to 0 by an error
      if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
      // if everything is ok, try to upload file
      } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
          echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
  
          $PicID = '1';
          $db = Database::getInstance();
          $mysqli = $db->getConnection(); 
          $sql_query = "INSERT INTO `files`(`FileFriendlyName`, `FilePath`, `FileTypeID`, `UserID`) VALUES ('$target_file','$HashedDir','$PicID','$ID')";
          $result = $mysqli->query($sql_query);
  
          if(mysqli_query($mysqli, $result)){
              echo "Image Uploaded successfully.";
          } 
          // else{
          //     echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
          // }
  
        } else {
          echo "Sorry, there was an error uploading your file.";
        }
      }
  }
  
  
  public function FetchAvailableEvents()
  {
      $EventArray = array();
   
      $db = Database::getInstance();
      $mysqli = $db->getConnection(); 
      $sql_query = "SELECT * FROM events";
      $result = $mysqli->query($sql_query);                    
                                                            
      while ($row = mysqli_fetch_assoc($result))
      {
          $EV = new event(); 
          $EV->ID = $row['Event_ID'];
          $EV->event_name = $row['Event_Name'];
          $EV->event_capacity = $row['Event_Capacity'];
          $EV->event_start = $row['Event_Start'];
          $EV->event_end = $row['Event_End'];
          $EV->event_fees = $row['Event_Fees'];                                                                                      
          array_push($EventArray , $EV);
      }                                                  
          echo "<br>";                         
          return $EventArray;           
  }
}

?>