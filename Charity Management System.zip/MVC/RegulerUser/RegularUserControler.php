<?php
require_once 'RegularUser.php';
require_once '../User/Module/User.php';






if(isset($_POST["submit"]))
{
    if(isset($_SESSION["UserID"])){

        //echo "Dkhallllllll";
        $ID = $_SESSION["UserID"];
        //echo $ID;
    }

    $UserrOneee = new RUser();
    $UserrOneee->HashUploadss($ID);
}

if(isset($_SESSION["UserID"])){

    $recieveID= $_SESSION["UserID"];
}

$TTT = 1;

if(isset($_POST['Events'])){        
    $TTT = 2;
}

if ($TTT == 1)
{
    require_once 'RegularUserView.php';
}
else
{
    $UserrOneee = new RUser();
    $Arrayyy = $UserrOneee->FetchAvailableEvents();
    $string = json_encode($Arrayyy);
    $_SESSION["whatever"] = $string;
    require_once '../Event/EventTable.php';
}

if(isset($_POST['Register'])){        
    $id = $_POST['ID'];
    $name = $_POST['Name'];
    $cost = $_POST['Cost'];
    $_SESSION["SendUserID"]=$recieveID;
    $_SESSION["ID"]=$id;
    $_SESSION["EventCost"]=$cost;
    $_SESSION["Name"]=$name;
    header("Location: http://localhost/MVC/Registration/Reg_controller.php");   

}               
    
//print_r($Arrayyy);

?>