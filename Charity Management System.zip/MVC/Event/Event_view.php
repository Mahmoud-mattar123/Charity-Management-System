
<?php
require_once 'Event_Controler.php';

$userOne= new event();

   $x=$userOne->get_html(1);
   echo $x;

    
   
if(isset($_POST['do9'])){
  $about=$_SESSION["about_us"];
  echo $about;
  $about = " ";
  }

  
class event3
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        public $f;
        public $htmll;

             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
            $this->htmll=NULL;
        }
    }

    $v=new event4();

    if(isset($_POST['do4'])){
      $v=new event4();
      $v->a = $_POST["ID"];    
      $v->b = $_POST["event_name"];
      $v->c = $_POST["event_start"];
      $v->d = $_POST["event_end"];
      $v->e = $_POST["event_capacity"];         
      $v->f = $_POST["event_fees"];   
     
      

    }
    
  
    

 
?>