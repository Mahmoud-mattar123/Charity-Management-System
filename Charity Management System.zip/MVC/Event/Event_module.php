<?php 
require_once '../Database.php';
require_once '../InterFaceClass Observer/Observer.php'; 



class event implements Observer
    {
        public $ID;
        public $event_name;
        public $event_start;
        public $event_end;
        public $event_capacity;
        public $event_fees;
        public $html;

             //constructor
        public function __construct(){
            $this->ID =NULL;
            $this->event_name =NULL;
            $this->event_start =NULL;
            $this->event_end =NULL;
            $this->event_capacity =NULL;
            $this->event_fees =NULL; 
            $this->html =NULL;             
        }




        /////////////////Observer Function
        public function update($event_name,$event_fees,$type)
        {
            $_SESSION["eventname"]=$event_name;
            $_SESSION["eventfees"]=$event_fees;
            $string = json_encode($type);
            $_SESSION["type"]=$string;
        }

         ////////////////////////////////////////////////
         //setters
         //getters
         public function FetchEvents()
         {
             $EventArray = array();
 
             $db = Database::getInstance();
             $mysqli = $db->getConnection(); 
             $sql_query = "SELECT * FROM events";
             $result = $mysqli->query($sql_query);
 
             while ($row = mysqli_fetch_assoc($result))
             {
                 $EV = new event(); 
                 $EV->ID = $row['Event_ID'];
                 $EV->event_name = $row['Event_Name'];
                 $EV->event_capacity = $row['Event_Capacity'];
                 $EV->event_start = $row['Event_Start'];
                 $EV->event_end = $row['Event_End'];
                 $EV->event_fees = $row['Event_Fees'];
                 if($row['IsDeleted']==0)
                 {
 
                     array_push($EventArray , $EV);
                 }
 
             }
                 echo "<br>";
                 return $EventArray;
         }

         public function setreqid($ID)
         {           
            $this->ID=$ID;
         }
         
         public function getreqid()
         {            
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `events`";
            $result = $mysqli->query($sql_query);
                        
                while ($row = mysqli_fetch_assoc($result)){
                    echo $this->ID=$row['ID'];
                    echo "<br>";
                }                                 
         }

         public function setevent_name($event_name)
         {            
            $this->event_name=$event_name;             
         }
         public function getevent_name($ID)
         {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT Event_Name FROM events WHERE Event_ID = '$ID' ";
            $result = $mysqli->query($sql_query);

                while ($row = mysqli_fetch_assoc($result)){
                    $this->event_name=$row['Event_Name'];
                }
                return  $this->event_name;
         }
         public function setevent_start($event_start)
         {
            $this->event_start=$event_start;             
         }
 
         public function getevent_start()
         {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `events`";
            $result = $mysqli->query($sql_query);
                    
             while ($row = mysqli_fetch_assoc($result)){
                echo $this->event_start=$row['event_start'];
                echo "<br>";
            }                                 
         }
////////////////////////////////////////////////////////////////////

        public function setevent_end($ReqSenderID)
        {        
            $this->event_end=$event_end;            
        }

        public function getevent_end()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `events`";
            $result = $mysqli->query($sql_query);
                           
            while ($row = mysqli_fetch_assoc($result)){
                echo $this->event_end=$row['event_end'];
                echo "<br>";                        
                }                           
        }
//////////////////////////////////////////////////////////////////

        public function setevent_capacity($event_capacity)
        {
            $this->event_capacity=$event_capacity;   
        }

        public function getevent_capacity()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `events`";
            $result = $mysqli->query($sql_query);
                
            while ($row = mysqli_fetch_assoc($result)){

                echo $this->event_capacity=$row['event_capacity'];
                echo "<br>";
            }                            
        }

        //////////////////////////////////////////////////////////////////

        public function setevent_fees($event_fees)
        {
            $this->event_fees=$event_fees;            
        }

        public function getevent_fees()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "SELECT * FROM `events`";
            $result = $mysqli->query($sql_query);
                           
            while ($row = mysqli_fetch_assoc($result)){
                echo $this->event_fees=$row['event_fees'];
                echo "<br>";                
             }
        }

        public function Insertevent($event_name,$event_start,$event_end,$event_capacity,$event_fees)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "INSERT INTO  `events`(`event_name`, `event_start`, `event_end`, `event_capacity`,`event_fees`) VALUES('$event_name','$event_start','$event_end','$event_capacity','$event_fees')";
            $result = $mysqli->query($sql_query);          
            
           if(mysqli_query($mysqli, $result)){
            echo "Records inserted successfully.";
            } 
            // else
            // {
            // echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            // }
        }
        public function NotifyAll()
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $notification = $sql_query = "SELECT Event_Name, Event_start FROM `events`";
            $result = $mysqli->query($sql_query);          
            
           if(mysqli_query($mysqli, $sql_query)){
            echo "Records inserted successfully.";
            } 
            else
            {
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
            return $notification;
            /////////////////////////////////////////not yet finished
        }

        public function delete_Event($ID)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE events SET IsDeleted='1' WHERE Event_ID='$ID'";
            $result = $mysqli->query($sql_query);

            if(mysqli_query($mysqli, $result)){
                echo "Record Deleted successfully.";
            } 
            // else{
            //     echo "ERROR: Could not able to execute $result. " . mysqli_error($mysqli);
            //     }
        }
        public function UpdateAll($ID, $EventName , $EventCap ,$EventStart , $EventEnd ,$Fees)
        {                
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `events` SET `Event_Name`='$EventName' ,`Event_Capacity`='$EventCap' ,`Event_Start`='$EventStart',`Event_End`='$EventEnd',`Event_Fees`='$Fees' WHERE `Event_ID`='$ID' ";
            $result = $mysqli->query($sql_query);    
                                             
               if(mysqli_query($mysqli, $sql_query)){
                echo "Record Updated successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
                }
        }


        public function Update_event_name($ID,$event_name)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `events` SET `event_name`='$event_name' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
          
           if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }


        public function Update_event_start($ID,$event_start)
        {
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `events` SET `event_start`='$event_start' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
           
           if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }


        public function Update_event_end($ID,$event_end)
        {   
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `events` SET `event_end`='$event_end' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);           

           if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }
        
        public function Update_event_capacity($ID,$event_capacity)
        {   
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = " UPDATE `events` SET `event_capacity`='$event_capacity' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
           
           if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }

        public function Update_event_fees($ID,$event_fees)
        {   
            $db = Database::getInstance();
            $mysqli = $db->getConnection(); 
            $sql_query = "UPDATE `events` SET `event_fees`='$event_fees' WHERE `ID`='$ID'";
            $result = $mysqli->query($sql_query);
                       
           if(mysqli_query($mysqli, $sql_query)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
            }
        }
        public function get_html($ID)
        {$link = mysqli_connect("localhost", "root", "", "whmang");

            // Check connection
            if($link === false)
            {
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }


            //  return $this->casename; 
            $sql ="SELECT * FROM userpages  WHERE ID='$ID'";
                $result = mysqli_query($link,$sql);
                $resultCheck = mysqli_num_rows($result);
                if( $resultCheck >0 ){
                    while ($row = mysqli_fetch_assoc($result)){



                       return  $row['HTML']; 


                    }
                }
                       
        }

        
}
?>