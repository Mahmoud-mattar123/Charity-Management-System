
<?php
require_once '../RegulerUser/RegularUserControler.php';


echo ' 
<!DOCTYPE html>
<html>

<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 10px;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.tab-2 input{display: block;margin-bottom: 10px}
.tab-2{margin-left: 1000px;margin-bottom: -300px}
tr:hover{background-color:#EEE;cursor: pointer}
tr{transition:all .25s ease-in-out}



.right{
  position: absolute;
  left:73%;
  top:5%;
}

</style>
</head>


<body>

<form action="RegularUserControler.php" method="POST" >
<h2>Available Events</h2>
             

<table id="table" style="width:60%">
  <tr>
    <th>ID</th>
    <th>Name</th> 
    <th>Capacity</th>
    <th>Start Date</th>
    <th>End Date</th>
    <th>Fees</th>      
  </tr>';

  
  

if(isset($_SESSION["whatever"])){
  
  $array = json_decode( $_SESSION["whatever"] , true);  
  foreach ($array as $arrays)
  {
    echo '<tr><td>';
    echo $arrays['ID'];
    echo'</td><td>';
    echo $arrays['event_name'];
    echo'</td><td>';
    echo $arrays['event_capacity'];
    echo'</td><td>';
    echo $arrays['event_start'];
    echo'</td><td>';
    echo $arrays['event_end'];
    echo'</td><td>';
    echo $arrays['event_fees'];
    echo'</td>';
    echo '<td>';
    echo '<button onclick="RegisterInSelectedRow(); value="Register" name="Register"">Register</button>';
    echo'</td>';
    // echo '<td>';
    // echo '<button onclick="GetCaseType(); value="GCT" name="GCT"">Get Case Type</button>';
    // echo'</td>';                                              
    echo'</tr>';
  }          
}


  
echo'</table>
<input type="hidden" id="ID"  name="ID" value = "IDTester">
<input type="hidden" id="Cost"  name="Cost" value = "CostTester">
<input type="hidden" id="Name"  name="Name" value = "NameTester">';
echo '
<script>


function selectedRowToInput()
              {
                var table = document.getElementById("table");
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {                         
                      document.getElementById("ID").value = this.cells[0].innerHTML; 
                      document.getElementById("Name").value = this.cells[1].innerHTML;                       
                      document.getElementById("Cost").value = this.cells[5].innerHTML;
                    };
                }                             
              }
              
              selectedRowToInput();
                           
                function RegisterInSelectedRow()
                {
                  var IDTester = document.getElementById("ID").value;
                  var NameTester = document.getElementById("Name").value;
                  var CostTester = document.getElementById("Cost").value;
                }                             

         </script>
<div class="right">

</div>



</form>
</body>
</html>';







///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////


?>