<?php
require_once 'Event_view.php';
require_once 'Event_Controler.php';


class event2
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        public $f;


             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->n=NULL;
           
        }
    }






echo'
<!DOCTYPE HTML>
<html>

<head>
<script type="text/javascript">
   function RefreshPage()
   {
   
   <meta http-equiv="refresh" content="2"/>
   <meta http-equiv="refresh" content="2"/>
   
   }
</script>

</head>


<style>
body {
    background-color: #8cd98c;
  
  }
  
</style>
<body>
<p>edit about us</p>
</body>


   <td>
   <form action="Event_Controler.php" method="POST" >
   <textarea type="text" name="textt" rows="25" cols="50"> 
   </textarea>
   <td><button class="button" class="button" onclick="RefreshPage()"  value="do9" name="do9" >Change</button></td>
   <td> <a  href="http://localhost/MVC/Event/Event_view.php">Done</a></td>
   <td><a  href="http://localhost/MVC/Event/Event_view.php"> back</a></td>
   </td> 
   <script>
  

   </script>



  </form>
</html>



';


?>





  