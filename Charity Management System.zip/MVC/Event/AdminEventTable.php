
<?php
require_once 'Event_Controler.php';


echo ' 
<!DOCTYPE html>
<html>

<head>
<style>

body {
  background-color: #8cd98c;

}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
  background-color: white;
}
th, td {
  padding: 10px;
}

a:link, a:visited {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  
}
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.tab-2 input{display: block;margin-bottom: 10px}
.tab-2{margin-left: 1000px;margin-bottom: -300px}
tr:hover{background-color:#EEE;cursor: pointer}
tr{transition:all .25s ease-in-out}



.right{
  position: absolute;
  left:73%;
  top:5%;
}


</style>
</head>


<body>

<form action="Event_Controler.php" method="POST" >
<h2>Available Events</h2>
             
<div class="tab tab-2">
        ID:<input type="text" name="ID" id="ID" required>
        Name:<input type="text" name="Name" id="Name" required> 
        Capacity:<input type="number" name="Capacity" id="Capacity" required>
        Start Date:<input type="date" name="StartDate" id="StartDate" required>
        End Date:<input type="date" name="EndDate" id="EndDate" required>
        Fees:<input type="number" name="Fees" id="Fees" required>                                
        <button onclick="editHtmlTbleSelectedRow(); value="Edit" name="Edit" ">Edit</button>                                
</div>


<table id="table" style="width:60%">
  <tr>
    <th>ID</th>
    <th>Name</th> 
    <th>Capacity</th>
    <th>Start Date</th>
    <th>End Date</th>
    <th>Fees</th>      
  </tr>';

  
  

if(isset($_SESSION["whatever"])){
  
  $array = json_decode( $_SESSION["whatever"] , true);  
  foreach ($array as $arrays)
  {
    echo '<tr><td>';
    echo $arrays['ID'];
    echo'</td><td>';
    echo $arrays['event_name'];
    echo'</td><td>';
    echo $arrays['event_capacity'];
    echo'</td><td>';
    echo $arrays['event_start'];
    echo'</td><td>';
    echo $arrays['event_end'];
    echo'</td><td>';
    echo $arrays['event_fees'];
    echo'</td>';
    echo '<td>';
    echo '<button onclick="removeSelectedRow(); value="Remove" name="Remove"">Remove</button>';
    echo'</td>';
    // echo '<td>';
    // echo '<button onclick="GetCaseType(); value="GCT" name="GCT"">Get Case Type</button>';
    // echo'</td>';                                              
    echo'</tr>';
  }          
}


  
echo'</table>

<script>


function selectedRowToInput()
              {
                var table = document.getElementById("table");
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {                         
                        document.getElementById("ID").value = this.cells[0].innerHTML;
                        document.getElementById("Name").value = this.cells[1].innerHTML;
                        document.getElementById("Capacity").value = this.cells[2].innerHTML;
                        document.getElementById("StartDate").value = this.cells[3].innerHTML;
                        document.getElementById("EndDate").value = this.cells[4].innerHTML;
                        document.getElementById("Fees").value = this.cells[5].innerHTML;                         
                    };
                }                             
              }
              
              selectedRowToInput();
                           
              function editHtmlTbleSelectedRow()
              {
                  var ID = document.getElementById("ID").value,
                      Name = document.getElementById("Name").value,
                      Capacity = document.getElementById("Capacity").value,
                      StartDate = document.getElementById("StartDate").value,
                      EndDate = document.getElementById("EndDate").value,
                      Fees = document.getElementById("Fees").value;
                      
                  var
                      W1 = $_POST["ID"],
                      W2 = $_POST["Name"],
                      W3 = $_POST["Capacity"],
                      W4 = $_POST["StartDate"],
                      W5 = $_POST["EndDate"],
                      W6 = $_POST["Fees"];

              } 
              function removeSelectedRow()
              {
                  var ID = document.getElementById("ID").value;
                      
                  var
                      W1 = $_POST["ID"];
              }                            

         </script>
         <div class="right">
         <button class="button" class="button onclick="myFunction() value="Insert" name="Insert" ">Insert New Event</button>
         <a href="http://localhost/MVC/User/Module/User.Contr.php">Home</a>
         <script>
            function myFunction() {                
             $ppp = $_POST[2];
             $n=$_POST[2];
         
            }
         
              </script>
         
         </div>



</form>
</body>
</html>';







///////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////


?>