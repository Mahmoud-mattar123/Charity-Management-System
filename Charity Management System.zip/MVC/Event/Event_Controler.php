<?php
require_once 'Event_module.php';
require_once '../RegulerUser/RegularUser.php';
// session_start();

$ct_correct=0;
class event4
    {
        public $a;
        public $b;
        public $c;
        public $d;
        public $e;
        public $g1;
        public $g2;
        public $g3;
        public $g4;
        public $g5;
        public $g6;
        public $f;


             //constructor
        public function __construct(){
            $this->a =NULL;
            $this->b =NULL;
            $this->c =NULL;
            $this->d =NULL;
            $this->e =NULL;
            $this->f =NULL;
            $this->g1 =NULL;
            $this->g2 =NULL;
            $this->g3 =NULL;
            $this->g4 =NULL;
            $this->g5 =NULL;
            $this->g6 =NULL;
            $this->n=NULL;
           
        }
    }

    $ppp = 1;
if(isset($_POST['Insert'])){
      //echo "Dakhall 3al post beta3t el insert";
        $ppp = 2;
      }

    //   if(isset($_POST['EditAUs'])){
    //     $ppp = 3;
    //   }

    //   if(isset($_POST['do9'])){
    //     $ppp = 3;
    //   }

    if(isset($_POST['do1'])){
      //echo "Dakhall 3al post beta3t el insert";
        $ppp = 2;
                $v=new event4();
                if (is_numeric($_POST["event_name"])) { 
                //donothing
      
                }
                else{
                  $v->b= $_POST["event_name"];
                   $ct_correct+=1;
                  
                }
      
                if (is_numeric($_POST["event_start"])) { 
                //donothing
      
                $ct_correct+=1;
      
                }
      
                if (is_numeric($_POST["event_end"])) { 
                //donothing
      
                $ct_correct+=1;
      
                }
      
                if (is_numeric($_POST["event_capacity"])) { 
                //donothing
                if($_POST["event_capacity"]>0)
                {
                  $v->e = $_POST["event_capacity"];
                  $ct_correct+=1;
      
                }
      
      
                }
                if (is_numeric($_POST["event_fees"])) { 
                  //donothing
                  if($_POST["event_fees"]>0)
                  {
                    $v->f = $_POST["event_fees"];
                    $ct_correct+=1;
      
                  }
      
      
                  }
                  echo  $ct_correct;
                if($ct_correct==3)
                {$v->c = $_POST["event_start"];
                  $v->d = $_POST["event_end"];
                  $userOne= new event();
                  $userOne->Insertevent($v->b,$v->c,$v->d,$v->e,$v->f); //event_name, event_start, event_end, event_capacity,event_fees
                }
       
      }

        if(isset($_POST['Edit'])){
          //echo "Dakhall el iff beta3t el Edittt Akheran ";
          $ct_correct=0;
    
          $ThisWillWork = new event4();
    
          if (is_numeric($_POST["Name"])) { 
            //donothing
    
            }
            else{
              $ThisWillWork->g2= $_POST["Name"];
            $ct_correct+=1;
    
            }
            if (is_numeric($_POST["Capacity"])) { 
              //donothing
              if($_POST["Capacity"]>0)
              {
                $ThisWillWork->g3 = $_POST["Capacity"];
                $ct_correct+=1;
    
              }
    
            }
            if (is_numeric($_POST["Fees"])) { 
              //donothing
              if($_POST["Fees"]>=0)
              {
                $ThisWillWork->g6 = $_POST["Fees"];
                $ct_correct+=1;
    
              }
    
            }
    
            if($ct_correct==3)
            {echo $ct_correct;
              $ThisWillWork->g4 = $_POST["StartDate"];   //$ID, $EventName , $EventCap ,$EventStart , $EventEnd ,$Fees)
              $ThisWillWork->g5 = $_POST["EndDate"];
              $ThisWillWork->g1 = $_POST["ID"];
    
              $userOne = new event();
              $userOne->UpdateAll($ThisWillWork->g1 , $ThisWillWork->g2 , $ThisWillWork->g3 , $ThisWillWork->g4 , $ThisWillWork->g5 , $ThisWillWork->g6);

              $user = new RUser();
              $user->notify_observer($ThisWillWork->g1);
            }
    
    
    
          //$TTT = 2;
        }



if(isset($_POST['Remove'])){

    $ThisWillWork = new event4();
    $ThisWillWork->g1 = $_POST["ID"];           

    $userOne = new event();        
    $userOne->delete_Event($ThisWillWork->g1);                
}


if($ppp==1)
{
    $userOne = new event();

    $Arrayyyy = $userOne->FetchEvents();

    $string = json_encode($Arrayyyy);
    $_SESSION["whatever"] = $string;
    require_once 'AdminEventTable.php';    
}
else {    
    require_once 'Event_view.php';
    
 
    
}                                                
?>