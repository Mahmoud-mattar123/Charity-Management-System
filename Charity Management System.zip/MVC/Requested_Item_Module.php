<?php 




define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'mmm');
// / Attempt to connect to MySQL database */
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
        else{
                // echo "connected";
        }



class requested_items
    {
        public $ID;
        public $ReqType;
        public $ReqSenderName;
        public $ReqSenderID;
        public $IsAccepted;


             //constructor
        public function __construct(){
            $this->ID =NULL;
            $this->ReqType =NULL;
            $this->ReqSenderName =NULL;
            $this->ReqSenderID =NULL;
            $this->IsAccepted =NULL;
           
        }


         ////////////////////////////////////////////////


         //setters
         //getters


         public function setreqid($ID)
         {
           
                $this->ID=$ID;
        }
         
 
         public function getreqid()
         {
            
                //  return $this->casetype; 

                $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                $sql ="SELECT * FROM `requested items`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                            echo $this->ID=$row['ID'];
                            echo "<br>";
                            // $this->ID=$row['ID']; 


                        }
                    }
             
         }



         public function setReqType($ReqType)
         {
            
              
                 
 
                 $this->ReqType=$ReqType;
             
         }
 
         public function getReqType()
         {
            
          
           
                //  return $this->casetype; 

                $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                $sql ="SELECT * FROM `requested items`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                            echo $this->ReqType=$row['ReqType'];
                            echo "<br>";
                            // $this->ID=$row['ID']; 


                        }
                    }

             
         }










         public function setReqSenderName($ReqSenderName)
         {
            
              
                

                $this->ReqSenderName=$ReqSenderName;
             
         }
 
         public function getReqSenderName()
         {
            
          
           
                //  return $this->casetype; 

                $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }
            

                $sql ="SELECT * FROM `requested items`";
                    $result = mysqli_query($link,$sql);
                    $resultCheck = mysqli_num_rows($result);
                    if( $resultCheck >0 ){
                        while ($row = mysqli_fetch_assoc($result)){

                            echo $this->ReqSenderName=$row['ReqSenderName'];
                            echo "<br>";
                            // $this->ID=$row['ID']; 


                        }
                    }

             
         }

////////////////////////////////////////////////////////////////////

        public function setReqSenderID($ReqSenderID)
        {
        
         
            

            $this->ReqSenderID=$ReqSenderID;
            
        }

        public function getReqSenderID()
        {
        
        
        
            //  return $this->casetype; 

            $link = mysqli_connect("localhost", "root", "", "mmm");

            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }
        

            $sql ="SELECT * FROM `requested items`";
                $result = mysqli_query($link,$sql);
                $resultCheck = mysqli_num_rows($result);
                if( $resultCheck >0 ){
                    while ($row = mysqli_fetch_assoc($result)){

                        echo $this->ReqSenderID=$row['ReqSenderID'];
                        echo "<br>";
                        // $this->ID=$row['ID']; 


                    }
                }

            
        }
//////////////////////////////////////////////////////////////////

        public function setIsAccepted($IsAccepted)
        {


            

            $this->IsAccepted=$IsAccepted;
            
        }

        public function getIsAccepted()
        {



            //  return $this->casetype; 

            $link = mysqli_connect("localhost", "root", "", "mmm");

            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }


            $sql ="SELECT * FROM `requested items`";
                $result = mysqli_query($link,$sql);
                $resultCheck = mysqli_num_rows($result);
                if( $resultCheck >0 ){
                    while ($row = mysqli_fetch_assoc($result)){

                        echo $this->IsAccepted=$row['IsAccepted'];
                        echo "<br>";
                        // $this->ID=$row['ID']; 


                    }
                }

            
        }






 //////////////////////////////////////////////////////////////////////////


    //functions 

   

        public function CheckIfAccepted($ID)
        {
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }

               $sql=mysqli_query($link,"SELECT * FROM `requested items` WHERE `ID`='$ID'");
                while($row=mysqli_fetch_array($sql)){
                        
                        return $row['IsAccepted'];
                 
         }

        }

        
        public function CheckIfAcceptedandsendid($ID)
        {
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
                // Check connection
                if($link === false){
                    die("ERROR: Could not connect. " . mysqli_connect_error());
                }

               $sql=mysqli_query($link,"SELECT * FROM `requested items` WHERE `ID`='$ID'");
                   
                 while($row=mysqli_fetch_array($sql)){
                        
                    return $row['ID'];
                     

             }
         }

        
        

        public function InsertRequstedItem($ReqType,$ReqSenderName,$ReqSenderID,$IsAccepted)
        {
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

           $sql = "INSERT INTO  `requested items`(`ReqType`, `ReqSenderName`, `ReqSenderID`, `IsAccepted`) VALUES('$ReqType','$ReqSenderName','$IsAccepted')";
            
           if(mysqli_query($link, $sql)){
            echo "Records inserted successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }

        }



        public function delete_Requested_Item($ID)
        {
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

            $sql =" DELETE FROM `requested items` WHERE `ID`='$ID'";
            if(mysqli_query($link, $sql)){
                echo "Records Deleted successfully.";
                } 
                else{
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                }

        }


        public function Update_Requsted_Type($ID,$ReqType)
        {
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

          
           $sql =" UPDATE `requested items` SET `ReqType`='$ReqType' WHERE `ID`='$ID'";



           if(mysqli_query($link, $sql)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }
        }


        public function Update_Sender_Name($ID,$ReqSenderName)
        {
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

          
           $sql =" UPDATE `requested items` SET `ReqSenderName`='$ReqSenderName' WHERE `ID`='$ID'";



           if(mysqli_query($link, $sql)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }
        }


        public function Update_IsAccepted($ID,$IsAccepted)
        {   
            $link = mysqli_connect("localhost", "root", "", "mmm");
 
            // Check connection
            if($link === false){
                die("ERROR: Could not connect. " . mysqli_connect_error());
            }

          
           $sql =" UPDATE `requested items` SET `IsAccepted`='$IsAccepted' WHERE `ID`='$ID'";



           if(mysqli_query($link, $sql)){
            echo "Records Updated successfully.";
            } 
            else{
            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
            }
        }
public function FetchData()
    {
      $IcArray = array();

      $link = mysqli_connect("localhost", "root", "", "mmm");
 
      // Check connection
      if($link === false){
          die("ERROR: Could not connect. " . mysqli_connect_error());
      }

         $sql ="SELECT * FROM `requested items`";      // $sql ="SELECT * FROM `requested items`";
                    $result = mysqli_query($link,$sql);

                    if(mysqli_num_rows($result) > 0)
                    {
                        while ($row = mysqli_fetch_assoc($result))
                        {
                            $IC = new requested_items(); 

                            $IC->ID = $row['ID']; 
                            $IC->ReqType = $row['ReqType']; 
                            $IC->ReqSenderName = $row['ReqSenderName']; 
                            $IC->IsAccepted = $row['IsAccepted'];
                            $IC->ReqSenderID = $row['ReqSenderID'];

                            array_push($IcArray , $IC);
                        }
                    } 
                  
                   
                    echo "<br>";
                    //echo "This Should be the statement before the return ";
                   return $IcArray;

      // echo "<br>";
      // print_r($IcArray);
    }
     


}














?>