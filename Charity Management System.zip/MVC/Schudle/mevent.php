<?php
require_once 'cevent.php';
require_once 'D:/Xamp new/htdocs/MVC/Event/Event_module.php';
require_once 'D:/Xamp new/htdocs/MVC/User/Module/User.php';
require_once 'D:/Xamp new/htdocs/MVC/Registration/Reg_Module.php';
require_once 'D:/Xamp new/htdocs/MVC/Database.php';





class eventt
{
    public $luser_id;
    public $levent_id;
    public $levent_name;
    public $UserName;
    public $EventName;
    public $RoleType;
    public $levent_start;
    public $levent_end;
    public $event_capacity;
    public $levent_fees;

	public function reg_id_f($user_id)  //done
    {   $lus_id = array();
        

		$db = Database::getInstance();
        $mysqli = $db->getConnection(); 
        $sql_query = "SELECT * FROM `registration` WHERE `User_ID`='$user_id'";
        $result = $mysqli->query($sql_query);
		//ha5od usr_id n5osh 3ala al (registration) we ageb kol al ids we b3d keda haro7 reg dit adwer 3ala al reg_id we ashof al event id we hageeb kol al evntaat bta3et al id da we b3d keda haro7 altabe bta3 
		//al (event id)
                      
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 )
        {  while ($row = mysqli_fetch_assoc($result))
            {  

             $reg_id_from_reg=$row['ID'];

            
                     
                    
               
                
            
            $sql_reg_dit ="SELECT * FROM `registration details` WHERE `Registration_ID`=' $reg_id_from_reg'";
            $result_reg_dit = $mysqli->query($sql_reg_dit);
            $resultCheck__reg_dit = mysqli_num_rows($result_reg_dit);  
            if( $resultCheck__reg_dit >0 )
            {    while ($row1 = mysqli_fetch_assoc($result_reg_dit))
                {

                    $event_id_from_reg_dit=$row1['Event_ID'];

                
                
            
                 $sqll ="SELECT * FROM `events` WHERE `Event_ID`=' $event_id_from_reg_dit'";
                 $resultt = $mysqli->query($sqll);
                 $resultCheckk = mysqli_num_rows($resultt);  
                
                if( $resultCheckk >0 )
                {
                    while ($roww = mysqli_fetch_assoc($resultt))
                    {      
                        $IC = new eventt(); 
                        $User = new User();
                        $IC->luser_id=$user_id;
                        $IC->UserName = $User->getUsername($IC->luser_id);
						$IC->levent_id=$roww['Event_ID'];
						$IC->levent_name=$roww['Event_Name'];
						$IC->levent_start=$roww['Event_Start'];
						$IC->levent_end=$roww['Event_End'];
						$IC->event_capacity=$roww['Event_Capacity'];
                        $IC->levent_fees=$roww['Event_Fees'];								                        
                        array_push($lus_id , $IC);    //asm al class mkan al ic
                    }
                    
                }
            }
        }
    }
               
        }
            return $lus_id;	
    }
                
              
	//---------------------------------------------------------------

    public function event_id_f($eventt_id)
	{
        $lus_id = array();
        //ha5od event_id n5osh 3ala al (reg_details) we hageeb kol al users bta3et al id da we b3d keda haro7 altable bta3 
        //al (users)we ageb aldata bta3tkol al ids de 
        $db = Database::getInstance();
        $mysqli = $db->getConnection(); 
        $sql_query = "SELECT * FROM `registration details` WHERE `Event_ID`='$eventt_id'";
        $result = $mysqli->query($sql_query);
		                        
        $resultCheck = mysqli_num_rows($result);
        if( $resultCheck >0 )
        {
        while ($row = mysqli_fetch_assoc($result))
        {
                $Registration_ID_from_reg_dit=$row['Registration_ID'];

                $sqll ="SELECT * FROM `registration` WHERE `ID`=' $Registration_ID_from_reg_dit'";
                $resultt = $mysqli->query($sqll);
                $resultCheckk = mysqli_num_rows($resultt);  
                if( $resultCheckk >0 )
                {
            while ($row1 = mysqli_fetch_assoc($resultt))
            { $userr_id=$row1['User_ID'];


                $sqll ="SELECT * FROM `users` WHERE `ID`=' $userr_id'";
                $resultt = $mysqli->query($sqll);
                $resultCheckk = mysqli_num_rows($resultt);  
                  if( $resultCheckk >0 )
                  {
                    while ($roww = mysqli_fetch_assoc($resultt))
                    {                                                   
                        $IC = new eventt(); 
                        $EV = new event();
                        $RL = new Reg2();
                        $IC->luser_id=$roww['ID'];
                        $IC->levent_id=$eventt_id;
                        $IC->EventName = $EV->getevent_name($IC->levent_id);
						$IC->levent_name=$roww['UserName'];
                        $IC->RoleType= $RL->getrole_id($IC->luser_id);
                        if ($IC->RoleType == '0')
                        {
                            $IC->RoleType = 'Attender';
                        }
                        else
                        {
                            $IC->RoleType = 'Organizer';
                        }
						        								                        
                        array_push($lus_id , $IC);
                    }
                  }
            }
           }
            }
        
           return $lus_id;
        }		
	}

    public function delete_record($ID)
    {
        $db = Database::getInstance();
        $mysqli = $db->getConnection(); 
        $sql_query = "`registration details` WHERE `Registration_ID`='$ID'";
        $result = $mysqli->query($sql_query);
                
        if(mysqli_query($mysqli, $sql_query)){
         echo "Records deleted successfully.";
        } 
         else{
         echo "ERROR: Could not able to execute $sql_query. " . mysqli_error($mysqli);
        }            
    }
}















?>