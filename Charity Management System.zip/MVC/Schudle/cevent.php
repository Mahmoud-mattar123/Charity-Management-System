<?php
require_once 'mevent.php';
require_once 'vevent.php';

class eventt2
{
    public $Event_ID;
    public $Register_ID;
    public $c;

    public function __construct()
    {
      $this->Event_ID =NULL;
      $this->Register_ID =NULL;
      $this->c =NULL;
    }
}

$v=new eventt2();
$a=new eventt();

if(isset($_POST['do']))
{    
    $v=new eventt2();
    $v->Event_ID = $_POST['Event_ID'];
    $Arrayyyy=$a->event_id_f($v->Event_ID);

    //print_r($Arrayyyy);

    $string = json_encode($Arrayyyy);
    $_SESSION["new"] = $string;
}
if(isset($_POST['do2']))
{   
    $v=new eventt2();  
    $v->Register_ID = $_POST['Register_ID'];
    $c=$v->Register_ID;
    $Arrayyyy =$a->reg_id_f($c);

    $string = json_encode($Arrayyyy);
    $_SESSION["whatever2"] = $string;
}
if(isset($_POST['Remove']))
    {
        $id = $_POST['ID'];
        $a->delete_record($id);
    }

?>