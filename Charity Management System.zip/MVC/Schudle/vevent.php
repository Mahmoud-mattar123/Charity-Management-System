<?php


require_once 'cevent.php';

echo '
<!DOCTYPE html>
<html>
<style>
table, th, td
 {
  border: 1px solid black;
  border-collapse: collapse;
 }
th, td 
{
  padding: 10px;
}



.right{
  position: absolute;
  left:73%;
  top:5%;
}

.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
<body>
<h2>Scheduling</h2>

<form action="cevent.php" method="POST">
  <label for="Event_ID">Search by event ID:</label><br>
  <input type="text" name="Event_ID"><br><br>
  <button class="button onclick="myFunction() value="do" name="do" ">Search</button><br><br>

  
  <label for="Register_ID">Search by register ID:</label><br>
  <input type="text" name="Register_ID"><br><br>
  <button class="button onclick="myFunction1() value="do2" name="do2" ">Search</button><br><br>

  <table id="table" style="width:60%">
  <tr>
    <th>Event ID</th>
    <th>Event Name</th>
    <th>User ID</th>     
    <th>User Name</th>
    <th>Role Type</th>    
  </tr>

  
  <button onclick="editHtmlTbleSelectedRow(); value="Edit" name="Edit"">Edit</button>          
 
';
  if(isset($_SESSION["new"]))
  {
    // echo "Dakhall";
    $CT = 0;
    $array = json_decode($_SESSION["new"] , true);
    foreach ($array as $arrays)
    {
      echo '<tr>';
      echo '<td>';
      if ($CT == 0){
      echo $arrays['levent_id'];
      }
      echo'</td>';
      echo '<td>';
      if ($CT == 0){
        echo $arrays['EventName'];
        }
      echo'</td>';
      echo '<td>';
      echo $arrays['luser_id'];
      echo'</td>';
      echo '<td>';
      echo $arrays['levent_name'];
      echo'</td><td>';
      echo $arrays['RoleType'];
      echo'</td>'; 
      echo '<td>
      <select name="RTypeID" id="RTypeID">
      <option value="M">Organizer</option>
      <option value="F">Attender</option>
      </td>';   
      echo'</tr>';
      $CT = $CT + 1;
    }
  }
  echo'</table>';
  echo "<br>";
   echo "<br>";
    echo "<br>";
     echo "<br>";
  echo'
  <table id="table2" style="width:60%">
  <tr>
    <th>User ID</th>
    <th>User Name</th>
    <th>Event ID</th> 
    <th>Event Name</th>
    <th>Event Start date</th>
    <th>Event End date</th> 
    <th>Event Capacity</th>
    <th>Fees</th>
  </tr>
  
';
  if(isset($_SESSION["whatever2"]))
  {
    $CT = 0;
    $array = json_decode($_SESSION["whatever2"] , true);
    foreach ($array as $arrays)
    {
      echo '<tr>';
      echo '<td>';
      if ($CT == 0){
        echo $arrays['luser_id'];
      }      
      echo'</td>';
      echo '<td>';
      if ($CT == 0){
        echo $arrays['UserName'];
      }      
      echo'</td>';
      echo '<td>';
      echo $arrays['levent_id'];
      echo'</td><td>';
      echo $arrays['levent_name'];
      echo'</td><td>';
      echo $arrays['levent_start'];
      echo'</td><td>';
      echo $arrays['levent_end'];
      echo'</td><td>';
      echo $arrays['event_capacity'];
      echo'</td><td>';
      echo $arrays['levent_fees'];
      echo'</td>';
      echo '<td>';
      echo '<button onclick="removeSelectedRow(); value="Remove" name="Remove"">UnRegister</button>';
      echo'</td>';
      echo'</tr>';
      $CT = $CT + 1;
    }
  }
  echo'</table>
  <input type="hidden" id="ID"  name="ID" value = "IDTester">';
  
echo'<script>


function selectedRowToInput()
              {
                var table = document.getElementById("table2");
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()
                    {                         
                      document.getElementById("ID").value = this.cells[0].innerHTML;  
                                                                                  
                    };
                }                             
              }
              
              selectedRowToInput();
                                          
              function removeSelectedRow()
              { 
                var IDTester = document.getElementById("ID").value;                                                                        
              }      
        </script>
</form>


<a href="http://localhost/MVC/User/Module/User.Contr.php" class="button">Home</a>



</body>
</html>
';


// session_destroy();
?>